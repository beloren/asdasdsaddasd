--------------------------------------------------------------------------------
-- Config
-- ЕДИНСТВЕННЫЙ источник балансных чисел.
-- Ни один сервис не хранит магических констант — всё настраивается здесь.
--------------------------------------------------------------------------------

local Config = {}

Config.Version = "0.1.0"

--------------------------------------------------------------------------------
-- DATA
--------------------------------------------------------------------------------
Config.Data = {
	-- v20.88: ПОЛНЫЙ ВАЙП всех игроков (новый namespace профилей). Старые
	-- профили «_56» остаются в DataStore, просто больше не читаются.
	StoreName = "PvPExtraction_57",
	ReceiptStoreName = "PvPExtraction_01_Receipts_v2", -- НЕ вайпать вместе с профилями: это журнал уже оплаченных покупок, и сброс namespace означал бы повторную выдачу товара по старым чекам
	AutosaveInterval = 120, -- сек
	SaveRetries = 3,
	SaveRetryDelay = 1,
	SessionLockTimeout = 600, -- большой запас сверх autosave; после падения сервера освободится сам
	ReceiptHistoryLimit = 200, -- быстрый кэш последних receipt внутри профиля; полный журнал хранится отдельно
}

Config.Leaderboards = {
	TopCount = 10,
	RefreshInterval = 60,
	-- v20.85: ВАЙП ТОПОВ - новый префикс = новые пустые рейтинги (старые
	-- «_02» остаются в DataStore, просто больше не читаются).
	-- v20.118: стойка лидеров на постаментах - по очереди анимации торговцев
	-- (ключи Config.NpcIdleAnimations): деньги, престиж, донат.
	StatueAnimations = { "BankMerchant", "IslandKeeperNPC", "BankMerchant" },
	StorePrefix = "PvPExtraction_Leaderboard_05", -- текущие глобальные рейтинги (v20.116: сброс топов, профили не трогаем)
	BoardFace = Enum.NormalId.Front,
	-- v20.82: топы (деньги / престиж / донат) - три стенда в центре города
	-- (LeaderboardStands, строит tools/BuildIslandMap или
	-- tools/BuildLeaderboardStands). Перед каждой доской на постаменте -
	-- R6-риг игрока с 1-го места как есть (одежда, аксессуары).
	PerPlotBoards = false, -- true - вернуть старые доски у каждой базы
}

--------------------------------------------------------------------------------
-- ОБУЧЕНИЕ v7 — ДИАЛОГОВЫЙ ПРОЛОГ.
--
-- ЧТО ЗАМЕНИЛО. Старый 12-шаговый гайд жил целиком внутри
-- CustomCartUI.client.lua (одна функция на ~1560 строк) и разошёлся с игрой
-- после двух переделок подряд:
--   • шаг 1 ждал атрибут CarryingCart — но с v12 у нового игрока тележки
--     физически нет, у него в рюкзаке лежит УПАКОВКА (см. Config.CartPackage);
--   • шаг 2 ("поставь тележку в зону шахты") проверял атрибут MineActive,
--     который в новом MineService означает просто "у игрока есть тележка со
--     свободным местом" — шаг засчитывался где угодно на карте;
--   • шаг 3 ("жди 12 капель руды") ждал авто-добычу, которой больше нет:
--     руда добывается ТОЛЬКО экспедицией (см. Config.MineExpedition).
-- Прогресс при этом хранился на КЛИЕНТЕ и обнулялся при каждом перезаходе.
--
-- ЧТО СТАЛО. Шаги — данные (таблица Steps ниже), а не код. Состояние ведёт
-- сервер (TutorialService), пишет его в профиль (Data.TutorialStep) и сам
-- проверяет условия. Клиент (TutorialUI.client.lua) только рисует
-- диалоговое окно и стрелку к цели — подделывать ему нечего.
--
-- ФОРМА ПОДАЧИ — диалоговое окно снизу экрана (плашка имени + портрет +
-- посимвольная печать), которое ПОСЛЕ реплик сворачивается в однострочную
-- плашку-задание и разворачивается обратно на следующем шаге. Один элемент
-- на экране в любой момент времени.
--
-- ЧТО ТУТОРИАЛ СОЗНАТЕЛЬНО НЕ ТРОГАЕТ: жеоды, острова, подиум, сейф,
-- гоблины, динамит, сундуки, престиж, PvP. Всё это объясняется по одной
-- механике за раз через Config.Tutorial.Hints — ровно в тот момент, когда
-- игрок впервые сталкивается с ней сам.
--------------------------------------------------------------------------------
Config.Tutorial = {
	-- Профиль с TutorialVersion < этого числа считается непройденным.
	-- Поднятие версии = ПОВТОРНОЕ прохождение у всех, включая старых
	-- игроков; поднимать только при реальной переделке шагов.
	Version = 7,
	Enabled = true,

	-- Кто говорит. Наставник — тот же НПС-шахтёр, что водит в экспедицию
	-- (MinerNPC, см. MineService), поэтому первый же человек, к которому
	-- игрока просят подойти, потом остаётся его постоянной точкой входа в
	-- добычу — не одноразовый персонаж "только для тутора".
	SpeakerName = "MINER",
	-- Портрет в диалоговом окне. Тот же крот-маскот, что на загрузочном
	-- экране (см. Config.UI.TutorialMoleImageId) — 0 отключит картинку,
	-- окно останется без портрета и не сломается.
	PortraitImageId = 81174978418012,
	TypewriterCharDelay = 0.022,
	-- Сколько ждать после окончания печати, прежде чем разрешить
	-- "Далее" — защита от случайного пропуска реплики двойным тапом.
	AdvanceGuardSeconds = 0.25,


	-- Тип жеоды, которую обучение гарантированно кладёт в первую тележку
	-- новичка (см. GeodeService:SpawnGuaranteedTutorialGeode). Сам момент
	-- выдачи к шагам обучения не привязан и работает как раньше.
	GuaranteedGeodeType = "Stone",

	-- Награда за первое прохождение. BadgeId = 0 — бейдж ещё не создан в
	-- Creator Dashboard (впиши ID, когда создашь), деньги начисляются в
	-- любом случае.
	Reward = {
		Money = 150,
		BadgeId = 0,
	},

	-- Тропинка-трейл к текущей цели (Beam между игроком и целью, см.
	-- TutorialUI.client.lua). TrailTextureId = 0 — луч рисуется просто
	-- цветной линией без текстуры.
	TrailTextureId = 1053551368,
	TrailColor = Color3.fromRGB(255, 70, 70),
	TrailWidth = 2.2,
	TrailTextureLength = 4,
	TrailScrollSpeed = 3,

	--------------------------------------------------------------------------
	-- ШАГИ. ПОРЯДОК В ЭТОЙ ТАБЛИЦЕ = ПОРЯДОК ПРОХОЖДЕНИЯ, кода это не
	-- требует: TutorialService держит индекс текущего шага и идёт по списку.
	--
	-- ПОЛЯ:
	--   Id     — стабильный ключ (пишется в профиль/метрики; не меняй у
	--            уже вышедших шагов, иначе прогресс старых игроков
	--            съедет на соседний шаг).
	--   Lines  — реплики НПС ДО задания. Печатаются по очереди, между
	--            ними игрок жмёт "Далее". Пустой список = сразу задание.
	--   Done   — реплика ПОСЛЕ выполнения (необязательна).
	--   Short  — заголовок в свёрнутой плашке-задании (КАПС, 2-4 слова).
	--   Task   — сама задача одной строкой.
	--   Goal   — условие перехода, см. TutorialService:_goalProgress:
	--              { Kind = "Ack" }                     — просто "Далее"
	--              { Kind = "Counter", Key = ..., Target = N }
	--              { Kind = "Flag", Key = ... }          — атрибут игрока
	--   Target — что подсвечивать в мире (см. TutorialService:_resolveTarget):
	--              "BaseBoulder" | "Bank" | "UpgradeShopNPC" | "MinerNPC"
	--              | "Cart" | nil
	--   Reveal — какие ScreenGui показать, начиная с этого шага (остальные
	--            до тех пор скрыты, чтобы новичок не тонул в иконках).
	--            Сейчас не используется: журнал квестов пуст до конца
	--            пролога (QuestUI.client.lua), открывать его раньше незачем.
	--   KeepEarlyProgress — не обнулять счётчик при входе в шаг.
	--   GrantMoney — разовая выдача денег при входе в шаг.
	--------------------------------------------------------------------------
	-- v20.36: тексты короткие, без длинных тире. Highlight — какая карточка в
	-- окне улучшений крутит лучи (Mine / Cheapest), HighlightColor — цвет.
	-- ResetCounters — счётчики, которые обнуляются при входе в шаг.
	-- v20.40: реплики, где надо жать «Далее», листаются сами через N секунд (0 — выкл).
	AutoAdvanceSeconds = 5,
	Steps = {
		-- v20.110: тексты - что сделать и зачем, коротко. UiTargets - какие
		-- кнопки подсветить (Shared.TutorialTarget): экран вокруг темнеет,
		-- указатель тапает в кнопку. Target - цель в мире (указатель/стрелка).
		{
			-- v20.118: первый шаг - взять кирку (курсор тапает в слот кирки).
			Id = "Intro",
			Lines = { "Hi! I'm your mining buddy.", "First, grab your pickaxe from the hotbar below!" },
			Short = "TAKE THE PICKAXE",
			Task = "Tap the pickaxe in your hotbar (or press 1)",
			Goal = { Kind = "Check", Check = "PickaxeEquipped" },
			UiTargets = { "PickaxeSlot" },
			Done = { "Rocks are blocking your mine. Let's smash them!" },
		},
		{
			Id = "BreakBoulders",
			Lines = {},
			Short = "CLEAR THE WAY",
			Task = "Click the boulders to break them",
			Goal = { Kind = "Counter", Key = "BaseBouldersBroken", Target = 2 },
			KeepEarlyProgress = true,
			Target = "BaseBoulder",
			Done = { "Nice! Boulders drop ore and money." },
		},
		{
			Id = "RepairMine",
			Lines = { "Your mine is broken. The trader fixes it for FREE." },
			Short = "FIX THE MINE",
			Task = "Talk to the trader and press MINE",
			Goal = { Kind = "Flag", Key = "MineRepaired" },
			Target = "UpgradeShopNPC",
			UiTargets = { "UpgradeBuy:Mine", "UpgradeCard:Mine", "Upgrade:Mine" },
			Highlight = "Mine",
			HighlightColor = Color3.fromRGB(255, 70, 70),
			Done = { "The mine works again!" },
		},
		{
			Id = "FirstExpedition",
			Lines = { "Talk to me at the mine to go digging.", "Tap when the marker is on GREEN - you get more and rarer ore!" },
			Short = "GO MINING",
			Task = "Talk to the miner and press LET'S DIG",
			Goal = { Kind = "Counter", Key = "ExpeditionsDone", Target = 1 },
			Target = "MinerNPC",
			UiTargets = { "Miner:Yes" },
			ResetCounters = { "OrePickedUp" },
			Done = { "Great haul! Walk over the ore to pick it up." },
		},
		{
			Id = "CollectOre",
			Lines = {},
			Short = "PICK UP ORE",
			Task = "Walk over the ore to pick it up",
			Goal = { Kind = "Counter", Key = "OrePickedUp", Target = 1 },
			KeepEarlyProgress = true,
			CompleteWhenBagFull = true,
			Target = "MinerNPC", -- v20.118: руда лежит у шахтёра - на него и показываем
			Done = { "Ore goes to your backpack. The counter shows how much fits." },
		},
		{
			Id = "SellOre",
			Lines = { "Take your ore to the sell zone in the middle. A mole will pop up!" },
			Short = "SELL THE ORE",
			Task = "Go to the sell zone and press SELL ALL",
			Goal = { Kind = "Counter", Keys = { "CartSold", "OreSoldFromBag" }, Target = 1 },
			CompleteWhenBagEmpty = true,
			Target = "Bank",
			UiTargets = { "Mole:All" },
			Done = { "A fuller backpack sells for more - up to x3!" },
		},
		{
			Id = "FirstUpgrade",
			Lines = { "Here's a bonus! Make your backpack bigger at the trader." },
			Short = "BIGGER BACKPACK",
			Task = "Talk to the trader and press BACKPACK",
			Goal = { Kind = "Counter", Key = "UpgradesBought", Target = 1 },
			GrantMoney = 150,
			Target = "UpgradeShopNPC",
			UiTargets = { "UpgradeBuy:Cart", "UpgradeCard:Cart", "Upgrade:Cart" },
			Highlight = "Cart",
			HighlightColor = Color3.fromRGB(255, 200, 50),
			Done = { "That's the loop: dig, sell, upgrade! I'll show you more soon." },
		},
	},

	-- v20.110: ГЛАВЫ после основного обучения. When - когда начать
	-- (проверка из TutorialService.Checks), After - какие главы раньше,
	-- SkipIf - уже умеет (старый игрок) => глава засчитана молча.
	-- Шаги - как выше; Goal.Kind ещё "Near" (дойти до Target, Radius) и
	-- "Check" (состояние игрока); SkipUnless - пропустить шаг, если нет условия.
	ChapterGapSeconds = 8,   -- пауза между главами
	NudgeSeconds = 18,       -- игрок стоит на задании столько - напоминание
	ClientFlags = { "QuestsOpened", "CompassOpened" },
	CharacterImageId = 0,    -- персонаж слева в диалоге (0 - PortraitImageId)
	BoardImageId = 0,        -- подложка-табличка справа (0 - тёмная панель)
	PointerImageId = 134580870263733, -- курсор-указатель (v20.116); 0 = рука 👆 (плейсхолдер)
	-- v20.115: курсор «тапает» в нужную кнопку, пока игрок не нажмёт.
	PointerTip = Vector2.new(0.08, 0.06), -- где на картинке остриё (доли: 0,0 - левый верх). Стрелка мыши - ~0.08,0.06; рука 👆 - 0.5,0.06
	PointerSize = 0,                     -- размер в пикселях; 0 = 64 на ПК / 52 на телефоне
	-- v20.118: цель в мире (идти/бить) - 3D-курсор над ней, перевёрнутый остриём
	-- вниз (плитка с картинкой курсора). false - экранный курсор и стрелка-шеврон.
	Cursor3D = true,
	Pointer3DSize = 3.5,                 -- размер 3D-курсора в стадах
	FarDistance = 160,                   -- дальше этого - курсор тапает в кнопку компаса
	-- Пока говорит НПС обучения - эти экраны остаются, остальное уезжает к краям.
	DialogFocusKeep = { "HotbarUi", "TutorialUi", "TutorialCursor" },
	PointerTapSeconds = 1.3,             -- один цикл «подлёт - нажатие - отход» (v20.118: мягче)
	PointerFromDir = Vector2.new(0.45, 1), -- откуда подлетает курсор (вниз-вправо от цели)
	SpotlightColor = Color3.fromRGB(255, 215, 60),
	Chapters = {
		{
			Id = "Quests", Title = "Quests", RewardMoney = 50,
			Steps = {
				{
					Id = "OpenQuests",
					Lines = { "Quests give free money and items.", "Open the MENU and press QUESTS." },
					Short = "QUESTS", Task = "Open MENU, then QUESTS",
					Goal = { Kind = "Flag", Key = "QuestsOpened" },
					UiTargets = { "Menu:Quests", "MenuButton" },
					Done = { "Do quests to earn rewards. New ones come every day!" },
				},
			},
		},
		{
			Id = "NewOre", Title = "New Ore", RewardMoney = 100, After = { "Quests" },
			When = { Check = "CanAffordOre" }, SkipIf = { Check = "OreUnlockedAny" },
			Steps = {
				{
					Id = "BuyOre",
					Lines = { "Your mine only has Coal and Copper.", "Buy new ore from the Ore Merchant in the middle - ORE tab!" },
					Short = "NEW ORE", Task = "Buy an ore box at the Ore Merchant (ORE tab)",
					Goal = { Kind = "Check", Check = "OreBoxOwned" },
					Target = "World:BankMerchant", OnEnter = "EnsureOreStock",
					UiTargets = { "MerchantBuy:Ore_*", "MerchantRow:Ore_*", "MerchantTab:Ore" },
				},
				{
					Id = "OpenBox",
					Lines = { "Take the box from your hotbar - you'll lift it over your head.", "Then click anywhere to open it!" },
					Short = "OPEN THE BOX", Task = "Take the box from the hotbar, then click to open",
					Goal = { Kind = "Check", Check = "OreUnlockedAny" },
					UiTargets = { "Hotbar:gear:OreBox_*" },
				},
				{
					Id = "DigNewOre",
					Lines = { "The new ore is in your mine now.", "Your next dig gives it for sure!" },
					Short = "DIG IT UP", Task = "Talk to the miner and dig",
					Goal = { Kind = "Counter", Key = "ExpeditionsDone", Target = 1 },
					Target = "MinerNPC", UiTargets = { "Miner:Yes" },
					Done = { "Rarer ore sells for more. Buy more ores to get rich!" },
				},
			},
		},
		{
			Id = "AnvilIsland", Title = "Anvil Island", RewardMoney = 150, After = { "NewOre" },
			When = { Check = "CanAffordIsland", Arg = "Anvil" }, SkipIf = { Check = "IslandOwned", Arg = "Anvil" },
			Steps = {
				{
					Id = "BuyAnvil",
					Lines = { "Islands unlock new things! The first one opens geodes.", "Buy the Anvil Island from the Island Keeper." },
					Short = "ANVIL ISLAND", Task = "Buy Anvil Island at the Island Keeper",
					Goal = { Kind = "Check", Check = "IslandOwned", Arg = "Anvil" },
					Target = "World:IslandKeeper", UiTargets = { "IslandBuy", "IslandCard:Anvil" },
				},
				{
					Id = "VisitAnvil",
					Lines = { "Your island rose up behind your base. Go take a look!" },
					Short = "VISIT THE ISLAND", Task = "Walk to your Anvil Island",
					Goal = { Kind = "Near", Radius = 30 }, Target = "Island_Anvil",
				},
				{
					Id = "OpenGeode",
					SkipUnless = { Check = "HasGeode" },
					Lines = { "Geodes from the mine wait in your vault.", "Open one at the anvil to find a crystal!" },
					Short = "OPEN A GEODE", Task = "Open a geode at the anvil",
					Goal = { Kind = "Counter", Key = "GeodesOpened", Target = 1 },
					Target = "GeodeBuilding", -- v20.121: курсор на саму наковальню, а не на верх острова
					Done = { "Crystals earn money on the Income Island. Remember that!" },
				},
			},
		},
		{
			Id = "Compass", Title = "Compass", RewardMoney = 50, After = { "AnvilIsland" },
			Steps = {
				{
					Id = "UseCompass",
					Lines = { "Tired of walking? Use the COMPASS on the left to teleport!" },
					Short = "COMPASS", Task = "Open the compass and teleport",
					Goal = { Kind = "Counter", Key = "Teleported", Target = 1 },
					UiTargets = { "Compass:*", "Compass" },
				},
			},
		},
		{
			Id = "IncomeIsland", Title = "Income Island", RewardMoney = 300, After = { "AnvilIsland" },
			When = { Check = "CanAffordIsland", Arg = "Income" }, SkipIf = { Check = "IslandOwned", Arg = "Income" },
			Steps = {
				{
					Id = "BuyIncome",
					Lines = { "The Income Island makes money - even when you're offline!", "Buy it from the Island Keeper." },
					Short = "INCOME ISLAND", Task = "Buy Income Island at the Island Keeper",
					Goal = { Kind = "Check", Check = "IslandOwned", Arg = "Income" },
					Target = "World:IslandKeeper", UiTargets = { "IslandBuy", "IslandCard:Income" },
				},
				{
					Id = "VisitIncome",
					Lines = { "Go to your new island." },
					Short = "VISIT THE ISLAND", Task = "Walk to your Income Island",
					Goal = { Kind = "Near", Radius = 30 }, Target = "Island_Income",
				},
				{
					Id = "PlaceCrystal",
					SkipUnless = { Check = "HasCrystal" },
					Lines = { "Put a crystal on the podium. It earns money every second." },
					Short = "PLACE A CRYSTAL", Task = "Use the podium and pick a crystal",
					Goal = { Kind = "Check", Check = "CrystalOnPodium" },
					Target = "GeodePodium",
					UiTargets = { "PodiumInstall", "PodiumCrystal:1" }, -- v20.121: курсор в окне подиума
					Done = { "Money piles up in the safe. Come back to collect it!" },
				},
			},
		},
		{
			Id = "SmelterIsland", Title = "Smelter", RewardMoney = 500, After = { "IncomeIsland" },
			When = { Check = "CanAffordIsland", Arg = "Smelter" }, SkipIf = { Check = "IslandOwned", Arg = "Smelter" },
			Steps = {
				{
					Id = "BuySmelter",
					Lines = { "The Smelter turns ore into ingots worth x10!", "Buy it from the Island Keeper." },
					Short = "SMELTER", Task = "Buy the Smelter Island at the Island Keeper",
					Goal = { Kind = "Check", Check = "IslandOwned", Arg = "Smelter" },
					Target = "World:IslandKeeper", UiTargets = { "IslandBuy", "IslandCard:Smelter" },
				},
				{
					Id = "VisitSmelter",
					Lines = { "Go to the Smelter." },
					Short = "VISIT THE ISLAND", Task = "Walk to your Smelter Island",
					Goal = { Kind = "Near", Radius = 30 }, Target = "Island_Smelter",
				},
				{
					Id = "Smelt",
					Lines = { "Take ore in your hand and use the furnace." },
					Short = "SMELT ORE", Task = "Hold ore and use the furnace",
					Goal = { Kind = "Counter", Key = "OresSmelted", Target = 1 },
					Target = "Smelter",
					Done = { "Ingots keep the ore's mutations. Sell them for big money!" },
				},
			},
		},
		-- v20.121: НОВЫЕ МЕХАНИКИ - глава стартует в момент, когда игрок впервые
		-- с ней столкнулся (When), курсор показывает, куда нажать / идти.
		{
			Id = "CrystalBank", Title = "Crystals", RewardMoney = 100,
			When = { Check = "CarryingCrystal" },
			Steps = {
				{
					Id = "BankCrystal",
					Lines = { "You found a crystal! Don't lose it.", "Bring it to the mole at the sell zone - he keeps it in your bank." },
					Short = "BANK THE CRYSTAL", Task = "Go to the sell zone, press DEPOSIT CRYSTAL",
					Goal = { Kind = "Check", Check = "NotCarryingCrystal" },
					Target = "Bank", UiTargets = { "Mole:Crystal" },
					Done = { "Crystals in the bank go on your Income Island podium." },
				},
			},
		},
		{
			Id = "IncomeSafe", Title = "Income Safe", RewardMoney = 100, After = { "IncomeIsland" },
			When = { Check = "SafeHasMoney" },
			Steps = {
				{
					Id = "CollectSafe",
					Lines = { "Your crystal made money! It waits in the safe.", "Walk to the safe to collect it." },
					Short = "COLLECT THE SAFE", Task = "Collect the money from your safe",
					Goal = { Kind = "Counter", Key = "SafeCollected", Target = 1 },
					Target = "GeodeSafe",
					Done = { "Better crystals earn more. Come back often!" },
				},
			},
		},
		{
			Id = "Totems", Title = "Totems", RewardMoney = 100,
			When = { Check = "HasTotemItem" }, SkipIf = { Check = "TotemPlacedAny" },
			Steps = {
				{
					Id = "PlaceTotem",
					Lines = { "You got a TOTEM! It gives your ore mutations.", "Take it from the hotbar and click on your base to place it." },
					Short = "PLACE THE TOTEM", Task = "Take the totem from the hotbar, click on your base",
					Goal = { Kind = "Check", Check = "TotemPlacedAny" },
					UiTargets = { "Hotbar:gear:Totem_*" },
					Done = { "Ore dug near the totem can get its mutation!" },
				},
			},
		},
		{
			Id = "Dynamite", Title = "Dynamite", RewardMoney = 50,
			When = { Check = "HasDynamite" },
			Steps = {
				{
					Id = "UseDynamite",
					Lines = { "Dynamite! It breaks boulders in one go.", "Take it from the hotbar and click on a boulder." },
					Short = "USE DYNAMITE", Task = "Take dynamite from the hotbar, click a boulder",
					Goal = { Kind = "Counter", Key = "DynamiteUsed", Target = 1 },
					Target = "BaseBoulder", UiTargets = { "Hotbar:gear:Dynamite*" },
				},
			},
		},
		{
			Id = "Prestige", Title = "Prestige",
			When = { Check = "CanPrestige" }, SkipIf = { Check = "HasPrestiged" },
			Steps = {
				{
					Id = "DoPrestige",
					Lines = { "You're ready to PRESTIGE!", "You start over, but get Prestige Points for perks that stay forever." },
					Short = "PRESTIGE", Task = "Talk to the Prestige NPC and confirm",
					Goal = { Kind = "Check", Check = "HasPrestiged" },
					Target = "RebirthNPC", UiTargets = { "PrestigeConfirm" },
				},
				{
					Id = "BuyPerk",
					Lines = { "Spend your points in the Prestige case next to your base." },
					Short = "BUY A PERK", Task = "Open the Prestige case and buy a perk",
					Goal = { Kind = "Check", Check = "PerkBoughtAny" },
					Target = "PrestigeCase", UiTargets = { "PerkUpgrade", "PerkNode:*" },
					Done = { "Perks stay after every prestige. Have fun!" },
				},
			},
		},
	},

	-- v20.121: ПОВТОРНЫЕ ПОДСКАЗКИ КУРСОРОМ - вне глав обучения первые Times
	-- раз курсор тапает в нужную кнопку, как только она на экране (окно
	-- открыто). Раз засчитывается, когда кнопка пропала с экрана.
	UiHints = {
		{ Id = "PodiumCrystal", Targets = { "PodiumCrystal:1" }, Times = 3 },  -- окно подиума: самый доходный кристалл
		{ Id = "PodiumInstall", Targets = { "PodiumInstall" }, Times = 3 },    -- кнопка «поставить»
		{ Id = "MoleCrystal", Targets = { "Mole:Crystal" }, Times = 3 },       -- крот: сдать кристалл
		{ Id = "MoleSellAll", Targets = { "Mole:All" }, Times = 2 },           -- крот: продать всё
		{ Id = "CompassPlace", Targets = { "Compass:Raft" }, Times = 2 },     -- карта: домой
	},

	QueuedHintGapSeconds = 8,

	--------------------------------------------------------------------------
	-- КОНТЕКСТНЫЕ ПОДСКАЗКИ (слой 2). Это НЕ шаги — они не блокируют игру и
	-- не идут по порядку. Каждая показывается ОДИН РАЗ за профиль, в тот
	-- момент, когда игрок впервые столкнулся с механикой сам (см.
	-- TutorialService:ShowHint — ключ уже лежит в Data.SeenHints, то есть
	-- в том же хранилище, где и прежние разовые подсказки).
	--
	-- ЗАЧЕМ ОТДЕЛЬНО ОТ ШАГОВ: если запихать жеоды, острова, сейф, гоблинов
	-- и динамит в пролог, он вырастет с двух минут до десяти, и его начнут
	-- пропускать целиком — вместе с той частью, которая объясняет базовый
	-- цикл. Здесь же каждая механика объясняется ровно тогда, когда она уже
	-- появилась у игрока на глазах и ей есть куда примениться.
	--------------------------------------------------------------------------
	-- v20.93: всплывающие окна-подсказки после гайда выключены (false).
	-- true - вернуть разовые подсказки (Hints ниже) при первой встрече.
	ShowHints = false,
	Hints = {
		FirstGeode = "A geode! Crack it open in the vault on your base.",
		FirstChest = "A chest! It opens by itself after a while. Or open it now.",
		FirstGoblin = "Goblins! Hit them with your pickaxe. Every kill pays.",
		FirstDynamite = "Dynamite breaks big rocks. Place it on a boulder.",
		FirstMutation = "Mutated ore is worth a lot more. Don't lose it!",
		FirstPvpHit = "You got hit! Your shield protects you. It drops if you hit back.",
		FirstIsland = "Island unlocked! It adds new things to do.",
	},
}

-- Создай эти бейджи в Creator Dashboard и вставь сюда их числовые ID.
Config.Badges = {
	JoinedGame = 2011645416795580,
	TutorialComplete = 4396951957389002,
	RareOre = 3953627961107346,
	-- v20.106: новые бейджи (BadgeTrackerService). Создай бейдж в Creator Hub
	-- и впиши его Id; 0 = бейдж выключен.
	FirstOre = 0,          -- первая руда
	FirstGeode = 0,        -- первая открытая жеода
	Geodes10 = 0,          -- 10 жеод
	Geodes100 = 0,         -- 100 жеод
	FirstMythic = 0,       -- первая мифическая руда
	FirstCelestial = 0,    -- первая руда с мутацией Celestial
	Prestige1 = 0,         -- первый престиж
	Prestige5 = 0,
	Prestige10 = 0,
	Money1M = 0,           -- $1M на руках
	Money1B = 0,           -- $1B на руках
	MutationBook = 0,      -- найдены все мутации (хотя бы по разу)
	GoldenBoulder = 0,     -- разбил Golden Boulder
	FirstKnockdown = 0,    -- первый нокдаун в PvP
	OneHour = 0,           -- час в игре
}

--------------------------------------------------------------------------------
-- ПОДСКАЗКИ ПОСЛЕ ГАЙДА (не часть основного туториала).
--
-- ЗАЧЕМ ЭТО ОТДЕЛЬНО ОТ ГАЙДА ВЫШЕ. Основной 12-шаговый гайд (Config.
-- Tutorial) ведёт по КОСТЯКУ игры (шахта → тележка → банк → жеода →
-- кристалл → сейф → бой) — и специально НЕ включает вторичные механики,
-- иначе стал бы длиннее и утомительнее для ребёнка на первой минуте. Но у
-- игры есть механики, которые ИНАЧЕ игрок может вообще никогда не открыть
-- сам, потому что ничто на экране не намекает на их существование:
--   - Подарить кристалл другому игроку (RockService:GiftCrystal) — промпт
--     появляется, только если стоишь рядом с игроком, НЕСЯ кристалл в
--     руках — то есть по чистой случайности.
--   - Разбивать валуны по карте ради бонусных кристаллов (Config.Boulders)
--     — они просто стоят в мире без единой подсказки, что их можно трогать.
--
-- Каждая подсказка — один тост NotifyService, ровно один раз за профиль,
-- через фиксированную задержку ПОСЛЕ завершения основного гайда (см.
-- QuestService:_scheduleTips, вызывается из CompleteTutorialRequest и при
-- заходе игрока, который уже прошёл гайд раньше). Задержки специально
-- РАЗНЕСЕНЫ по времени — если бы обе подсказки выпадали разом сразу после
-- гайда, это выглядело бы как ещё один экран текста, который никто не
-- читает, а не как естественная подсказка "в моменте".
-- ПУСТО — обе прежние подсказки (подарить кристалл, разбивать валуны)
-- теперь объясняются ВМЕСТЕ через Config.Quests.Starter.FirstBoulder.
-- OnActivateTip (см. QuestService:_maybeShowQuestActivationTip) — этот
-- тост всплывает РОВНО в момент, когда квест про валун реально становится
-- активным (после апгрейда кирки до тира 2), а не по слепому таймеру
-- после тутора, который мог сработать заметно раньше или позже того, как
-- игрок физически дошёл до этой точки прогрессии. Оставлена как рабочий
-- механизм — новые тайминг-подсказки, не завязанные на конкретный квест,
-- по-прежнему можно добавлять сюда.
Config.Tips = {}

-- Промокоды — вводятся в меню настроек (Discord и т.п.). Каждый код
-- разово на аккаунт (DataService:RedeemCode проверяет и запоминает).
-- Ключи — ВСЕГДА заглавными без пробелов (сервер сам нормализует ввод).
Config.PromoCodes = {
	-- Имя ключа может быть любым. Регистр/пробелы при вводе игнорируются.
	-- ExpiresAt: nil = бессрочно, Unix timestamp ИЛИ дата "YYYY-MM-DD" (UTC).
	-- Суммы подняты ×1.6 вместе с денежными паками: промокоды получают на
	-- РАННЕЙ стадии игры, а цены первых тиров выросли именно во столько раз
	-- (см. Config.MineChain). Без этого награда за код незаметно
	-- обесценилась бы вместе с ребалансом.
	-- Суммы промокодов пересчитаны вместе со сменой масштаба экономики (÷100,
	-- см. Config.Crystal_BaseValue) — та же ранняя-стадийная доля прогресса,
	-- что и раньше, просто в новых числах.
	DISCORD = { Money = 600, Enabled = true, ExpiresAt = nil },
	LAUNCH = { Money = 300, Enabled = true, ExpiresAt = "2027-01-01" },
	["RELEASE<3"] = { Money = 350, Enabled = true, ExpiresAt = nil },
	MINEMOLEHUNTER = { Money = 350, Enabled = true, ExpiresAt = nil },
	-- v16: код с табло лайков (Config.LikeGoals). RequiresLikes — код
	-- работает только когда Config.LikeGoals.CurrentLikes ≥ этого числа.
	-- Chest — вместо/вместе с деньгами выдаёт сундук этой редкости.
	LIKES100 = { Money = 0, Chest = "Rare", RequiresLikes = 100, Enabled = true, ExpiresAt = nil }, -- v20.122: было LIKES50
	OLDLAUNCH = { Money = 150, Enabled = false, ExpiresAt = nil },
}

--------------------------------------------------------------------------------
-- МИР
--------------------------------------------------------------------------------
Config.World = {
	PlotCount = 8,      -- максимум игроков на сервере = число участков
	PlotRadius = 170,   -- расстояние от банка до участка = длина "опасной дороги"
	PlotSize = Vector3.new(48, 1, 48),
}

--------------------------------------------------------------------------------
-- ШАХТА
--------------------------------------------------------------------------------
Config.Mine = {
	-- v20.34: где у МОДЕЛИ шахты визуальный «перёд» относительно её LookVector,
	-- градусы вокруг вертикали. Шахта ставится так, чтобы именно этот бок
	-- смотрел наружу (к MineFacingMarker / в сторону от банка), туда же
	-- смотрит камера улучшения тира. Развернулось не туда — поставьте -90
	-- (или 180 / 0). Деталь MineFront в модели шахты главнее этого числа.
	ModelFrontYaw = -90, -- v20.39: было 90, развёрнуто на 180°
	--------------------------------------------------------------------------
	-- СЛОМАННАЯ ШАХТА (обучение, см. Config.Tutorial).
	--
	-- ПОЧЕМУ НЕ "ТИР 0". Напрашивалось сделать нулевой тир шахты, но
	-- Config.MineTiers — массив 1..CaveCount, и Config.MineTiers[tier]
	-- читается в паре десятков мест (цена апгрейда, пул руды, цвет двери,
	-- тир валунов, гоблины, вся экономика). Индекс 0 вернул бы там nil и
	-- уронил бы половину сервера. Поэтому внутренний тир всегда остаётся
	-- 1, а "шахта не работает" — это ОТДЕЛЬНЫЙ флаг MineRepaired в профиле
	-- (см. DataService/TutorialService). Для игрока разницы нет никакой,
	-- риска для остального кода — ноль.
	--
	-- ПОКА ФЛАГ НЕ ПОДНЯТ: экспедиция у НПС недоступна, а сама модель
	-- шахты обесцвечивается в чёрный неон (материалы и цвета снимаются,
	-- см. PlotService:_applyBrokenLook). Починка — отдельный НУЛЕВОЙ шаг
	-- ветки шахты у торговца (DataService:GetNextBranchStep, флаг Repair):
	-- MineIndex она НЕ двигает, MineChain[1] остаётся следующей покупкой.
	-- Цвета и материалы плавно возвращаются за RepairFadeSeconds.
	--------------------------------------------------------------------------
	Broken = {
		-- ЦЕНА ПОЧИНКИ. Ноль во время обучения (см.
		-- DataService:GetNextBranchStep). Пропуск обучения чинит шахту
		-- сам (TutorialService:_skip), так что RepairCost платит только
		-- игрок с Config.Tutorial.Enabled = true, у которого шахта всё ещё
		-- сломана вне обучения — на практике это страховочное значение.
		RepairCost = 120,
		RepairCostDuringTutorial = 0,
		Color = Color3.fromRGB(12, 12, 16),
		-- Neon намеренно, а не SmoothPlastic: чёрный неон читается как
		-- "выключено/обесточено", а не как "тёмная текстура".
		Material = Enum.Material.Neon,
		RepairFadeSeconds = 1.2,
		-- Что НЕ обесцвечивать — служебные детали, которым внешний вид
		-- задаёт другой код (дверь красится по редкости руды в
		-- MineService:_applyDoorRarity, Zone невидима и так).
		SkipNames = { Zone = true, MineDoor = true },
	},
	SpawnInterval = 2.0 / 1.15, -- ровно на 15% быстрее прежних 2 сек на кристалл
	SpawnSpeedBonusPerTier = 0.05, -- каждый тир шахты ускоряет следующий спавн на 5%
	-- "Тележка у шахты?" теперь проверяется по РЕАЛЬНОЙ площади части Zone
	-- (см. MineService/PlotService), а не по радиусу от центра — отдельного
	-- числа тут больше не нужно.
}

--------------------------------------------------------------------------------
-- РИТМ-МИНИ-ИГРА ВО ВРЕМЯ ДОБЫЧИ — по прямому запросу, чтобы не было
-- скучно стоять и ждать, пока шахта заполнит тележку саму. Пока игрок
-- реально стоит с тележкой в зоне шахты (та же проверка, что двигает
-- обычную добычу — см. MineService.activeCarts), время от времени на
-- экране всплывает кнопка; успел нажать — сразу RewardOreCount руды
-- падает в тележку (в дополнение к обычной добыче, не взамен неё), и
-- ТУТ ЖЕ появляется следующая кнопка КОМБО-цепочки — с более коротким
-- окном на реакцию (первая попытка ощутимо легче, чем raньше — 2 сек, а
-- не 0.9, чтобы дети успевали; сложнее становится только если уже
-- поймал предыдущую). Промах на любом шаге просто обрывает цепочку без
-- штрафа — то, что уже поймано до этого, остаётся начисленным.
--------------------------------------------------------------------------------
Config.MiningRhythm = {
	-- ВЫКЛЮЧЕНО: механика "тележка стоит в зоне шахты → руда сама
	-- капает/мигает кнопка" полностью убрана по ТЗ ("удали механику
	-- выпадения руды из шахты при наступлении рядом тележки"). Добыча
	-- теперь идёт ТОЛЬКО через НПС-экспедицию, см. Config.MineExpedition
	-- и новый MineService.lua. Таблица и код мини-игры оставлены в файлах
	-- (не удалены физически), чтобы легко вернуть при желании — просто
	-- Enabled = true и заново подключить вызовы в MineService.
	Enabled = false,
	MinIntervalSeconds = 14, -- пауза между началами цепочки — рандом в этом диапазоне
	MaxIntervalSeconds = 26,
	-- Окно на реакцию для каждого шага комбо по порядку — длина списка =
	-- максимальная длина цепочки. По прямому запросу — больше 3 шагов
	-- (сейчас 5) и ускорение попроще, чтобы у игрока с медленной реакцией
	-- цепочка сама быстро обрывалась (не тянулась бы долго для всех
	-- подряд) — а не потому что шагов стало меньше.
	ComboWindowSeconds = { 2.0, 1.4, 1.0, 0.7, 0.5 },
	ComboStepPause = 0.2, -- небольшая пауза после попадания, прежде чем показать следующую кнопку — иначе следующая кнопка появлялась бы мгновенно поверх фидбека "NICE!"
	RewardOreCount = 4, -- сколько руды падает в тележку ЗА КАЖДОЕ попадание (не суммарно на всю цепочку)
}

--------------------------------------------------------------------------------
-- ЭКСПЕДИЦИЯ В ШАХТУ v2 — ПОЛНАЯ ЗАМЕНА старой механики "подъехал тележкой —
-- посыпалась руда". См. ТЗ целиком (в двух сообщениях) — коротко:
--   1. Игрок подходит к НПС слева от шахты → диалог → "ОТПРАВИТЬСЯ В ШАХТУ".
--   2. НПС и игрок анимацией ходьбы идут внутрь, камера отъезжает и
--      поднимается (см. NpcWalkInSeconds/CameraDolly ниже).
--   3. Мини-игра "дуга": стрелка катается туда-сюда по дуге, 3 раза подряд
--      спавнится случайная зона на дуге — успеть тыкнуть, пока стрелка в
--      зоне. 3 попадания = добыча состоялась.
--   4. Каждое попадание — FOV-пружинка + шахта "дышит" (расширяется/трясётся)
--      + дверь шахты (MineDoor, см. ниже) обновляет неоновый цвет.
--   5. На 3-м попадании — камера ныряет к земле, из шахты хаотично
--      вылетает вся выбитая руда (см. MineService:_ejectOre), игрок с НПС
--      выходят обратно, камера возвращается игроку.
--   6. Руда лежит на земле — подбирается НАЕЗДОМ тележки (см. CartService).
--------------------------------------------------------------------------------
-- v20.x: РЕПЛИКИ НА СКАМЕЙКЕ (client/BenchChatter). Сел на декор-скамейку -
-- над головой печатаются реплики по одной букве. At - через сколько секунд
-- сидения выскакивает строка. Кириллица видна, только если шрифт темы её
-- поддерживает, иначе будут квадратики.
Config.BenchChatter = {
	Enabled = true,
	Lines = {
		{ At = 0.4, Text = "bruh..." },
		{ At = 30, Text = "nice sitting here, my imaginary friend.." },
	},
	SecondsPerLetter = 0.06, -- скорость печати
	HoldSeconds = 4,         -- сколько строка висит после печати
	HeightOffset = 2.4,      -- над головой, в стадах
	WidthStuds = 9,
	HeightStuds = 1.5,
	MaxDistance = 70,
	TextColor = Color3.fromRGB(255, 255, 255),
}

Config.MineExpedition = {
	-- ШАГ 2: ходьба внутрь.
	NpcWalkInSeconds = 2.2,
	NpcWalkOutSeconds = 2.0,
	-- ID анимации ходьбы НПС/игрока внутрь шахты. Оставь 0, чтобы играть
	-- только перемещение (Humanoid:MoveTo) без самой анимации, пока не
	-- вставишь свой AnimationId (см. ТЗ — "я просто вставлю айди анимки").
	WalkAnimationId = 0,
	-- v20.x: где стоит шахтёр, если нет детали MinerMarker ни в модели
	-- шахты, ни в PlotTemplate. Смещение от зоны шахты (Zone) в её осях:
	-- X вправо, Y вверх, Z вперёд. nil = старое место (слева от шахты).
	-- MinerYaw - доворот шахтёра в градусах.
	MinerOffset = nil, -- например Vector3.new(-12, 0, 4)
	MinerYaw = 0,
	-- true = шахтёр уходит в шахту вместе с игроком (как раньше).
	-- false = шахтёр стоит на месте, в шахту заходит только игрок.
	MinerWalksIn = false,
	-- v20.62: игрок идёт от своего места прямо во вход шахты (без петли по
	-- MinePathN) и почти без паузы перед ходьбой. false - старый путь.
	DirectEntry = true,
	DirectIdleSeconds = 0.2,

	-- ШАГ 2: камера. CameraBackOffset — насколько камера отъезжает НАЗАД
	-- (по -LookVector входа шахты) от точки, где встал игрок для мини-игры,
	-- CameraUpOffset — насколько выше. TweenSeconds — длительность отъезда
	-- (тот же "рывок", что при апгрейде — playUpgradeRevealCamera в
	-- CustomCartUI.client.lua, см. комментарий там).
	CameraBackOffset = 22,
	CameraUpOffset = 16,
	CameraDollySeconds = 1.4,
	CameraFOVDefault = 70,
	CameraFOVMinigame = 62, -- чуть уже во время дуги — фокус на воротах шахты

	-- МАРКЕРЫ КАМЕРЫ (по прямому запросу — "камера летает не так, как
	-- хочет сейчас, а я буду спавнить маркеры с направлением куда она
	-- должна смотреть при каждой ситуации"). Билдер кладёт в модель шахты
	-- пары частей "CameraMarkerN"/"CameraMarkerNLook" (N — просто номер;
	-- см. подробности в PlotService:_buildMine). Здесь — какой номер
	-- маркера отвечает за какую стадию экспедиции. Для стадии, для
	-- которой в этой таблице нет номера ИЛИ у шахты нет соответствующей
	-- пары маркеров, клиент использует старый расчётный долли (см.
	-- CameraBackOffset/CameraUpOffset выше и dollyTo в
	-- MineExpeditionUI.client.lua) — так шахты без маркеров не остаются
	-- совсем без камеры.
	CameraMarkerForStage = {
		WalkIn = 1,
		Minigame = 2,
		Eject = 3,
		WalkOut = 1,
	},

	-- КАМЕРА ПО ОСИ "ШАХТА → БАНК" (по прямому запросу — "вместо работы по
	-- маркерам камеру тоже переделай").
	--
	-- Маркеры требовали ручной расстановки в каждой шахте и молча
	-- отваливались там, где их забыли поставить. Вместо этого камера
	-- теперь СЧИТАЕТСЯ: берём горизонтальное направление от шахты к банку
	-- и отходим вдоль него на нужное расстояние и высоту. Это работает на
	-- любом участке без единого маркера, а разговор с НПС, мини-игра и
	-- выброс руды отличаются только парой чисел.
	--
	--   Talk  — игрок говорит с шахтёром: далеко и ВЫСОКО, смотрим на
	--           шахту сверху (обзорный план, видно весь участок).
	--   Eject — шахта "лопнула": уходим ЕЩЁ дальше в сторону банка и
	--           опускаемся почти на землю (низкий, "киношный" план, руда
	--           летит прямо над камерой).
	UseBankAxisCamera = true, -- false вернёт старое поведение по маркерам
	-- Ещё дальше к банку (было 72/42): с такого отлёта в кадр помещается и
	-- шахта целиком, и вся площадка, куда полетит руда.
	-- Чуть ближе и ниже, чем было (96 / 50) — по прямому запросу.
	CameraTalkDistance = 84,
	CameraTalkHeight = 40,
	CameraTalkSeconds = 1.4,
	CameraTalkAimHeight = 6, -- на сколько выше основания шахты целится камера
	-- ВЫБРОС РУДЫ: ещё ближе к банку и чуть шире объектив. На тесном
	-- кадре разлетающаяся пачка вылезала за края — камера отходит дальше,
	-- а FOV дополнительно расширяется на CameraEjectFOVWiden, чтобы куски
	-- гарантированно помещались целиком.
	-- Ближе, чем было (92): руда теперь падает у самой шахты, и с 92 стадов
	-- она читалась мелко.
	CameraEjectDistance = 62,
	CameraEjectHeight = 8,
	CameraEjectAimHeight = 4, -- было 10: чуть наклоняем вниз, чтобы руда у самого объектива не уходила за нижний край кадра
	CameraEjectFOVWiden = 10, -- прибавляется к обычному FOV на время выброса

	-- ШАГ 3: мини-игра "дуга". HitsRequired — сколько удачных тычков нужно
	-- (ТЗ: ровно 3). Ширина зоны попадания ТЕПЕРЬ СЛУЧАЙНАЯ каждый раунд
	-- (ZoneWidthMin..ZoneWidthMax, доля от всей дуги [0,1]) — по прямому
	-- запросу "на каждой зоне свой шанс увеличения дропа": узкая (сложная)
	-- зона даёт больше LuckPerNarrowZone-бонуса при попадании, чем
	-- широкая (лёгкая), см. MineService:_onArcHit/LuckBonus и
	-- Config.RollOreForTier. SweepSeconds — время одного прохода стрелки
	-- от начала до конца дуги (туда-обратно, пинг-понг).
	-- RoundTimeoutSeconds — если игрок вообще не попал за это время, зона
	-- перевыпускается заново (мини-игра НЕ проваливается насовсем —
	-- просто ждём дальше, добыча — не боевая механика, штрафовать не за что).
	HitsRequired = 3,
	-- ЗОНЫ ДУГИ (по прямому запросу — "красная зона должна быть почти на
	-- весь ползунок, жёлтая на 50 процентов больше, а зелёную процентов на
	-- 5 больше").
	--
	-- РАСКЛАДКА ИЗМЕНИЛАСЬ. Раньше это были пять отдельных плашек встык
	-- (Red|Yellow|GREEN|Yellow|Red), которые вместе занимали всего 38%
	-- дуги — остальные 62% были пустотой, где клик просто не засчитывался.
	-- Теперь это ВЛОЖЕННЫЕ полосы, как в обычной рыбалке/чекпоинте:
	--
	--   [=========== RED (почти вся дуга) ===========]
	--          [==== YELLOW ====]
	--              [ GREEN ]
	--
	-- Красная — фон почти на весь ползунок, жёлтая лежит поверх неё,
	-- зелёная — поверх жёлтой. Промахнуться "в никуда" теперь почти
	-- невозможно, а попадание всё равно имеет градацию: чем точнее, тем
	-- больше удачи.
	--
	-- Width — доля ВСЕЙ дуги [0,1]. Luck — сколько "удачи" даёт попадание
	-- в эту зону (см. MineService:_onArcHit → Config.RollOreForTier —
	-- удача наклоняет финальный ролл руды к более редким слотам тира).
	-- Позиция связки каждый раунд случайная, заучить нельзя.
	-- РАСКЛАДКА ДУГИ (по референсу). Сегменты идут ПОДРЯД и покрывают
	-- дугу ЦЕЛИКОМ — сумма Weight равна 1. Именно это чинит "стрелка не
	-- попадает в края": раньше зоны занимали кусок дуги, а всё остальное
	-- было пустотой, где клик не засчитывался; теперь пустоты нет вообще,
	-- любое положение стрелки попадает в какой-то сегмент.
	--
	-- "Dead" — серые заглушки по краям (как на референсе): в них попасть
	-- можно, но удачи они не дают. Каждый раунд список ЦИКЛИЧЕСКИ
	-- сдвигается на случайное число позиций, поэтому раскладку нельзя
	-- заучить, но она всегда остаётся сплошной и красивой.
	ArcSegments = {
		{ Kind = "Dead",   Weight = 0.07 },
		{ Kind = "Green",  Weight = 0.10 },
		{ Kind = "Yellow", Weight = 0.11 },
		{ Kind = "Red",    Weight = 0.13 },
		{ Kind = "Green",  Weight = 0.18 },
		{ Kind = "Red",    Weight = 0.13 },
		{ Kind = "Yellow", Weight = 0.11 },
		{ Kind = "Green",  Weight = 0.10 },
		{ Kind = "Dead",   Weight = 0.07 },
	},

	ZoneKinds = {
		-- 0.06 → 0.063: +5%, как и просили. Зелёная намеренно осталась
		-- почти такой же — она и должна требовать точности, иначе весь
		-- смысл целиться пропадает.
		Green  = { Width = 0.063, Luck = 0.10, Color = Color3.fromRGB(80, 200, 90) },
		-- 0.07 → 0.105: ровно +50%. Это ПОЛНАЯ ширина жёлтой полосы
		-- (раньше 0.07 было шириной ОДНОГО из двух жёлтых крыльев).
		Yellow = { Width = 0.105, Luck = 0.05, Color = Color3.fromRGB(235, 180, 55) },
		-- "Почти на весь ползунок": 94% дуги, оставшиеся 6% — узкие поля
		-- по краям, чтобы позиция связки всё-таки могла гулять и раскладка
		-- не была одинаковой каждый раунд.
		Red    = { Width = 0.94,  Luck = 0.01, Color = Color3.fromRGB(210, 70, 60) },
		-- Серые заглушки по краям дуги (см. ArcSegments). Клик засчитывается,
		-- удачи не даёт — ровно как промах, но теперь это ВИДНО заранее.
		Dead   = { Width = 0.07,  Luck = 0,    Color = Color3.fromRGB(90, 85, 80) },
	},
	-- Клик ВООБЩЕ мимо всех зон (в те самые 6% полей) теперь тоже
	-- засчитывается как попадание — по прямому запросу "когда по пустой
	-- зоне кликаешь, тоже должно регать". Удачи не даёт, но раунд
	-- двигает: игрок нажал — игра отреагировала. Раньше такой клик
	-- проваливался в тишину, и это читалось как "игра зависла".
	MissLuck = 0,
	MissColor = Color3.fromRGB(150, 150, 160),

	----------------------------------------------------------------------------
	-- МИНИ-ИГРА "РУДНАЯ ЖИЛА" (вариант A). ZoneKinds/ArcSegments выше —
	-- старая раскладка, больше не используется (оставлена для истории).
	--
	-- Удача: PERFECT (самородок) и GOOD (кристаллы). Промах — мимо зон —
	-- удачи НЕ даёт вовсе (по прямому запросу), но удар засчитывается и
	-- раунд идёт дальше.
	----------------------------------------------------------------------------
	VeinLuck = { Perfect = 0.20, Good = 0.07, Miss = 0 }, -- v20.106: было 0.10/0.05 - качество почти не чувствовалось
	-- v20.106: качество ударов меняет и КОЛИЧЕСТВО руды: каждый PERFECT +1
	-- кусок, каждый промах -1 (не меньше MinYield). 3 перфекта всегда лучше 3 промахов.
	VeinYieldBonus = { Perfect = 1, Good = 0, Miss = -1 },
	VeinMinYield = 2,
	VeinColors = {
		Perfect = Color3.fromRGB(255, 205, 70),
		Good = Color3.fromRGB(110, 210, 90),
		Miss = Color3.fromRGB(215, 90, 80),
	},
	-- РАЗНЫЕ ЗОНЫ НА КАЖДЫЙ УДАР (вариант 1). Ширины — доли жилы [0..1].
	--   Good    — ширины кристальных зон этого удара (их может быть несколько);
	--   Perfect — ширина самородка внутри ОДНОЙ случайной кристальной зоны;
	--   Speed   — множитель скорости кирки (>1 — быстрее).
	-- Удар 1 широкий и спокойный, 2 уже, 3 — две маленькие зоны и быстрее.
	VeinRounds = {
		{ Good = { 0.24 }, Perfect = 0.055, Speed = 1.0 },
		{ Good = { 0.16 }, Perfect = 0.045, Speed = 1.1 },
		{ Good = { 0.10, 0.10 }, Perfect = 0.04, Speed = 1.2 },
	},
	VeinEdgeMargin = 0.04, -- зоны не прилипают к самым краям жилы
	VeinHitTolerance = 0.006, -- доля жилы: запас на округление, не на лаг
	-- Компенсация лага: клиент присылает, СКОЛЬКО секунд с начала раунда
	-- прошло у него в момент нажатия; сервер принимает это значение, только
	-- если оно не старше собственного времени больше чем на
	-- 2·пинг + VeinLagGrace (и не больше VeinLagMax).
	VeinLagGrace = 0.12,
	VeinLagMax = 0.35,

	-- МОДИФИКАТОРЫ ЗАХОДА (вариант 4). Выбирается один на весь заход с
	-- шансом ModifierChance, иначе заход обычный (без карточки).
	--   SweepMul    — множитель длительности прохода (<1 — быстрее);
	--   Motion      — "Eased": медленно у краёв, быстро в центре;
	--   GoodMul     — множитель ширины кристальных зон;
	--   PerfectMul  — множитель ширины самородка;
	--   ExtraGood   — сколько кристальных зон добавить в КАЖДЫЙ удар;
	--   LuckMul     — множитель всей удачи; PerfectLuckMul — только самородка.
	ModifierChance = 0.65,
	-- v14.3 — дополнительные поля режимов:
	--   Dual        — две кирки навстречу, засчитывается лучшая из двух;
	--   Momentum    — каждый PERFECT подряд ускоряет кирку (×MomentumSpeed)
	--                 и даёт +MomentumLuck к удаче следующего удара;
	--   Shrink      — { Seconds, MinFrac }: зоны сужаются к центру;
	--   GhostSeconds— через столько секунд зоны гаснут (бить по памяти);
	--   Reverse     — { Count, Min, Max }: кирка разворачивается в случайные
	--                 моменты (Count раз, между Min и Max сек от старта);
	--   Jackpot     — только один крошечный самородок (ширина JackpotWidth);
	--   Hits        — сколько ударов в заходе (вместо HitsRequired).
	Modifiers = {
		{ Id = "FastRock", Weight = 3, Title = "FAST ROCK", Subtitle = "Faster pick, +50% luck",
			Color = Color3.fromRGB(255, 140, 70), SweepMul = 0.72, LuckMul = 1.5 },
		{ Id = "GoldenVein", Weight = 2, Title = "GOLDEN VEIN", Subtitle = "Nuggets give x2.5 luck",
			Color = Color3.fromRGB(255, 205, 70), PerfectMul = 0.75, PerfectLuckMul = 2.5 },
		{ Id = "CrackedVein", Weight = 3, Title = "CRACKED VEIN", Subtitle = "One more crystal zone every hit",
			Color = Color3.fromRGB(140, 220, 120), ExtraGood = 1 },
		{ Id = "WideVein", Weight = 3, Title = "WIDE VEIN", Subtitle = "Bigger crystal zones",
			Color = Color3.fromRGB(120, 200, 255), GoodMul = 1.4, PerfectMul = 1.2 },
		{ Id = "UnstableRock", Weight = 2, Title = "UNSTABLE ROCK", Subtitle = "The pick speeds up in the middle",
			Color = Color3.fromRGB(200, 130, 255), Motion = "Eased", LuckMul = 1.3 },
		-- v14.3 --------------------------------------------------------------
		{ Id = "SlowMo", Weight = 3, Title = "SLOW MO", Subtitle = "Super slow pick, a bit less luck",
			Color = Color3.fromRGB(150, 220, 255), SweepMul = 1.8, GoodMul = 0.9, LuckMul = 0.85 },
		{ Id = "DualPicks", Weight = 2, Title = "DUAL PICKS", Subtitle = "Two picks - the best one counts!",
			Color = Color3.fromRGB(255, 120, 200), Dual = true, GoodMul = 0.85 },
		{ Id = "Momentum", Weight = 2, Title = "MOMENTUM", Subtitle = "Perfect streak = faster pick, more luck",
			Color = Color3.fromRGB(255, 90, 90), Momentum = true, MomentumSpeed = 0.85, MomentumLuck = 0.5 },
		{ Id = "ShrinkingVein", Weight = 2, Title = "SHRINKING VEIN", Subtitle = "Zones shrink - hit fast!",
			Color = Color3.fromRGB(120, 255, 200), GoodMul = 1.35, Shrink = { Seconds = 2.6, MinFrac = 0.3 }, LuckMul = 1.15 },
		{ Id = "GhostVein", Weight = 1, Title = "GHOST VEIN", Subtitle = "Zones vanish - hit from memory, +40% luck",
			Color = Color3.fromRGB(190, 200, 230), GhostSeconds = 0.7, LuckMul = 1.4 },
		{ Id = "Reverse", Weight = 2, Title = "REVERSE", Subtitle = "The pick turns around at random",
			Color = Color3.fromRGB(255, 170, 90), Reverse = { Count = 2, Min = 0.5, Max = 2.6 }, LuckMul = 1.2 },
		{ Id = "Jackpot", Weight = 1, Title = "JACKPOT", Subtitle = "One tiny nugget - x4 luck!",
			Color = Color3.fromRGB(255, 225, 60), Jackpot = true, JackpotWidth = 0.055, PerfectLuckMul = 4 },
		{ Id = "Frenzy", Weight = 1, Title = "FRENZY", Subtitle = "5 quick hits!",
			Color = Color3.fromRGB(255, 80, 160), Hits = 5, SweepMul = 0.72, LuckMul = 0.6 },
	},

	-- РЕАКЦИЯ ШАХТЫ НА УДАР — своя на каждый результат. Overshoot — насколько
	-- шахта "подпрыгивает" сверх накопленного роста (доля MineBaseScale),
	-- Shake — амплитуда тряски в стадах, ShakeSeconds — её длительность,
	-- Rocks — сколько каменных осколков вылетает из входа (у клиента).
	MineHitReaction = {
		Perfect = { Overshoot = 0.20, Shake = 0.55, ShakeSeconds = 0.4, Rocks = 22 },
		Good    = { Overshoot = 0.09, Shake = 0.22, ShakeSeconds = 0.28, Rocks = 14 },
		Miss    = { Dip = 0.06, Shake = 0.10, ShakeSeconds = 0.22, Rocks = 6 },
	},
	-- v9: цветные эффекты двери (неон по качеству удара, VFX_<Rarity>) —
	-- выключены; на клик только серые 3D-осколки вокруг всей шахты.
	DoorColorFX = false,
	-- v9: вход редкости подгоняется под размер ENTRY, но не сильнее этих рамок.
	EntryScaleMin = 0.75,
	EntryScaleMax = 1.5,
	SweepSeconds = 1.6,
	RoundTimeoutSeconds = 8,
	HitForgivenessSeconds = 0.12, -- запас на сетевую задержку клика, как в старой ритм-мини-игре

	-- "УДАЧА" ЗА МИНИ-ИГРУ (по прямому запросу — "с каждым кликом надо
	-- увеличивать редкость выпадения, хотя бы визуально или не сильно") —
	-- копится за экспедицию (см. MineService:_onArcHit → expedition
	-- .LuckBonus), применяется один раз при роллах ВСЕЙ пачки руды в
	-- конце (см. _ejectOre → Config.RollOreForTier(tier, luckBonus)).
	-- Сколько даёт каждая зона — см. ZoneKinds выше (Luck). За 3
	-- попадания подряд в ЗЕЛЁНУЮ набегает 0.30 — заметно, но не
	-- переворачивает шансы тира с ног на голову (см. потолок 0.6 в
	-- Config.RollOreForTier). Три красных дадут всего 0.03 — клик
	-- засчитан, но почти без пользы, ровно как и задумано.

	-- ШАГ 4: "пружинка" FOV на каждое попадание + тряска шахты.
	HitFOVKick = -6, -- отрицательное = временно СУЖАЕТСЯ (наезд), затем плавно возвращается
	HitFOVKickSeconds = 0.22,

	-- НАКОПИТЕЛЬНЫЙ НАЕЗД КАМЕРЫ (по прямому запросу — "сделай её
	-- динамичной, чтобы при каждом клике условно камера приближалась
	-- слегка"). В отличие от HitFOVKick выше, который отыгрывает назад,
	-- этот наезд ОСТАЁТСЯ: с каждым кликом базовый FOV становится уже, и
	-- к последнему попаданию камера заметно ближе к воротам шахты, чем
	-- была на первом. Отсчёт сбрасывается в начале каждой экспедиции.
	--
	-- Шаг отрицательный (сужение = приближение). Потолок нужен, чтобы
	-- длинная серия не загнала FOV в неприлично узкий "телескоп", при
	-- котором любое движение камеры выглядит рывком.
	-- Наезд сделан СЛАБЕЕ (было -3.5 за клик при потолке -14): на прошлых
	-- значениях к третьему попаданию кадр становился настолько узким, что
	-- шахта переставала помещаться целиком.
	HitFOVZoomStep = -1.8,
	HitFOVZoomMax = -6,
	HitFOVZoomSeconds = 0.35,
	MineShakeMagnitude = 0.35,
	MineShakeSeconds = 0.3,
	-- Во сколько раз модель шахты "раздувается" на пике каждого попадания
	-- (ScaleTo вокруг текущего размера, потом плавно назад).
	-- ПОСТОЯННЫЙ РАЗМЕР ШАХТЫ (по прямому запросу — "+30% для любого тира").
	-- Это БАЗОВЫЙ масштаб, вокруг которого пляшут все временные эффекты
	-- (рост при ударах, "взрыв"). Если бы рост/взрыв продолжали считать
	-- от 1, они бы на каждом ударе SBRAсывали шахту обратно к её
	-- АВТОРСКОМУ размеру (Model:ScaleTo принимает АБСОЛЮТНЫЙ масштаб от
	-- исходной геометрии, а не "от текущего") — постоянная прибавка бы
	-- пропадала при первом же клике мини-игры. Поэтому весь код роста
	-- ниже (_stretchMine/_burstMine) считает от ЭТОЙ константы, а не от 1.
	MineBaseScale = 1.3,
	-- v20.16: анимацию масштаба шахты (растяжение, взрыв, плевок) проигрывает
	-- клиент (client/MineScaleFX) — сервер не гоняет ScaleTo всей модели по
	-- сети каждый кадр (это давало пролаг при перелёте камеры к руде).
	ClientMineScale = true,

	MineBulgeScale = 1.06,

	-- ШАХТА РАСТЯГИВАЕТСЯ С КАЖДЫМ КЛИКОМ (по прямому запросу). В отличие
	-- от MineBulgeScale выше, который отыгрывает назад сразу, этот
	-- масштаб НАКАПЛИВАЕТСЯ: к третьему попаданию шахта заметно раздута и
	-- выглядит так, будто вот-вот лопнет — что дальше и происходит.
	-- Рост РЕЗКИЙ (по прямому запросу): шахта скачком прибавляет в размере
	-- на каждый клик и тут же чуть оседает — читается как удар изнутри, а
	-- не как плавное надувание.
	MineStretchPerHit = 0.14,
	MineStretchOvershoot = 0.09, -- на сколько проскакивает выше цели в момент удара
	MineStretchSeconds = 0.18,
	-- "Шахта будто лопается" в момент завершения мини-игры: резко
	-- раздувается и тут же схлопывается обратно к MineBaseScale.
	--
	-- MineBurstScale ЗАДАЁТСЯ МНОЖИТЕЛЕМ ОТ MineBaseScale, а не абсолютным
	-- числом. Абсолютное 1.4 было МЕНЬШЕ, чем шахта успевает раздуться
	-- накопительным ростом за 3 удара мини-игры (HitsRequired) даже без
	-- поправки на +30% (1 + 0.14×3 + оverdshoot ≈ 1.51 > 1.4) — то есть
	-- "взрыв" в кульминационный момент на деле СЖИМАЛ шахту, а не раздувал.
	-- С добавлением MineBaseScale = 1.3 разрыв стал ещё заметнее (шахта к
	-- третьему удару уже около 1.72-1.81, а взрыв тянул её вниз до 1.4).
	-- Множитель гарантирует, что взрыв ВСЕГДА больше самого раздутого
	-- состояния перед ним, при любой базе.
	MineBurstScale = 1.5, -- итоговый масштаб = MineBaseScale * MineBurstScale
	MineBurstSeconds = 0.45,

	-- "ПЛЕВОК" ШАХТЫ НА КАЖДУЮ РУДУ (по прямому запросу): пока руда
	-- приседает в двери, шахта чуть поджимается (MineSpitSquash), в момент
	-- вылета резко раздувается (MineSpitScale) и упруго возвращается к
	-- MineBaseScale. Оба числа — МНОЖИТЕЛИ от MineBaseScale.
	-- Руды одного батча вылетают по очереди с шагом MineSpitStaggerSeconds,
	-- чтобы у каждой был свой плевок (см. MineService:_ejectOre/_spitMine).
	MineSpitScale = 1.2,
	MineSpitSquash = 0.94,
	MineSpitSeconds = 0.55,
	MineSpitStaggerSeconds = 0.5,

	-- РУДА НА ВРЕМЯ КАТСЦЕНЫ КРУПНЕЕ (по прямому запросу). Пока идёт
	-- катсцена, камера стоит далеко, и руда нормального размера читалась бы
	-- как несколько пикселей. Поэтому на время выброса каждый кусок
	-- увеличивается, а когда катсцена заканчивается — плавно садится
	-- обратно к 1, уже рядом с игроком.
	-- КАТСЦЕНА С ДУБЛЁРОМ (по прямому запросу). Камера больше НЕ залетает
	-- внутрь шахты: сразу после разговора она встаёт на верхнюю точку, с
	-- которой идёт мини-игра, и оттуда показывает, как в шахту заходят —
	-- а в конце выходят — шахтёр и КЛОН игрока.
	--
	-- Настоящий персонаж при этом не двигается вообще: он становится
	-- невидимым и стоит ровно там, где нажал на разговор, поэтому по
	-- окончании катсцены игрок оказывается на том же месте — никакого
	-- "возврата" не требуется, возвращать нечего.
	--
	-- Идут ПО ОЧЕРЕДИ: сначала оба стоят (ActorIdleSeconds), потом трогается
	-- шахтёр, а клон выходит следом с задержкой ActorStaggerSeconds — так
	-- читается "повёл за собой", а не "двое синхронно поехали".
	ActorIdleSeconds = 0.9,
	ActorStaggerSeconds = 0.8,
	ActorWalkSeconds = 2.2,
	ActorCloneOffset = Vector3.new(-3, 0, 0), -- где клон стоит относительно шахтёра у входа

	-- v14.3: ПУТЬ В ШАХТУ. Шахтёр и клон игрока идут ПО ТОЧКАМ: отходят от
	-- входа, поворачивают направо, проходят, ещё раз направо и заходят в
	-- ENTRY. Точки — детали MinePath1, MinePath2, MinePath3… внутри модели
	-- шахты (сколько положишь — столько и пройдут, по порядку номеров). Нет
	-- ни одной — путь считается сам из чисел ниже (отсчёт от места, где
	-- стоял шахтёр, «вперёд» = куда смотрит шахта).
	ActorWalkSpeed = 9,          -- стадов/сек
	ActorTurnSpeed = 10,         -- насколько резко разворачиваются на поворотах
	ActorFollowGap = 3.2,        -- клон идёт за шахтёром на таком расстоянии
	PathAutoForward = 7,         -- авто-путь: сколько отойти от шахты
	PathAutoSide = 7,            -- …потом вправо
	PathAutoApproach = 5,        -- …потом к точке перед входом
	-- Анимация ходьбы клона (Humanoid игрока). 0 — стандартная Roblox.
	ActorWalkAnimationR15 = 0,
	ActorWalkAnimationR6 = 0,

	-- v14.3: ПОСЛЕ ВЫХОДА руда из шахты не подбирается, пока игрок не
	-- сдвинется с места появления хотя бы на ExitMoveThreshold стадов, и
	-- подбирается только вблизи (DropPickupRadius; с пропуском OreMagnet —
	-- DropPickupRadiusMagnet). Так куча не «магнитится» в игрока сама.
	ExitMoveThreshold = 3,
	DropPickupRadius = 4.5,
	DropPickupRadiusMagnet = 9,

	-- v14.3: КАРТОЧКА РЕДКОСТИ ШАХТЫ после мини-игры — пролетает снизу
	-- вверх экрана с микро-паузой в центре, потом начинается вылет руды.
	-- Свои модели: ReplicatedStorage.Assets.MineRarityCards.<Редкость>
	-- (Common, Uncommon, Rare, Epic, Legendary, Mythic) — см. CHANGELOG.
	-- v20.109: ЛЕНТА РЕДКОСТЕЙ (как в кейсах) перед карточкой редкости:
	-- крутится, дразнит соседней редкостью повыше и встаёт на лучшую руду
	-- этой пачки. Только без тележек (руда роллится заранее).
	RarityReel = {
		Enabled = true,
		-- v20.118: "3D" - крутятся сами 3D-карточки редкости (MineRarityCards)
		-- сверху вниз барабаном и встают на выпавшую; "2D" - плоская лента.
		Mode = "3D",
		Cards3D = 16,        -- карточек в 3D-ленте
		Gap3D = 0.5,         -- промежуток между карточками (доля высоты карточки)
		DrumDegrees = 38,    -- наклон карточек у краёв (эффект барабана)
		Seconds = 4.9,       -- прокрутка (v20.121: +1.5 с)
		HoldSeconds = 0.8,   -- пауза на выпавшей редкости (с лучами сзади)
		Tiles = 46,          -- плиток в ленте
		TileWidth = 118,     -- (старая горизонтальная лента, не используется)
		TileGap = 10,        -- зазор между карточками
		-- v20.114: вертикальная лента без фона (карточки едут сверху вниз)
		CardWidth = 300,
		CardHeight = 92,
		VisibleCards = 5,    -- сколько карточек видно в колонке
		TeaseChance = 0.75,  -- шанс, что следующая плитка - редкость повыше
		Weights = { Common = 50, Uncommon = 26, Rare = 13, Epic = 7, Legendary = 3, Mythic = 1 },
	},
	RarityCard = {
		Distance = 10,       -- стадов перед камерой (карточка — 3D-объект в мире)
		ScreenWidth = 0.29,  -- ширина карточки, доля экрана (v20.67: 0.18 → 0.29, +60%)
		-- v20.62: лицом к камере всегда САМАЯ ШИРОКАЯ грань главной детали
		-- (если на ней Decal/SurfaceGui - берётся именно та сторона).
		-- CardRotation - доп. поворот в градусах (X, Y, Z); Z - в плоскости экрана.
		CardRotation = Vector3.new(0, 0, 0),
		-- v17: дольше висит в центре и двигается плавнее (вылет с мягким
		-- перелётом, покачивание в центре, замах вниз перед уходом вверх).
		InSeconds = 0.6,     -- вылет снизу до центра
		HoldSeconds = 1.45,  -- «висит» в центре (+ HoldExtra редкости)
		OutSeconds = 0.5,    -- улетает вверх
		SwayDegrees = 7,     -- покачивание в центре (крен/поворот)
		TiltDegrees = 24,    -- наклон: снизу — вниз, сверху — вверх
		-- ЭФФЕКТЫ ПО РЕДКОСТИ (в момент остановки в центре):
		--   Burst — искры; Stars — крупные звёзды; Rays — лучи позади;
		--   Ring — ударная волна; Confetti — конфетти; Shake — тряска камеры;
		--   Flash — вспышка экрана цветом редкости (0..1); Rainbow — рамка
		--   переливается; HoldExtra — насколько дольше висит в центре.
		Effects = {
			Common = { Burst = 10 },
			Uncommon = { Burst = 18, Ring = true },
			Rare = { Burst = 28, Ring = true, Rays = 6, Shake = 0.08 },
			Epic = { Burst = 40, Ring = true, Rays = 8, Stars = true, Shake = 0.14, HoldExtra = 0.1 },
			Legendary = { Burst = 60, Ring = true, Rays = 12, Stars = true, Confetti = 40, Shake = 0.24, Flash = 0.45, HoldExtra = 0.2 },
			Mythic = { Burst = 90, Ring = true, Rays = 16, Stars = true, Confetti = 70, Shake = 0.34, Flash = 0.6, Rainbow = true, HoldExtra = 0.35 },
		},
		-- v20.38: ПОЛОСКИ ЗА КАРТОЧКОЙ — у каждой редкости свои (картинки из
		-- UiTheme.Backdrops). Слои рисуются друг за другом: Kind — картинка,
		-- Spin — скорость вращения (рад/с, минус — в другую сторону), Scale —
		-- размер слоя относительно основного. Цвет — цвет редкости.
		-- Ударная волна (Ring) — тоже полоски первого слоя, расходятся и гаснут.
		Backdrops = {
			Common    = { { Kind = "RaysSoft", Spin = 0.5 } },
			Uncommon  = { { Kind = "Rays", Spin = 0.7 } },
			Rare      = { { Kind = "Rays", Spin = 0.9 }, { Kind = "RaysSoft", Spin = -0.6, Scale = 0.8 } },
			Epic      = { { Kind = "Epic2", Spin = 0.9 }, { Kind = "RaysSoft", Spin = -0.5, Scale = 1.2 } },
			Legendary = { { Kind = "Epic2", Spin = 1.1 }, { Kind = "Rays", Spin = -0.7, Scale = 1.3 } },
			Mythic    = { { Kind = "Rarest", Spin = 1.2 }, { Kind = "Epic2", Spin = -0.8, Scale = 1.35 } },
		},
	},

	-- Выброс руды игроком на Backspace (см. MineService:ThrowOreToGround).
	-- v20.63: выброшенная руда не притягивается магнитом и тележкой -
	-- подбирается только наступив (DropStepRadius стадов по горизонтали).
	-- Бросивший не может поднять свой кусок DropSelfPickupDelay секунд.
	DropSelfPickupDelay = 10,
	DropStepRadius = 2.5,
	DropThrowDistance = 7,
	DropThrowSeconds = 0.6,
	DropThrowArcHeight = 6,

	-- v20.60: руда из шахты раздувается на 50% меньше (было 2.6) и
	-- садится к обычному размеру плавно, с лёгкой пружинкой.
	CutsceneOreScale = 1.0, -- v20.63: руда при выпадении больше не увеличивается
	CutsceneOreShrinkSeconds = 0.75,

	-- Руда слегка ЛЕВИТИРУЕТ над землёй и покачивается — так она читается
	-- как "добыча", а не как валяющийся камень, и её видно поверх травы.
	OreHoverHeight = 1.6,
	OreHoverBob = 0.35,          -- амплитуда покачивания вверх-вниз, студ
	OreHoverBobSeconds = 2.2,    -- период покачивания

	-- Точка падения руды сдвигается В СТОРОНУ БАНКА от центра участка —
	-- камера на выбросе стоит именно с той стороны, и без сдвига куча
	-- ложилась бы у неё за спиной.
	DropTowardBankStuds = 10, -- больше не используется: руда падает у выхода шахты (см. EjectLand* ниже)

	-- КУДА ПАДАЕТ РУДА: сектор перед дверью шахты (по прямому запросу —
	-- "ближе к выходу шахты, но не совсем близко"). Расстояния — в стадах
	-- от двери, разлёт — в градусах в каждую сторону от направления наружу.
	EjectLandMinDistance = 10,
	EjectLandMaxDistance = 22,
	EjectLandSpreadDegrees = 55,
	-- ...но по умолчанию руда летит К КАМЕРЕ и падает почти перед ней (по
	-- прямому запросу). Gap — сколько стадов от объектива до центра кучи,
	-- Spread — разброс вбок и в глубину. false вернёт сектор у выхода.
	EjectLandInFrontOfCamera = true,
	EjectLandCameraGap = 16,
	EjectLandCameraSpreadSide = 7,
	EjectLandCameraSpreadDepth = 4,
	-- v9: разброс с минимальной дистанцией (ярлыки шансов не слипаются).
	EjectLandMinGap = 4.5,        -- стадов между кусками (по ширине кадра)
	EjectLandDepthWeight = 0.7,   -- по глубине кадра дистанция «весит» меньше
	EjectLandMaxSpreadSide = 16,  -- куча растёт с числом руды, но не шире этого
	EjectLandMaxSpreadDepth = 9,

	-- Тряска куска в момент раскрытия.
	RevealShakeStuds = 0.22,
	RevealShakeSeconds = 0.35,

	-- ШАГ 5: нырок камеры к земле + очередность вылета руды.
	-- По прямому запросу ("по таймингам беда... сначала вылетает первая
	-- руда, потом две секунды ожидание и следующие вылетают, и редкость
	-- проявляется только тогда, когда выявляется следующая руда") —
	-- батчи (1 центральная → пара сбоку → волны по WaveSize) идут строго
	-- ПОСЛЕДОВАТЕЛЬНО с одной и той же паузой BatchGapSeconds между ними,
	-- и каждый батч раскрывается (снимает "чёрную скорлупу") РОВНО в
	-- момент, когда вылетает следующий — см. MineService:_ejectOre.
	CameraDiveSeconds = 0.9,
	BatchGapSeconds = 2,
	WaveSize = 3,
	-- v20.111: ВЫЛЕТ ПО РЕДКОСТИ (Б). Обычная руда высыпается быстро одной
	-- пачкой (шаг QuickStaggerSeconds) и раскрывается сразу; руда редкости
	-- DramaRarity и выше вылетает ПОСЛЕДНЕЙ, по одной, от менее редкой к
	-- самой редкой: пауза DramaPauseSeconds, вылет, приземление, вспышка
	-- цветом редкости, звук; Epic+ - тряска камеры, Legendary+ - лучи и
	-- надпись редкости над куском, вспышка экрана. false - старый порядок.
	RarityOrderEject = true,
	DramaRarity = "Rare",
	DramaAlwaysLast = true,     -- самая редкая руда пачки - всегда финал, даже Common
	QuickStaggerSeconds = 0.12,
	DramaPauseSeconds = 0.9,
	DramaLabelRarity = "Legendary",
	-- v20.111: ПРИЗЕМЛЕНИЕ (В): 1-2 настоящих отскока (высота в долях
	-- размера куска), облачко земли из стадов и мелкие камешки.
	LandingHops = { 0.9, 0.35 },
	LandingDirtCubes = 6,
	LandingPebbles = 4,
	LandingDirtColor = Color3.fromRGB(120, 85, 55),
	-- ПО ПРЯМОМУ ЗАПРОСУ ("сильнее раскидывались", "появлялись сто
	-- процентов на земле", "крутились на месте когда выпали", "будто мячи
	-- волейбольные с трейлом") — дуга выше и дальше, разброс намного шире,
	-- полёт чуть дольше (иначе с таким разбросом камни выглядели бы
	-- слишком быстрыми), плюс TrailEjectWidth/EjectSpinAfterLanding ниже.
	EjectArcHeight = 14, -- было 9
	EjectFlightSeconds = 0.85, -- было 0.65

	-- "ПЛЕВОК" ШАХТЫ (по прямому запросу): руда становится крупнее в
	-- момент вылета из шахты, а после — уменьшается обратно, как будто её
	-- выплюнуло. Действует ТОЛЬКО на настоящий вылет из шахты (см. flyOre,
	-- параметр spitPop) — на выброс руки игроком (Backspace) не влияет.
	-- ВЫКЛЮЧЕНО: теперь "плюётся" сама ШАХТА (MineSpit* выше), а руда
	-- летит своим обычным размером. true вернёт старое раздувание руды
	-- поверх плевка шахты.
	EjectOreSpitPop = false,
	EjectSpitPopMultiplier = 1.35, -- во сколько раз крупнее на пике
	EjectSpitPopSeconds = 0.3,     -- сколько длится весь всплеск туда-обратно
	EjectScatterRadius = 20, -- было 10 — разлёт заметно шире
	-- Скорость непрерывного вращения уже приземлившейся руды (рад/сек) —
	-- "крутились на месте когда выпали", см. общий Heartbeat-вращатель в
	-- MineService:Init (крутит всё, что лежит в workspace.MineGroundOre
	-- с атрибутом Landed=true, пока не подобрано).
	EjectSpinAfterLanding = 1.6,
	-- v20.114: ВСЯ РУДА В КАДРЕ - если кусок (в полёте или на земле) вышел
	-- за край кадра (отступ EjectFitMargin, доля экрана), камера выброса
	-- плавно отъезжает назад (до EjectFitMaxBack стадов).
	ActorStraightPath = true,   -- v20.118: вход/выход из шахты строго по прямой (без подпрыгиваний)
	EjectFitToScreen = true,
	EjectFitMargin = 0.08,
	EjectFitMaxBack = 45,
	EjectFitGrow = 30,          -- стадов/с, пока что-то вне кадра
	EjectFitSpeed = 4,          -- сглаживание отъезда
	-- v20.114: ПРИЗЕМЛЕНИЕ «ПО ФИЗИКЕ»: после отскоков кусок плавно
	-- заваливается и просто лежит на земле (без резкого подъёма в
	-- левитацию и без вращения). false - как раньше (висит и крутится).
	LandedRest = true,
	LandedRestTilt = 18,        -- случайный наклон лежащего куска, градусы
	-- Трейл во время полёта (см. flyOre) — толщина у начала/конца
	-- (Attachment0/1 разнесены по высоте камня) и время жизни хвоста.
	EjectTrailWidth = 0.6,
	EjectTrailLifetime = 0.4,
	-- Пока камень летит — он "заспойлерен": чёрный, без надписи шанса.
	-- Через RevealDelaySeconds ПОСЛЕ приземления ВСЕЙ пачки камера чуть
	-- отъезжает (см. RevealCameraBackOffset) и все камни разом раскрываются
	-- (настоящий цвет/материал + билборд шанса) — см. ТЗ.
	RevealDelaySeconds = 0.35,
	RevealCameraBackOffset = 6,
	RevealTweenSeconds = 0.4,
}

-- ЦВЕТ ВОРОТ ШАХТЫ (MineDoor, см. ТЗ) ПО РЕДКОСТИ САМОЙ ЦЕННОЙ руды в
-- выбитой пачке. Часть MineDoor получает Enum.Material.Neon + этот Color,
-- и КАЖДЫЙ VFX-attachment под MineDoor, чьё имя начинается с "VFX_" + это
-- имя редкости (например "VFX_Legendary"), включается (Enabled = true);
-- все остальные "VFX_*" — выключаются. Так билдер может положить под
-- MineDoor сколько угодно ParticleEmitter/Beam-attachment-ов на каждую
-- редкость, ничего не программируя.
Config.MineDoorRarityColor = {
	Common = Color3.fromRGB(180, 185, 195),
	Uncommon = Color3.fromRGB(80, 220, 120),
	Rare = Color3.fromRGB(70, 140, 255),
	Epic = Color3.fromRGB(190, 90, 255),
	Legendary = Color3.fromRGB(255, 70, 70),
}

--------------------------------------------------------------------------------
-- ОФЛАЙН-ШАХТА: ТЕЛЕЖКА, ЗАБИТАЯ РУДОЙ, ПОКА ИГРОКА НЕ БЫЛО
--
-- ГЛАВНОЕ РЕШЕНИЕ: офлайн даёт РУДУ, А НЕ ДЕНЬГИ. Тележка стоит на своей
-- обычной парковке уже наполненной — но деньги игрок всё равно зарабатывает
-- сам: руду надо довезти до банка, не потеряв её по дороге в PvP. Комбо-
-- множитель тоже считается только при реальной доставке (см. CartService.
-- comboMultiplier). Поэтому эта механика физически НЕ МОЖЕТ работать как
-- второй сейф — она даёт сырьё, а не результат.
--
-- ПОЧЕМУ ПОТОЛОК — РОВНО ОДНА ТЕЛЕЖКА. Шахта очень быстрая: полная тележка
-- набирается за 1.4 мин на T5 и за 4.3 мин на T10 (Capacity × SpawnInterval).
-- Любой накопитель большего размера заполнялся бы за 10-20 минут отсутствия
-- и всегда был бы полным — то есть перестал бы быть таймером вообще. Одна
-- тележка — это честный «подарок за возвращение» на 1-4 минуты игры, и она
-- принципиально не способна сдвинуть экономику (ребёрт стоит 17-110 полных
-- тележек, см. Config.Rebirth).
--
-- Хочешь сделать щедрее — поднимай Rate, а не потолок: потолок и есть то,
-- что защищает баланс.
--------------------------------------------------------------------------------
Config.OfflineCart = {
	Enabled = true,

	-- v20.9: ЧТО ВЫДАЁТСЯ ЗА ОФЛАЙН. "Money" — просто немного денег сразу
	-- на счёт (руда, высыпанная в тележку разом, давала лаг на заходе);
	-- "Ore" — старая схема с рудой в тележке (настройки ниже).
	Mode = "Money",
	-- Деньги = активный доход в минуту (Config.IncomePerMinute по текущим
	-- тирам шахты и тележки, × множитель ребёртов/перков) × минуты офлайна ×
	-- MoneyRate. 0.05 = 5% от активной игры: час отсутствия ≈ 3 минуты
	-- игры, потолок MaxMoneySeconds (6 ч) ≈ 18 минут игры. Сейф подиума
	-- копит отдельно, как и раньше.
	MoneyRate = 0.05,
	MaxMoneySeconds = 6 * 60 * 60,

	-- Скорость шахты, пока игрока нет, в долях от обычной. 0.4 = 40%.
	-- На T5 (1.39 сек/кристалл) полная тележка на 60 мест наберётся за
	-- 60 × 1.39 / 0.4 ≈ 3.5 минуты отсутствия.
	Rate = 0.4,

	-- Меньше этого времени отсутствия офлайн-добыча не начисляется ВООБЩЕ.
	-- Без этого порога перезаход раз в минуту был бы выгоднее, чем игра:
	-- вышел-зашёл — и тележка снова полная.
	MinOfflineSeconds = 300, -- 5 минут

	-- Дальше этого времени накопление не идёт. Формально избыточно (потолок
	-- и так — вместимость тележки), но оставлено явно: если однажды решишь
	-- поднять потолок выше одной тележки, именно это число не даст
	-- вернувшемуся через месяц игроку получить склад руды.
	MaxOfflineSeconds = 12 * 60 * 60,

	-- Какую долю ВМЕСТИМОСТИ тележки максимум может занять офлайн-руда.
	-- 1.0 = тележка полная. Ставь 0.7, если хочешь, чтобы игрок всё равно
	-- постоял у шахты пару секунд перед выездом.
	MaxFillPercent = 1.0,
}

Config.Goblins = {
	-- Загрузи изображение гоблина в Roblox и вставь сюда rbxassetid://ID.
	-- Пустое значение оставляет в билборде нейтральный силуэт-заглушку.
	IconImage = "rbxassetid://85181849716719",
	-- ВНИМАНИЕ: WaveMinDelay/WaveMaxDelay в коде НЕ используются нигде (см.
	-- grep по проекту) — это мёртвые поля, оставшиеся от старой схемы
	-- "случайная задержка между волнами". Реальный таймер задаёт ТОЛЬКО
	-- WaveInterval, поэтому менять надо именно его.
	WaveMinDelay = 180,
	WaveMaxDelay = 180,
	-- Пауза между волнами в секундах. Отсчёт стартует НЕ с момента спавна, а
	-- с момента, когда убит ПОСЛЕДНИЙ гоблин прошлой волны (см.
	-- GoblinService:_removeGoblin → state.NextWaveAt), плюс тик проверки раз
	-- в секунду в SetupPlayer. Было 180 (раз в 3 минуты) — по прямому
	-- запросу чуть пореже, 240 (раз в 4 минуты).
	WaveInterval = 240,
	TutorialDelayAfterFirstOre = 3,
	TutorialWaveCount = 1,
	AttackRadius = 30,
	-- ПОВОДОК. Раньше его не было вовсе: агро считается по расстоянию от
	-- самого гоблина, поэтому игрок мог бесконечно "тянуть" гоблина за
	-- собой — тот держался в пределах AttackRadius от игрока и бежал за ним
	-- хоть через всю карту, навсегда покидая свою зону.
	-- LeashRadius — предел удаления от ЗОНЫ (ZoneCenter), после которого
	-- гоблин бросает погоню и возвращается. Чуть больше AttackRadius, чтобы
	-- он мог "капельку" выйти за зону, но не более того.
	LeashRadius = 42,
	-- Вернувшись, гоблин снова начинает реагировать на игроков только когда
	-- подошёл к зоне ближе этого радиуса — гистерезис, чтобы он не дёргался
	-- "погоня/возврат" на самой границе поводка.
	LeashReturnRadius = 12,
	-- Золотой гоблин — страж разбитого валуна: его задача отбиваться от
	-- игроков на месте, а не убегать. Поводок заметно короче обычного.
	EliteLeashRadius = 22,
	EliteLeashReturnRadius = 8,
	-- МЁРТВЫЕ ПОЛЯ (проверено grep по всему проекту): BaseStealCount и
	-- SeparationStrength не читаются нигде. Оставлены, чтобы не ломать
	-- чужие правки конфига, но крутить их бессмысленно — реально работают
	-- MaxStealCount и SeparationRadius.
	SpawnSpacing = 16,
	PlayerAttackRadius = 8,
	ObjectiveInteractRadius = 7,
	-- Сколько раз contested-гоблин (тележку уже держит ДРУГОЙ гоблин, эту
	-- у него не отобрать) пробует украсть из неё оставшуюся руду напрямую,
	-- прежде чем сдаться. Без предела гоблин мог бегать к тележке и обратно
	-- бесконечно, ни разу не завершив цель (см. GoblinService:_finishObjective).
	MaxContestedStealAttempts = 3,
	SeparationRadius = 7,
	SeparationStrength = 5,
	CarryCartOffset = CFrame.new(0, -1.35, 8),
	-- Если тележка после замены плейсхолдера едет "не той" стороной вперёд —
	-- поменяй знак/добавь поворот сюда, например
	-- CFrame.new(0, -1.35, 5) * CFrame.Angles(0, math.rad(180), 0).
	AttackWindup = 0.22,
	HitStunDuration = 2.0, -- было 1.0 — по прямому запросу стан гоблина увеличен примерно в два раза
	-- ЖИЗНЬ ВОЛНЫ. Это поле НИГДЕ не читалось — гоблины жили вечно, пока их
	-- не убьют. Теперь GoblinService:SpawnWave его использует:
	--   0  = выключено, прежнее поведение (гоблин ждёт, пока его убьют);
	--   >0 = через столько секунд недобитый гоблин уходит сам.
	-- Оставлено в 0, чтобы ничего не поменялось молча — прежнее задуманное
	-- значение было 35. Гоблина, уже утащившего тележку, таймер не трогает.
	WaveLifetime = 0,
	StealCooldown = 3,
	SlowdownDuration = 30,
	SlowdownMin = 0.25,
	SlowdownMax = 0.40,
	BaseWalkSpeed = 9,
	DamageMultiplier = 1.5,
	BaseStealCount = 1,
	MaxStealCount = 7,
	RewardPerTier = 10000, -- legacy, v3 не используется (см. RewardCarts)
	-- v3: деньги из сундука гоблина = доля полной тележки пещеры этого тира
	-- (Config.CartValue), случайно в [Min, Max]. Фолбэк (жеода/скин не выдались) — Fallback.
	RewardCarts = { Min = 0.4, Max = 0.9, Fallback = 0.5 },
	-- Блуждание по зоне, пока никто не в радиусе атаки — вместо жёсткого
	-- возврата в ZoneCenter. WanderInterval — как часто выбирать новую
	-- случайную точку (секунды); WanderRadius = 0 значит "тот же радиус,
	-- что и AttackRadius" (см. использование в GoblinService).
	WanderInterval = 6,
	WanderRadius = 8,
	-- Удар → отход → снова удар, когда откатится кулдаун (см. п.2 дизайна).
	-- RetreatDuration не заводим отдельным полем — переиспользуем
	-- StealCooldown напрямую в коде, чтобы отход длился ровно столько же,
	-- сколько кулдаун удара (иначе легко рассинхронизировать при правке
	-- баланса в будущем).
	RetreatDistance = 6,
	-- Насколько медленнее гоблин ходит, пока несёт украденную тележку
	-- (множитель к WalkSpeed, 0.85 = на 15% медленнее).
	CartCarrySlowdownMultiplier = 0.85,
	-- Скорость сглаживания следования тележки за гоблином каждый кадр
	-- (Heartbeat) — чем больше число, тем быстрее тележка "нагоняет" цель.
	-- Раньше тележка телепортировалась на новую позицию раз в 0.35с (тик
	-- AI) — отсюда были рывки; теперь позиция плавно тянется каждый кадр.
	CartFollowSmoothing = 10,
	Animations = {
		-- Вставь опубликованные animation IDs. Нулевые ID безопасно отключены.
		Idle = 90666608813290,
		Walk = 72147126221056,
		-- v20.44: необязательные (0 — нет). Своя анимация главнее: папка
		-- Animations внутри модели гоблина (Animation: Idle, Walk, Run,
		-- Attack1..3, Hit, Stun, Death). Death держит последний кадр.
		Run = 0,
		Hit = 0,
		Stun = 0,
		Death = 0,
		Attacks = { 88115464228798, 84821580919778, 130751263844103 }, -- проигрываются строго 1 -> 2 -> 3 -> 1
	},
	Types = {
		-- БАЛАНС: все четыре типа ослаблены примерно на 15% по HP и на 13-15%
		-- по урону относительно прежних значений (закомментированы рядом,
		-- чтобы откатить было одной правкой). Формулы не менялись: итоговое
		-- HP = Health + tier * HealthPerTier, урон = Damage + tier *
		-- DamagePerTier — ослаблены ОБА слагаемых, иначе на высоких тирах
		-- ослабление почти не чувствовалось бы.
		Warrior = {
			DisplayName = "Goblin Warrior", MinMineTier = 1, MaxMineTier = 6,
			-- было: Health = 18, HealthPerTier = 6, Damage = 8, DamagePerTier = 1.0
			Health = 15, HealthPerTier = 5, Damage = 7, DamagePerTier = 0.85,
			Size = 1.00, StealCount = 0, Slowdown = 0.25, SlowdownDuration = 30,
			Objective = "Mine", CanStealCart = false, Color = Color3.fromRGB(210, 70, 70), Weight = 45,
		},
		Thief = {
			DisplayName = "Goblin Thief", MinMineTier = 2, MaxMineTier = 7,
			-- было: Health = 26, HealthPerTier = 14, Damage = 6, DamagePerTier = 0.7
			Health = 22, HealthPerTier = 12, Damage = 5.2, DamagePerTier = 0.6,
			Size = 0.94, StealCount = 1, Slowdown = 0.28, SlowdownDuration = 34,
			Objective = "Cart", CanStealCart = false, Color = Color3.fromRGB(220, 175, 55), Weight = 30,
		},
		Berserker = {
			DisplayName = "Goblin Barbarian", MinMineTier = 4, MaxMineTier = 9,
			-- было: Health = 56, HealthPerTier = 22, Damage = 10, DamagePerTier = 1.1
			Health = 48, HealthPerTier = 19, Damage = 8.5, DamagePerTier = 0.95,
			Size = 1.12, StealCount = 1, Slowdown = 0.34, SlowdownDuration = 42,
			Objective = "Cart", CanStealCart = true, Color = Color3.fromRGB(170, 95, 45), Weight = 18,
		},
		King = {
			DisplayName = "Goblin King", MinMineTier = 6, MaxMineTier = 9,
			-- было: Health = 150, HealthPerTier = 30, Damage = 13, DamagePerTier = 1.4
			Health = 128, HealthPerTier = 26, Damage = 11, DamagePerTier = 1.2,
			Size = 1.28, StealCount = 3, Slowdown = 0.40, SlowdownDuration = 55,
			Objective = "Cart", CanStealCart = true, Color = Color3.fromRGB(165, 80, 210), Weight = 7,
		},
		-- "Золотой" элитный гоблин с валуна — своя запись в энциклопедии
		-- (см. MutationBookService:RecordMobFound), с повышенным уроном
		-- относительно короля (SpawnEliteForBoulder всё равно удваивает HP отдельно).
		-- MinMineTier/MaxMineTier = 11 (за пределами реального диапазона
		-- 1-10) + Weight = 0 — гарантируют, что chooseGoblinType (обычные
		-- волны) никогда его не выберет: спавнится ТОЛЬКО через разрушение
		-- золотого валуна, никогда как часть обычной волны.
		Golden = {
			DisplayName = "Golden Goblin King", MinMineTier = 11, MaxMineTier = 11,
			-- ВНИМАНИЕ, число ниже — НЕ итоговый урон. Обычные типы получают
			-- в GoblinStats.Damage дополнительный x1.25, а Golden — нет.
			-- Поэтому по факту золотой бьёт сильнее короля не на 50%, а на
			-- ~20%: (16.5 + t*1.8) * 1.5 против (11 + t*1.2) * 1.25 * 1.5.
			-- На тире 10 это 51.8 против 43.1. Хотите ровно +50% — ставьте
			-- Damage = 20.6, DamagePerTier = 2.25.
			-- На обычные волны это не влияет (Weight = 0).
			-- SpawnEliteForBoulder всё равно удваивает HP сверх этого.
			Health = 128, HealthPerTier = 26, Damage = 16.5, DamagePerTier = 1.8,
			Size = 1.28, StealCount = 3, Slowdown = 0.40, SlowdownDuration = 55,
			-- Objective = "Guard": золотой гоблин НЕ ворует тележку и никуда
			-- не уходит — он охраняет место разбитого валуна и дерётся с
			-- игроками, которые к нему подошли. Раньше здесь стояло
			-- Objective = "Cart" + CanStealCart = true (наследство от копии
			-- статов короля), из-за чего страж валуна, победив игрока,
			-- убегал через полкарты воровать тележку и тащить её в банк —
			-- то есть вёл себя как обычный гоблин-вор, а не как босс.
			Objective = "Guard", CanStealCart = false, Color = Color3.fromRGB(255, 200, 60), Weight = 0,
		},
	},
	-- Шансы наград за убитого гоблина по тиру шахты. КАЖДАЯ строка обязана
	-- давать в сумме ровно 1.00 — в _rewardGoblin бросок math.random()
	-- сравнивается с Money, затем Money+Geode, а всё остальное уходит в
	-- Skin, так что недобор/перебор молча перекосит шансы скина.
	-- Тиры 9-10 добавлены вслед за поднятием Rebirth.MaxTierCap с 8 до 10:
	-- раньше таблица заканчивалась на 8, а код клампил тир к восьмёрке, из-за
	-- чего гоблины T9/T10 выдавали шансы уровня T8 (недобор скинов и жеод на
	-- самом дорогом контенте). Кривая продолжена как есть: Money -0.04 за
	-- тир, Skin +0.02, Geode добирает остаток до 1.00.
	RewardOddsByTier = {
		[1] = { Money = 0.78, Geode = 0.20, Skin = 0.02 },
		[2] = { Money = 0.75, Geode = 0.22, Skin = 0.03 },
		[3] = { Money = 0.72, Geode = 0.24, Skin = 0.04 },
		[4] = { Money = 0.68, Geode = 0.27, Skin = 0.05 },
		[5] = { Money = 0.64, Geode = 0.30, Skin = 0.06 },
		[6] = { Money = 0.60, Geode = 0.33, Skin = 0.07 },
		[7] = { Money = 0.56, Geode = 0.36, Skin = 0.08 },
		[8] = { Money = 0.52, Geode = 0.38, Skin = 0.10 },
		[9] = { Money = 0.48, Geode = 0.40, Skin = 0.12 },
	},
}

-- Тир шахты меняет стоимость и внешний вид кристалла. Multiplier задаёт
-- simulator-кривую дохода от $1K на T1 до $650M на T10.
-- ГЛОБАЛЬНЫЙ МАСШТАБ ЭКОНОМИКИ. Раньше базовое значение (1000) в паре с
-- ростом Multiplier по тирам руды (см. ниже) и комбо-множителем тележки
-- (до x260 на 100% заполнении тира 10, см. Config.Cart.ComboThresholds)
-- уводило доход полностью гружёной тележки в АБСУРДНЫЕ числа — тир 10
-- давал 38 ТРИЛЛИОНОВ за рейс. "Очень много денег" перестаёт ощущаться
-- как деньги, когда на экране трейлится 15-значное число.
--
-- 1000 → 10 (÷100) сжимает ВСЮ кривую пропорционально, не трогая сами
-- Multiplier (флейвор "во сколько раз эта руда ценнее угля" остаётся тем
-- же) и не трогая комбо-таблицу — только общий масштаб чисел на экране.
-- Результат по факту полной тележки на 100% заполнении, до Rebirth-бонусов:
--   T1  ≈ $480         (сотни)
--   T3  ≈ $36,000       (десятки тысяч)
--   T5  ≈ $3,750,000     (миллионы, середина прогрессии)
--   T7  ≈ $420,000,000    (сотни миллионов)
--   T10 ≈ $380,250,000,000 (очень много денег — большое, но ещё осмысленное число)
-- ЭКОНОМИКА v3 (ребаланс "цифры слишком большие"): база 1, цены руды —
-- прямо в Multiplier (Coal $2 … Singularity $2000, шаг ~×1.5 на руду).
-- Итог без ребёрт-бонусов: первая тележка ≈ $110, топовая пещера ≈ $250K.
Config.Crystal_BaseValue = 1

-- Points — ОТДЕЛЬНАЯ от денег шкала "ценности" руды для комбо-множителя
-- тележки (см. Config.Cart.ComboThresholds ниже). Специально нелинейная и
-- ускоряющаяся, как и денежный Multiplier, но не обязана с ним совпадать —
-- можно менять "вес" одной руды в комбо, не трогая её цену, и наоборот.
-- Разброс между тиром 1 и тиром 8 НАМЕРЕННО умеренный (не x95, как цена) —
-- иначе при формуле effectiveFill = rawFill × Points/ComboReferencePoints
-- дешёвая руда вообще не набирает ComboMinFill ни при каком заполнении,
-- а дорогая улетает в потолок раньше 60%. Текущий разброс (17..63, ×3.7)
-- откалиброван так, что на 60% заполнения тир 1 даёт x2, тир 8 — ~x35.
--------------------------------------------------------------------------------
-- РУДА v2 — ПОЛНЫЙ РЕДИЗАЙН (см. ТЗ "переписать систему механики сбора руды").
--
-- Раньше: 1 тир шахты = 1 фиксированная руда. Теперь: 15 тиров шахты, у
-- КАЖДОГО тира — окно из 4 доступных руд (скользящее окно по 18-позиционной
-- цепочке ниже): 3 руды "унаследованы" от предыдущего тира, 1 новая
-- добавляется, самая старая (пятая по счёту назад) выходит из пула. Именно
-- так, как описано в ТЗ таблицей тиров (Coal/Copper/Quartz/Amber → ... →
-- Singularity).
--
-- Config.OreChain — мастер-список всех руд по порядку появления (позиция в
-- массиве = порядок "возраста"). Все геймплейные и денежные параметры руды
-- живут здесь ОДИН раз.
--------------------------------------------------------------------------------
Config.OreChain = {
	{ Key = "Coal",        DisplayName = "Coal", Description = "A humble fuel ore that starts every miner's journey.",        Rarity = "Common",    Multiplier = 2,     Color = Color3.fromRGB(90, 90, 95),    Size = 1.00, Points = 17 },
	{ Key = "Copper",      DisplayName = "Copper", Description = "A warm metal ore prized by growing mining camps.",      Rarity = "Common",    Multiplier = 3,     Color = Color3.fromRGB(205, 120, 70),  Size = 1.05, Points = 19 },
	{ Key = "Quartz",      DisplayName = "Quartz", Description = "A clear crystal that catches every stray torchlight.",      Rarity = "Common",    Multiplier = 5,     Color = Color3.fromRGB(225, 225, 235), Size = 1.10, Points = 21 },
	{ Key = "Amber",       DisplayName = "Amber", Description = "Fossilised resin holding secrets older than the mine.",       Rarity = "Common",    Multiplier = 7,    Color = Color3.fromRGB(235, 190, 80),  Size = 1.15, Points = 23 },
	{ Key = "Iron",        DisplayName = "Iron", Description = "The dependable backbone of every serious operation.",        Rarity = "Common",    Multiplier = 10,    Color = Color3.fromRGB(160, 165, 175), Size = 1.20, Points = 25 },
	{ Key = "Silver",      DisplayName = "Silver", Description = "A bright metal that never quite loses its shine.",      Rarity = "Uncommon",  Multiplier = 15,    Color = Color3.fromRGB(200, 205, 215), Size = 1.26, Points = 28 },
	{ Key = "Gold",        DisplayName = "Gold", Description = "A brilliant ore that turns any cart into treasure.",        Rarity = "Uncommon",  Multiplier = 23,    Color = Color3.fromRGB(255, 220, 100), Size = 1.32, Points = 31 },
	{ Key = "Emerald",     DisplayName = "Emerald", Description = "A deep green gem formed under immense pressure.",     Rarity = "Uncommon",  Multiplier = 35,   Color = Color3.fromRGB(70, 225, 130),  Size = 1.38, Points = 35 },
	{ Key = "Ruby",        DisplayName = "Ruby", Description = "A living red crystal said to pulse underground.",        Rarity = "Rare",      Multiplier = 50,   Color = Color3.fromRGB(230, 60, 80),   Size = 1.44, Points = 38 },
	{ Key = "Sapphire",    DisplayName = "Sapphire", Description = "A cool blue gem cut from the deepest seams.",    Rarity = "Rare",      Multiplier = 75,   Color = Color3.fromRGB(70, 130, 255),  Size = 1.50, Points = 42 },
	{ Key = "Amethyst",    DisplayName = "Amethyst", Description = "A violet crystal carrying a calm ancient glow.",    Rarity = "Rare",      Multiplier = 115,   Color = Color3.fromRGB(190, 105, 255), Size = 1.56, Points = 47 },
	{ Key = "Obsidian",    DisplayName = "Obsidian", Description = "Volcanic glass with an edge sharper than steel.",    Rarity = "Epic",      Multiplier = 170,  Color = Color3.fromRGB(45, 40, 60),    Size = 1.62, Points = 52 },
	{ Key = "Platinum",    DisplayName = "Platinum", Description = "A rare white metal that resists almost everything.",    Rarity = "Epic",      Multiplier = 260,  Color = Color3.fromRGB(230, 235, 240), Size = 1.68, Points = 57 },
	{ Key = "Mythril",     DisplayName = "Mythril", Description = "A legendary alloy lighter than air and twice as strong.",     Rarity = "Epic",      Multiplier = 390,  Color = Color3.fromRGB(110, 255, 220), Size = 1.74, Points = 63 },
	{ Key = "Voidstone",   DisplayName = "Voidstone", Description = "A dense shard that seems to swallow nearby light.",   Rarity = "Legendary", Multiplier = 580, Color = Color3.fromRGB(70, 25, 100),   Size = 1.80, Points = 70 },
	{ Key = "Starshard",   DisplayName = "Starshard", Description = "A stellar fragment still burning with distant sunlight.",   Rarity = "Legendary", Multiplier = 870, Color = Color3.fromRGB(255, 240, 180), Size = 1.86, Points = 78 },
	{ Key = "Celestium",   DisplayName = "Celestium", Description = "Metal fallen from the sky, humming with cold energy.",   Rarity = "Legendary", Multiplier = 1300, Color = Color3.fromRGB(140, 200, 255), Size = 1.92, Points = 86 },
	{ Key = "Singularity", DisplayName = "Singularity", Description = "A point of impossible mass - the deepest prize of all.", Rarity = "Legendary", Multiplier = 2000, Color = Color3.fromRGB(20, 15, 30),    Size = 2.00, Points = 95 },
}
-- 18 руд в цепочке (ТЗ упоминало то 17, то поимённую таблицу на 18 — берём
-- таблицу как источник истины, она однозначна; если нужно ровно 17, скажи
-- какую руду убрать/слить, это одна строка).
-- v20: «БОЛЬШИЕ ЦИФРЫ» НА ВЕРХНИХ ТИРАХ. Начиная с руды From каждая
-- следующая дороже ещё в Growth раз сверх базовой кривой: последние
-- пещеры приносят миллионы. Цены пещер/тележки/кирки/престижа ниже
-- масштабируются тем же коэффициентом (Config.CaveNumberScale), поэтому
-- ТЕМП игры не меняется — растут только числа.
Config.NumberGrowth = { From = 5, Growth = 1.19 }
local function niceNumber(value)
	if value < 100 then return math.max(1, math.floor(value + 0.5)) end
	local step = 10 ^ (math.floor(math.log10(value)) - 1)
	return math.floor(value / step + 0.5) * step
end
Config.NiceNumber = niceNumber
function Config.OreNumberScale(index)
	local growth = Config.NumberGrowth
	return growth.Growth ^ math.max(0, (tonumber(index) or 1) - growth.From)
end
for index, info in ipairs(Config.OreChain) do
	info.Index = index
	info.BaseRarity = info.Rarity -- v20.109: «природная» редкость (переделка шахты)
	info.BaseMultiplier = info.Multiplier
	info.Multiplier = niceNumber(info.Multiplier * Config.OreNumberScale(index))
	info.CrystalValue = Config.Crystal_BaseValue * info.Multiplier
end

--------------------------------------------------------------------------------
-- ВАРИАЦИИ РУДЫ (по прямому запросу — "у каждой руды есть по 3
-- вариативности, 1/2/3; первая дешевле третьей, вторая дороже первой, но
-- не сильно; это всё будут меши в будущем").
--
-- Вариация — это НЕ отдельная руда: тир/пул/шансы самой руды не меняются
-- (см. Config.RollOreForTier), вариация роллится ОТДЕЛЬНО поверх уже
-- выпавшей руды и лишь домножает цену. Так 18 руд дают 54 визуально
-- разных камня, не раздувая таблицу тиров.
--
-- Множители намеренно близкие (1.0 / 1.25 / 1.6): по ТЗ "вторая дороже
-- первой, но не сильно". Веса — вариация 1 самая частая, 3 самая редкая,
-- чтобы третья ощущалась находкой.
--
-- МЕШИ: когда появятся модели, клади их в ReplicatedStorage/Assets с
-- именем "Crystal_<Ore>_V<N>" (например "Crystal_Iron_V3") — фабрика сама
-- их подхватит, см. PlaceholderFactory.OreCrystal. Пока таких ассетов
-- нет, берётся общий "Crystal_<Ore>", а вариация видна по подписи и
-- размеру камня (SizeScale ниже).
--------------------------------------------------------------------------------
-- v20.56: 4 вариации (I-IV). IV — самая редкая, крупная и дорогая.
-- Своя модель вариации: Assets/Crystal_<Руда>_V1..V4.
Config.OreVariants = {
	{ Variant = 1, DisplayName = "I",   ValueMultiplier = 1.00, SizeScale = 0.90, Weight = 58 },
	{ Variant = 2, DisplayName = "II",  ValueMultiplier = 1.25, SizeScale = 1.00, Weight = 29 },
	{ Variant = 3, DisplayName = "III", ValueMultiplier = 1.60, SizeScale = 1.12, Weight = 10 },
	{ Variant = 4, DisplayName = "IV",  ValueMultiplier = 2.20, SizeScale = 1.25, Weight = 3 },
}

-- Роллит вариацию (1/2/3) для уже выпавшей руды. Возвращает
-- (variantInfo, chanceFraction) — chanceFraction нужен, чтобы честно
-- перемножить его с шансом самой руды в надписи "1/N" над камнем.
function Config.RollOreVariant()
	local total = 0
	for _, variant in Config.OreVariants do
		total += variant.Weight
	end
	local roll = math.random() * total
	local acc = 0
	for _, variant in Config.OreVariants do
		acc += variant.Weight
		if roll <= acc then
			return variant, variant.Weight / total
		end
	end
	local last = Config.OreVariants[#Config.OreVariants]
	return last, last.Weight / total
end

Config.OreByKey = {}
for _, info in Config.OreChain do
	Config.OreByKey[info.Key] = info
end

--------------------------------------------------------------------------------
-- v17: МУСОР. С маленьким шансом вместо руды из шахты, валуна или жеоды
-- выпадает хлам: собачья кость, древние осколки, камень, банка колы,
-- резиновая утка. Стоит копейки или ничего. Ведёт себя как обычная руда
-- (летит в тележку/рюкзак, продаётся), но без мутаций, вариаций и книги
-- коллекции, в плавильню не берётся.
--
-- Chance — шанс, что КОНКРЕТНЫЙ кусок окажется мусором (на каждый кусок
-- отдельно). Value — цена в $ (0 = бесплатно). Weight — как часто этот
-- мусор среди мусора. Своя модель: ReplicatedStorage.Assets.Junk_<Key>
-- (Model с PrimaryPart или Part). Нет модели — простой плейсхолдер.
--------------------------------------------------------------------------------
Config.Junk = {
	Enabled = true,
	Chance = { Mine = 0.03, Boulder = 0.04, Geode = 0.04 },
	Items = {
		{ Key = "Junk_Rock",       DisplayName = "Plain Rock",     Value = 0, Weight = 30, Color = Color3.fromRGB(125, 120, 115), Description = "Just a rock. Truly remarkable." },
		{ Key = "Junk_ColaCan",    DisplayName = "Cola Can",       Value = 1, Weight = 25, Color = Color3.fromRGB(200, 30, 40),   Description = "Empty. Someone was thirsty down here." },
		{ Key = "Junk_DogBone",    DisplayName = "Dog Bone",       Value = 2, Weight = 20, Color = Color3.fromRGB(240, 232, 210), Description = "A good boy buried it here long ago." },
		{ Key = "Junk_AncientShards", DisplayName = "Ancient Shards", Value = 4, Weight = 15, Color = Color3.fromRGB(150, 175, 170), Description = "Broken pottery from a forgotten age." },
		{ Key = "Junk_RubberDuck", DisplayName = "Rubber Duck",    Value = 6, Weight = 10, Color = Color3.fromRGB(255, 215, 40),  Description = "Squeak." },
	},
}
Config.JunkByKey = {}
do
	local total = 0
	for _, item in Config.Junk.Items do total += item.Weight end
	for _, item in Config.Junk.Items do
		-- Поля «как у руды», чтобы весь конвейер руды принимал мусор как есть.
		item.Junk = true
		item.Index = 0 -- «дешевле» любой руды при сортировке
		item.Rarity = "Common"
		item.Multiplier = 0
		item.CrystalValue = item.Value
		item.Points = 0
		item.Size = 1
		item.Chance = item.Weight / math.max(1, total)
		Config.OreByKey[item.Key] = item
		Config.JunkByKey[item.Key] = item
	end
end

function Config.IsJunk(oreKey)
	return oreKey ~= nil and Config.JunkByKey[oreKey] ~= nil
end

-- source: "Mine" | "Boulder" | "Geode". Возвращает запись мусора или nil.
function Config.RollJunk(source)
	local cfg = Config.Junk
	if not (cfg and cfg.Enabled) then return nil end
	local chance = tonumber(cfg.Chance and cfg.Chance[source or "Mine"]) or 0
	if chance <= 0 or math.random() >= chance then return nil end
	local total = 0
	for _, item in cfg.Items do total += item.Weight end
	local roll = math.random() * total
	local acc = 0
	for _, item in cfg.Items do
		acc += item.Weight
		if roll <= acc then return item end
	end
	return cfg.Items[#cfg.Items]
end

--------------------------------------------------------------------------------
-- ПЕЩЕРЫ v3 (ребаланс): 15 пещер (под них уже есть модели Mine_Tier1..15).
-- Раньше ветка шахты кончалась на 9-м тире, и руды 13-18 не выпадали
-- никогда — теперь цепочка пещеры доходит до 15.
--
-- У каждой пещеры окно из 5 руд, сдвиг на 1 руду за пещеру: 4 руды
-- «наследуются» от прошлой пещеры, 1 новая добавляется. Пещера 14 = руды
-- 14..18. Пещера 15 — те же руды, что у 14-й, но с «богатыми» весами
-- (Config.TopCaveWeights): финальная пещера = заметно чаще редкие слоты.
--
-- РЕДКОСТЬ ПО СЛОТУ (выбор Ж2): редкость — это не свойство руды навсегда,
-- а то, насколько она редкая В ТЕКУЩЕЙ ПЕЩЕРЕ. Слот 1 (60%) — Common,
-- слот 5 (0.5%) — Legendary. В любой пещере с первой минуты видны все
-- цвета. Одна и та же руда в следующей пещере «дешевеет» по редкости —
-- это честно: для игрока с пещерой повыше она уже обыденная.
-- Mythic намеренно оставлен мутациям и жеодам.
--------------------------------------------------------------------------------
Config.OreTierWeights = { 60, 28, 9, 2.5, 0.5 }
Config.TopCaveWeights = { 40, 30, 18, 9, 3 } -- только для последней пещеры
Config.SlotRarities = { "Common", "Uncommon", "Rare", "Epic", "Legendary" }

Config.Mine.CaveCount = 15
Config.Mine.WindowStep = 1
-- Сколько руды вылетает за один заход в шахту (по пещере), 5 → 20.
Config.Mine.OreYieldByCave = { 5, 6, 7, 8, 9, 10, 11, 13, 14, 15, 16, 17, 18, 19, 20 }
Config.Mine.OreYieldByTier = { Min = 5, Max = 20 } -- совместимость, не используется

local function caveWindowStart(tier)
	local slots = #Config.OreTierWeights
	return math.min((tier - 1) * Config.Mine.WindowStep + 1, #Config.OreChain - slots + 1)
end

-- Средняя цена вариации (58/29/10/3 на I/II/III/IV) — нужна для честного
-- «среднего дропа» пещеры (им считаются цены апгрейдов, пассивка, награды).
local variantAverage = 0
do
	local totalWeight = 0
	for _, variant in Config.OreVariants do
		totalWeight += variant.Weight
		variantAverage += variant.ValueMultiplier * variant.Weight
	end
	variantAverage /= math.max(1, totalWeight)
end
Config.OreVariantAverage = variantAverage

Config.MineTiers = {}
for tier = 1, Config.Mine.CaveCount do
	local start = caveWindowStart(tier)
	local windowOres = {}
	for slot = 1, #Config.OreTierWeights do
		windowOres[slot] = Config.OreChain[start + slot - 1]
	end
	local weights = (tier == Config.Mine.CaveCount and Config.TopCaveWeights) or Config.OreTierWeights
	local weightTotal, expected, points, expectedBase = 0, 0, 0, 0
	for slot, weight in weights do
		weightTotal += weight
		expected += windowOres[slot].CrystalValue * weight
		expectedBase += Config.Crystal_BaseValue * (windowOres[slot].BaseMultiplier or windowOres[slot].Multiplier) * weight
		points += windowOres[slot].Points * weight
	end
	local newest = windowOres[#windowOres]
	Config.MineTiers[tier] = {
		Tier = tier,
		Ores = windowOres, -- [1]=Common 60% .. [5]=Legendary 0.5%
		Weights = weights,
		OreYield = Config.Mine.OreYieldByCave[tier] or Config.Mine.OreYieldByCave[#Config.Mine.OreYieldByCave],
		-- СРЕДНЯЯ цена одного куска руды пещеры (с вариациями, без мутаций
		-- и ребёртов). Раньше экономику считали по CrystalValue самой
		-- редкой руды окна — отсюда завышение дохода в 5-13 раз и цены,
		-- которые уходили в отрыв от реального заработка.
		ExpectedValue = expected / weightTotal * variantAverage,
		-- v20: во сколько раз доход пещеры вырос от Config.NumberGrowth.
		NumberScale = expected / math.max(1e-9, expectedBase),
		AveragePoints = points / weightTotal,
		-- Поля ниже — обратная совместимость (витрина тира = самая редкая руда окна).
		DisplayName = newest.DisplayName,
		Description = newest.Description,
		Rarity = Config.SlotRarities[#Config.SlotRarities],
		Multiplier = newest.Multiplier,
		Color = newest.Color,
		Size = newest.Size,
		Points = newest.Points,
		CrystalValue = newest.CrystalValue,
	}
end

-- Редкость руды oreKey в пещере mineTier (выбор Ж2 — по слоту окна).
-- Ниже окна → Common, выше окна → Legendary. Без mineTier — редкость по
-- «родной» пещере руды (где она впервые появляется самым редким слотом).
function Config.OreRarityFor(oreKey, mineTier)
	local ore = Config.OreByKey[oreKey]
	if not ore or ore.Junk then return "Common" end
	if Config.MineRework and Config.MineRework.Enabled and ore.BaseRarity then
		return ore.BaseRarity -- v20.109: редкость руды не зависит от пещеры
	end
	local tier = tonumber(mineTier)
	if not tier then
		return ore.Rarity or "Common"
	end
	tier = math.clamp(math.floor(tier), 1, #Config.MineTiers)
	local start = caveWindowStart(tier)
	local slot = ore.Index - start + 1
	if slot < 1 then return Config.SlotRarities[1] end
	if slot > #Config.SlotRarities then return Config.SlotRarities[#Config.SlotRarities] end
	return Config.SlotRarities[slot]
end

-- Статическая «родная» редкость руды (для мест без контекста пещеры):
-- слот, в котором руда стоит в первой пещере, где она появляется.
for _, info in Config.OreChain do
	local firstTier = 1
	for tier = 1, #Config.MineTiers do
		if caveWindowStart(tier) + #Config.OreTierWeights - 1 >= info.Index then
			firstTier = tier
			break
		end
	end
	info.Rarity = Config.OreRarityFor(info.Key, firstTier)
end

--------------------------------------------------------------------------------
-- v20.109: ПЕРЕДЕЛКА ШАХТЫ (7B). Руда больше НЕ привязана к пещере:
--   • сначала копаются только StarterOres (Coal, Copper - 2 руды x 4
--     вариации = 8 видов);
--   • новую руду покупают у торговца (вкладка ORE). Покупка - коробка в
--     инвентаре с превью руды; открыл - «New ore appeared in the mine!»,
--     руда добавлена в пул шахты (с повышенным шансом UnlockBoost), а
--     следующий заход в шахту гарантированно даёт её GuaranteedCount раз;
--   • улучшение шахты даёт только УДАЧУ (LuckPerCave за уровень) и больше
--     руды за заход (Config.Mine.OreYieldByCave);
--   • шанс руды = вес её природной редкости (Common 60 … Legendary 0.5),
--     внутри редкости новее - чуть реже (SameRarityDecay).
-- Enabled = false - старая система пещер. WipeVersion - поднять, чтобы
-- снова обнулить прогресс шахты у всех (уровень пещеры и купленные руды).
--------------------------------------------------------------------------------
Config.MineRework = {
	Enabled = true,
	-- v20.114: КОРОБКА РУДЫ. Купил у торговца - она в инвентаре; взял в руку -
	-- держишь над головой; клик - открыть: коробка трясётся, экран трясётся,
	-- над игроком реплика OpenLine, через OpenSeconds - карточка новой руды.
	OpenSeconds = 1.8,
	OpenLine = "what happened..?",
	OpenShake = 0.35,          -- сила тряски экрана
	OreBoxImages = {},         -- рисунок на коробке: { Coal = 1234567, ... }; нет - пиксельный самоцвет
	OreBoxOreOnTop = false,    -- true - ещё и руда сверху на коробке (как раньше)
	WipeVersion = 1,
	StarterOres = { "Coal", "Copper" },
	RarityWeights = { Common = 60, Uncommon = 28, Rare = 9, Epic = 2.5, Legendary = 0.5, Mythic = 0.2 },
	SameRarityDecay = 0.85,
	UnlockBoost = 2,       -- купленная руда выпадает в 2 раза чаще своей редкости
	-- v20.118: ПОВТОРНАЯ ПОКУПКА той же руды - она падает чаще, но мягко:
	-- каждая следующая коробка даёт меньше (RebuyBoost × RebuyDecay^(n-2)).
	-- 2 коробки ≈ x1.35, 3 ≈ x1.61, 5 ≈ x1.96, предел ≈ x2.4. MaxBuys - потолок.
	RebuyBoost = 0.35,
	RebuyDecay = 0.75,
	MaxBuys = 10,
	LuckPerCave = 0.15,    -- удача за уровень шахты: вес редкости × (1+удача)^(ступень редкости-1)
	MineCostScale = 0.6,   -- цены улучшения шахты × это (шахта больше не открывает руду)
	GuaranteedCount = 3,   -- столько кусков следующего захода - новая руда
	-- v20.110: ВАЛУНЫ роняют СЛУЧАЙНУЮ руду по своему тиру (окно из 5 руд,
	-- как у старых пещер; тир валуна растёт вместе с игроком), удача
	-- наклоняет к редким. Руда, которой ещё нет в шахте, подписана NEW.
	ApplyToBoulders = false,
	BoulderWindow = true,

}
Config.OreShop = {
	PriceBase = 250,       -- цена третьей руды (первой покупной)
	PriceGrowth = 1.7,     -- каждая следующая дороже в 1.7 раза
	ChanceByRarity = { Common = 0.95, Uncommon = 0.7, Rare = 0.4, Epic = 0.2, Legendary = 0.07, Mythic = 0.04 },
	StockByRarity = { Common = { 1, 2 } }, -- остальным - 1 штука
	BoxIcon = "📦",
}

if Config.MineRework.Enabled then
	for _, info in Config.OreChain do info.Rarity = info.BaseRarity or info.Rarity end
end

function Config.OreBaseRarity(oreKey)
	local ore = Config.OreByKey and Config.OreByKey[oreKey]
	return ore and (ore.BaseRarity or ore.Rarity) or "Common"
end

function Config.OreShopPrice(oreKey)
	local ore = Config.OreByKey and Config.OreByKey[oreKey]
	if not ore then return math.huge end
	local shop = Config.OreShop
	return niceNumber(shop.PriceBase * shop.PriceGrowth ^ math.max(0, (ore.Index or 3) - 3))
end

function Config.IsStarterOre(oreKey)
	return table.find(Config.MineRework.StarterOres, oreKey) ~= nil
end

-- Вес руды в пуле (без удачи).
function Config.OreDropWeight(oreKey)
	local ore = Config.OreByKey and Config.OreByKey[oreKey]
	if not ore then return 0 end
	local rework = Config.MineRework
	local rarity = ore.BaseRarity or ore.Rarity or "Common"
	-- позиция внутри своей редкости
	local position = 0
	for _, other in Config.OreChain do
		if other == ore then break end
		if (other.BaseRarity or other.Rarity) == rarity then position += 1 end
	end
	local weight = (rework.RarityWeights[rarity] or 1) * (rework.SameRarityDecay ^ position)
	if not Config.IsStarterOre(oreKey) then weight *= rework.UnlockBoost or 1 end
	return weight
end

-- v20.118: множитель веса руды от числа купленных коробок (1 = одна).
function Config.OreRebuyMultiplier(buys)
	local rework = Config.MineRework
	local extra = math.max(0, math.floor(tonumber(buys) or 1) - 1)
	if extra == 0 then return 1 end
	local decay = rework.RebuyDecay or 0.75
	return 1 + (rework.RebuyBoost or 0.35) * (1 - decay ^ extra) / (1 - decay)
end

-- Ролл руды из открытых. unlocked - { [oreKey] = true }, buys - { [oreKey] = N }
-- (v20.118, сколько раз куплена). Возвращает то же, что RollOreForTier:
-- (oreInfo, честный шанс без удачи, slot, rarity).
function Config.RollOreUnlocked(unlocked, luckBonus, forcedKey, buys)
	local list = {}
	for _, ore in Config.OreChain do
		if unlocked[ore.Key] or Config.IsStarterOre(ore.Key) then table.insert(list, ore) end
	end
	local baseTotal, total = 0, 0
	local weights = {}
	luckBonus = math.clamp(tonumber(luckBonus) or 0, 0, 10)
	local baseWeights = {}
	for index, ore in list do
		local w = Config.OreDropWeight(ore.Key) * Config.OreRebuyMultiplier(buys and buys[ore.Key])
		baseWeights[index] = w
		baseTotal += w
		local rarityIndex = table.find(Config.RarityOrder or {}, ore.BaseRarity or ore.Rarity) or 1
		local tilted = w * (1 + luckBonus) ^ (rarityIndex - 1) -- удача растит редкие ступенчато
		weights[index] = tilted
		total += tilted
	end
	local function result(index)
		local ore = list[index]
		return ore, baseWeights[index] / math.max(1e-9, baseTotal), index, ore.BaseRarity or ore.Rarity
	end
	if forcedKey then
		for index, ore in list do
			if ore.Key == forcedKey then return result(index) end
		end
	end
	local roll = math.random() * total
	for index, w in weights do
		roll -= w
		if roll <= 0 then return result(index) end
	end
	return result(#list)
end

--------------------------------------------------------------------------------
-- СРЕДНЯЯ РЕДКОСТЬ ДЛЯ ТИРА (меш входа шахты entry_common/..., см.
-- MineService:_applyEntryMesh). Средневзвешенная по тем же весам и с тем
-- же наклоном удачи, что и настоящий ролл.
--------------------------------------------------------------------------------
Config.RarityOrder = { "Common", "Uncommon", "Rare", "Epic", "Legendary", "Mythic" }

local RARITY_INDEX = {}
for index, name in Config.RarityOrder do
	RARITY_INDEX[name] = index
end

local function tiltedWeights(weights, luckBonus)
	local adjusted = {}
	local total = 0
	for slot, weight in ipairs(weights) do
		local w = weight * (1 + luckBonus * (slot - 1))
		adjusted[slot] = w
		total += w
	end
	return adjusted, total
end

function Config.AverageRarityForTier(tier, luckBonus)
	-- v3: при редкости по слоту «средняя редкость» одинакова в любой пещере,
	-- поэтому вход шахты светится по ПРОГРЕССУ: пещеры 1-3 Common, 4-6
	-- Uncommon, 7-9 Rare, 10-12 Epic, 13-15 Legendary. Хорошая мини-игра
	-- (удача ≥ LuckStepThreshold) поднимает свечение на одну ступень.
	tier = math.clamp(math.floor(tonumber(tier) or 1), 1, #Config.MineTiers)
	local bands = #Config.SlotRarities
	local index = math.clamp(math.ceil(tier / #Config.MineTiers * bands), 1, bands)
	if (tonumber(luckBonus) or 0) >= (Config.Mine.EntryLuckStepThreshold or 0.3) then
		index = math.min(index + 1, bands)
	end
	return Config.RarityOrder[index]
end

-- Роллит ОДНУ руду из пула пещеры. Возвращает (oreInfo, trueChance, slot,
-- rarity). trueChance — базовый шанс слота БЕЗ удачи (честная надпись
-- «1/N»). luckBonus (0..0.6) наклоняет веса к редким слотам.
function Config.RollOreForTier(tier, luckBonus)
	local tierInfo = Config.MineTiers[math.clamp(tier or 1, 1, #Config.MineTiers)]
	local weights = tierInfo.Weights
	luckBonus = luckBonus and math.clamp(luckBonus, 0, 0.6) or 0
	local adjusted, total = tiltedWeights(weights, luckBonus)
	local baseTotal = 0
	for _, weight in weights do baseTotal += weight end
	local roll = math.random() * total
	local acc = 0
	for slot, weight in ipairs(adjusted) do
		acc += weight
		if roll <= acc then
			return tierInfo.Ores[slot], weights[slot] / baseTotal, slot, Config.SlotRarities[slot]
		end
	end
	local lastSlot = #tierInfo.Ores
	return tierInfo.Ores[lastSlot], weights[lastSlot] / baseTotal, lastSlot, Config.SlotRarities[lastSlot]
end

--------------------------------------------------------------------------------
-- ТЕЛЕЖКА
-- MaxHealth больше НЕ зеркалит держателя — растёт с тиром САМОЙ тележки:
-- вложился в апгрейд → возишь груз увереннее, дольше выдерживаешь погоню.
-- Тир 1 (100) — как раньше, дальше рост ускоряется вместе с Capacity, но
-- не настолько, чтобы тир 8 кирка (46 урона/сек) переставала быть страшной —
-- даже топовая тележка ловит смертельную серию за ~7-8 сек непрерывного боя.
--------------------------------------------------------------------------------
Config.CartTiers = {
	[1] = { Capacity = 12,  MaxHealth = 100 },
	[2] = { Capacity = 20,  MaxHealth = 125 },
	[3] = { Capacity = 30,  MaxHealth = 150 },
	[4] = { Capacity = 45,  MaxHealth = 180 },
	[5] = { Capacity = 60,  MaxHealth = 215 },
	[6] = { Capacity = 80,  MaxHealth = 255 },
	[7] = { Capacity = 105, MaxHealth = 300 },
	[8] = { Capacity = 140, MaxHealth = 350 },
	[9] = { Capacity = 180, MaxHealth = 410 },
}

-- Сетка слотов внутри тележки (кристаллы видны БЕЗ интерфейса).
Config.CartSlots = {
	Cell = 1.8, -- шаг сетки; должен вмещать самый крупный кристалл
	Cols = 4,   -- по ширине
	Rows = 3,   -- по глубине
}

Config.Cart = {
	-- Дистанция клика/наведения на кусок руды В ТЕЛЕЖКЕ (своей или чужой) —
	-- клиентский raycast в OrePreviewHud.client.lua проверяет её от игрока до
	-- найденной руды.
	-- v20.40: карточка руды при наведении/тапе выключена — над рудой и так
	-- написано всё (редкость, цена, шанс). true — вернуть.
	OrePreviewEnabled = false,
	OrePreviewMaxDistance = 24,
	-- На этом расстоянии руда из рук автоматически отправляется в свою тележку.
	DepositDistance = 9,

	-- Смещение тележки относительно HumanoidRootPart держателя — X/Z
	-- (позади) берутся отсюда буквально, а вот Y (высота) больше НЕ читается
	-- напрямую: CartService:computeFollowOffset пересчитывает её под
	-- конкретную тележку и игрока (см. Bottom-маркер в PlaceholderFactory.Cart
	-- и Humanoid.HipHeight), чтобы низ тележки не проваливался в землю.
	-- Значение Y здесь оставлено для справки/старого умолчания, реально не используется.
	-- Z увеличен (было 6) — тележка держится чуть дальше от игрока, чтобы
	-- растяжение рук в IK-хвате (CustomCartUI.client.lua) выглядело как
	-- настоящая протянутая рука, а не почти прямая в упор к телу.
	FollowOffset = CFrame.new(0, -2, 8.5),

	-- Пол тележки шире по X (Cols), чем по Z (Rows) — 90° разворачивает
	-- саму тележку так, чтобы к игроку была обращена УЗКАЯ сторона, а не
	-- широкая (см. CartService:Attach, C1 у Motor6D). Не трогает сетку
	-- слотов кристаллов — она в локальных координатах тележки и крутится
	-- вместе с ней как единое целое.
	HolderSideRotation = 90,

	-- ПРЫЖОК С ТЕЛЕЖКОЙ: разрешён, но не часто — после каждого прыжка
	-- Jumping-состояние отключается на этот срок и включается обратно
	-- само (см. CartService:Attach). Не полный запрет — только откат.
	JumpCooldown = 3,

	-- СКОРОСТЬ С ТЕЛЕЖКОЙ (переделано по фидбеку игроков — старое замедление
	-- от % заполнения било по первому впечатлению: уже на половине тележки
	-- терялась треть скорости, на полной — больше 60%, и это ДО того, как
	-- игрок вообще успевал прокачаться. Новичок набирал первую тележку и
	-- буквально плёлся до банка — "that's where players will get bored and
	-- leave the game"). Теперь скорость с тележкой ВООБЩЕ НЕ зависит от
	-- заполнения — фиксированная база (+ геймпасс Speed Boost) плюс
	-- небольшой процент от обычной скорости ходьбы (см. CartSpeedBonusPercent
	-- в Config.Rebirth) — так прокачка (ребёрты/геймпасс) всё ещё немного
	-- влияет на скорость тележки, просто без пугающего резкого замедления.
	BaseWalkSpeed = 14,     -- скорость персонажа без груза (было 16 = стандарт Roblox — по фидбеку ощущалось слишком быстро, слегка снижено)
	-- ТЕЛЕЖКА ВООБЩЕ НЕ ЗАМЕДЛЯЕТ — по прямому запросу. Раньше даже на
	-- максимально ускоренной базе (13.1875) тележка была на ~5.8% медленнее
	-- обычной ходьбы (14) — теперь FixedCartSpeed РОВНО равен BaseWalkSpeed,
	-- разницы не остаётся вообще. Бонус от ребёртов (CartSpeedBonusPercent
	-- в Config.Rebirth) по-прежнему добавляется ПОВЕРХ — это ускорение,
	-- не компенсация замедления, никак не мешает "без замедления".
	FixedCartSpeed = 14,

	-- МЕДЛЕННЫЕ ПОВОРОТЫ: пока тележка в руках, AutoRotate персонажа
	-- выключается — поворотом управляет CartService вручную (limitTurning),
	-- с ограниченной угловой скоростью. Линейно от % заполнения тележки:
	-- MaxTurnRate (пустая, почти как обычно) до MinTurnRate (полная,
	-- разворот тяжёлый и медленный). Тележка приварена к HRP через Motor6D,
	-- поэтому автоматически повторяет уже ограниченный поворот персонажа —
	-- отдельно её саму крутить не нужно.
	-- ПОВОРОТ: даже у пустой тележки есть небольшое "стопорное" сопротивление —
	-- MaxTurnRate заметно ниже, чем "мгновенно", чтобы ощущалось, что в руках
	-- реально что-то есть, а не просто обычный разворот персонажа.
	MaxTurnRate = math.rad(225),  -- град/сек → рад/сек, пустая тележка — уже не мгновенно
	MinTurnRate = math.rad(45),   -- полная тележка — медленный, тяжёлый разворот

	-- ВЗЯТИЕ/ОТПУСКАНИЕ: сколько держать кнопку, чтобы взять свободную
	-- тележку (ProximityPrompt.HoldDuration) и чтобы отпустить ту, что уже
	-- несёшь (клавиша E, см. src/client/CustomCartUI.client.lua).
	PickupHoldDuration = 0, -- было 0.7 — теперь мгновенно (тап, не удержание), брать тележку должно быть без трения
	DropHoldDuration = 2.5,

	-- ДЕСПАВН ПРОСТОЯ: свободную (никто не держит) тележку, которую не
	-- трогали дольше этого времени — не важно, украдена она и брошена
	-- где-то далеко, или просто стоит без дела у самого владельца на базе,
	-- пока он бегает по карте — уничтожает полностью, груз внутри теряется.
	-- Если это была ТЕКУЩАЯ тележка игрока — тут же спавнится пустая новая
	-- на его базе (см. CartService:Start).
	DespawnIdleTime = 45,

	-- РУЧНОЙ РЕСПАВН: физическая кнопка у парковки на базе — всегда
	-- доступна (даже если старую в этот момент несёт вор — та не трогается
	-- вообще, просто перестаёт быть "текущей" и сама сгорит по таймеру
	-- простоя выше), но с кулдауном — иначе кража теряет всякий смысл.
	-- Числовой отсчёт над кнопкой — только в последние
	-- RespawnCountdownThreshold секунд, до этого видно только то, что
	-- кнопка "вдавлена" (см. CartService:SetupRespawnButton).
	ManualRespawnCooldown = 180,
	RespawnCountdownThreshold = 30,

	-- КУДА СТАВИТЬ КНОПКУ ("Spawn New"), если в PlotTemplate НЕТ отдельного
	-- маркера "CartButtonMarker" (см. PLACEHOLDERS_GUIDE.md — можно вместо
	-- этого просто подвинуть мышкой Part с таким именем в Studio, тогда
	-- ButtonOffset ниже вообще не используется, маркер побеждает). Это —
	-- запасной способ ЦИФРАМИ, без захода в модель участка: смещение
	-- (X, Y, Z) от точки парковки тележки (CartSpawnMarker), в studs,
	-- X — вбок, Y — вверх/вниз, Z — вперёд/назад.
	ButtonOffset = Vector3.new(5, -0.5, 0),

	-- Сам поворот применяется к персонажу НЕ прямой записью CFrame (это
	-- конфликтует с внутренней физикой Humanoid и даёт дёрганое движение
	-- при репликации другим игрокам), а через AlignOrientation-констрейнт,
	-- который физический движок плавно интегрирует в общий солвер вместе
	-- с обычным движением персонажа. Торк/отзывчивость специально высокие —
	-- вся "медленность" уже заложена в MaxTurnRate/MinTurnRate выше, здесь
	-- нужно лишь без задержки дотягиваться до уже посчитанной цели.
	TurnMaxTorque = 1e6,
	TurnResponsiveness = 35,

	-- РЕАЛЬНЫЙ ФИЗИЧЕСКИЙ ЛЮФТ: тележка больше НЕ приварена к игроку
	-- абсолютно жёстко — вместо прямого Motor6D она физически ДОГОНЯЕТ
	-- невидимый "идеальный" якорь (тот жёстко висит на игроке ровно так же,
	-- как раньше сама тележка), через AlignPosition/AlignOrientation с
	-- конечной силой/отзывчивостью (см. CartService:Attach). При резком
	-- движении/повороте тележка на мгновение чуть отстаёт — от этого руки
	-- (см. CustomCartUI.client.lua — IK каждый кадр считает честную дистанцию
	-- до точки хвата) визуально чуть растягиваются, и через секунду-другую
	-- само возвращается. FollowResponsiveness — главная ручка "насколько
	-- тянучее" (ниже = дольше самокоррекция), FollowMaxForce/Torque —
	-- потолок силы, важен в основном для того, чтобы держать вес тележки
	-- (не давать ей проседать) — не про "жёсткость" реакции.
	FollowResponsiveness = 4,
	-- v20.104: АНТИ-УЛЁТ (CartService guardFling): скорость, с которой
	-- тележка догоняет игрока, потолок скорости тележки/держателя, дистанция,
	-- дальше которой тележку сразу ставит к игроку, и высота, выше которой
	-- тележка считается потерянной (возвращается упаковкой).
	FollowMaxVelocity = 60,
	-- v20.105: окно тележки (R): сколько секунд достанная руда не
	-- переливается обратно автоматически, и с какого расстояния работает окно.
	InventoryNoAutoDepositSeconds = 10,
	InventoryUseDistance = 16,
	FlingMaxSpeed = 90,
	FlingSnapDistance = 18,
	FlingHolderUpSpeed = 70,
	MaxHeight = 600,
	FollowMaxForce = 40000,
	FollowForceGravityMultiplier = 8, -- минимум силы = масса тележки × gravity × это число
	FollowRotationResponsiveness = 30, -- поворот САМОЙ тележки относительно направления игрока остаётся куда более снятым — люфт нужен только по позиции
	FollowRotationMaxTorque = 1e6,

	-- ПОМОЩЬ НА РЕЛЬЕФЕ: при прыжке игрока тележка подпрыгивает следом, а
	-- низкие выступы медленно переползает вверх. Высокая стена остаётся
	-- стеной: верхний луч блокирует карабканье выше ClimbMaxHeight.
	FollowJumpVelocity = 28,
	ClimbMaxHeight = 3.5,
	ClimbSpeed = 5,
	ClimbProbeDistance = 2.75,
	ClimbMinFollowLag = 0.75,
	ClimbProbeInterval = 0.08,
	StuckDistance = 3,
	StuckDelay = 0.35,
	StuckBoostVelocity = 10,
	StuckBoostCooldown = 0.55,
	StuckMaxBoosts = 2,

	-- КОМБО-МНОЖИТЕЛЬ: радужная капсула над тележкой, умножает деньги при
	-- продаже — награда за риск возить ценный груз через опасную дорогу.
	-- Множитель зависит от % заполнения тележки НАПРЯМУЮ, а не от
	-- абсолютных очков — комбо начинается, только когда тележка ощутимо
	-- заполнена, а не с пустой/почти пустой (иначе не показательно и
	-- нечестно к маленьким тележкам). Очки (Config.MineTiers[N].Points)
	-- работают как "ускоритель": ценная руда даёт тот же множитель при
	-- МЕНЬШЕМ % заполнения — effectiveFill = rawFill × (среднийPoints/ComboReferencePoints).
	ComboMinFill = 0.15,               -- ниже этого % заполнения комбо не считается вообще (защита от "1 кусок дорогой руды в пустой телеге = дикий x60")
	-- Фиксированная точка отсчёта (не привязана к конкретному тиру руды) —
	-- откалибрована вместе с MineTiers[N].Points так, чтобы при 60% заполнения
	-- САМАЯ дешёвая руда (тир 1) давала x2 (серебро), а САМАЯ дорогая (тир 8) —
	-- около x35. Прокачка Шахты напрямую поднимает тир добываемой руды → выше
	-- средний Points → выше эффективный буст при той же % заполнения тележки —
	-- это и есть "зависимость от прокачки".
	-- ВАЖНО: тележка физически не может быть заполнена больше 100%
	-- (AddCrystal отказывает при #Crystals >= Capacity, см. CartService) —
	-- поэтому "потолок" каждого тира руды достигается РОВНО на полной
	-- тележке (fill=1.0), effectiveFill в этой точке равен Points/ComboReferencePoints
	-- этого тира. Тиры 1-6 упираются в x50 около 100% заполнения; тиры 7 и 8
	-- НАРОЧНО имеют более высокий буст (k=2.60 и k=3.15) — их потолок выше
	-- (x80 и x120 соответственно), тоже достижимый ровно на полной тележке.
	ComboReferencePoints = 20,
	-- ЭКОНОМИКА v3: комбо зависит ТОЛЬКО от заполнения тележки (не от
	-- «качества» руды) и упирается в x3 на полной тележке. Старое комбо
	-- доходило до x260 и было главным источником гигантских чисел: цена
	-- руды росла в ~2 раза за тир, а комбо поверх — ещё в 1.5-2 раза.
	ComboUseOreQuality = false,
	ComboThresholds = {
		{ Fill = 0.35, Multiplier = 1.25 },
		{ Fill = 0.50, Multiplier = 1.5 },
		{ Fill = 0.70, Multiplier = 2 },
		{ Fill = 0.85, Multiplier = 2.5 },
		{ Fill = 1.00, Multiplier = 3 },
	},
	-- Порог «продал на высоком комбо» для квеста X4Sales (теперь «x3»).
	QuestHighComboMultiplier = 3,

	-- ВИЗУАЛЬНЫЕ СТАДИИ карточки комбо — растёт размер и меняется градиент
	-- по "лигам" множителя: от тусклого дерева при скромном комбо до полной
	-- радуги на самом верху — видно издалека, кого стоит грабить.
	-- Радуга нарочно начинается высоко (x65) — на 100% заполнения её физически
	-- достают только тиры руды 7-8 (потолки x80/x120, см. ComboThresholds выше),
	-- остальным тирам светит максимум "кристалл". Порядок лиг: дерево → серебро
	-- → бронза → золото → кристалл → радуга.
	-- ВИЗУАЛЬНЫЕ СТАДИИ карточки комбо — теперь просто текст "X{число}" без
	-- фона-плашки (см. CartService:findOrBuildComboGui/updateComboLabel):
	-- растёт размер текста и меняется его СПЛОШНОЙ цвет по "лигам" множителя.
	-- Только у самой верхней лиги (Радуга) вместо Color — Gradient: крутящийся
	-- радужный градиент прямо на буквах, как и раньше был на фоне.
	ComboVisualStages = {
		{ -- Дерево — самое скромное комбо, любая руда его достаёт почти сразу
			MinMultiplier = 1.25,
			Size = UDim2.new(3.6, 0, 0.95, 0),
			Color = Color3.fromRGB(181, 136, 99),
		},
		{ -- Серебро
			MinMultiplier = 1.5,
			Size = UDim2.new(4.0, 0, 1.05, 0),
			Color = Color3.fromRGB(225, 225, 235),
		},
		{ -- Бронза
			MinMultiplier = 2,
			Size = UDim2.new(4.4, 0, 1.15, 0),
			Color = Color3.fromRGB(215, 140, 90),
		},
		{ -- Золото
			MinMultiplier = 2.5,
			Size = UDim2.new(4.8, 0, 1.25, 0),
			Color = Color3.fromRGB(255, 205, 60),
		},
		{ -- Кристалл — холодный переливающийся голубой, ощутимо "дороже" золота
			MinMultiplier = 2.75,
			Size = UDim2.new(5.2, 0, 1.35, 0),
			Color = Color3.fromRGB(150, 215, 255),
		},
		{ -- Радуга — вершина, x65+ (реально только тиры руды 7-8 на почти полной тележке)
			MinMultiplier = 3, -- v3: радуга = полная тележка (потолок комбо x3)
			Size = UDim2.new(5.6, 0, 1.45, 0),
			Gradient = ColorSequence.new({
				ColorSequenceKeypoint.new(0.00, Color3.fromRGB(255, 0, 0)),
				ColorSequenceKeypoint.new(0.17, Color3.fromRGB(255, 165, 0)),
				ColorSequenceKeypoint.new(0.34, Color3.fromRGB(255, 255, 0)),
				ColorSequenceKeypoint.new(0.50, Color3.fromRGB(0, 255, 0)),
				ColorSequenceKeypoint.new(0.67, Color3.fromRGB(0, 170, 255)),
				ColorSequenceKeypoint.new(0.84, Color3.fromRGB(140, 0, 255)),
				ColorSequenceKeypoint.new(1.00, Color3.fromRGB(255, 0, 0)),
			}),
		},
	},
}

--------------------------------------------------------------------------------
-- УПАКОВКА ТЕЛЕЖКИ (v12 — полная замена "тележка выдаётся сама + кнопка
-- Spawn New").
--
-- НОВЫЙ ЖИЗНЕННЫЙ ЦИКЛ:
--   1. У нового игрока тележки НЕТ ВООБЩЕ. Первая покупается у НПС прокачки
--      за 0 (карточка "GET CART · FREE", см. UpgradeService — ветка Cart при
--      ещё не купленной тележке).
--   2. Покупка выдаёт не тележку, а УПАКОВКУ — предмет инвентаря
--      (data.Gear["CartPackage"], тот же контейнер, что у динамита/сундуков,
--      поэтому она сразу появляется в рюкзаке и хотбаре).
--   3. Взял упаковку в руки — она поднимается НАД ГОЛОВОЙ ровно как руда
--      (OreCarryPose.client.lua, атрибут HeldCartPackage), и включается
--      ЗЕЛЁНЫЙ/КРАСНЫЙ предпросмотр места постановки (CartPlacement.client.lua).
--   4. Поставил — тележка появляется маленькой и резко "надувается" до
--      нормального размера (CartService:_playInflate).
--   5. Улучшил тележку: стоит в мире — апгрейд применяется ПРЯМО НА НЕЙ (с
--      подсветкой и той же надувной анимацией); не стоит — игрок просто
--      получает новую упаковку (тир читается в момент постановки, поэтому
--      сама упаковка тир не хранит).
--
-- ИНВАРИАНТ: у игрока с купленной тележкой ВСЕГДА ровно одно из двух —
-- тележка в мире ИЛИ упаковка в рюкзаке. Потерял тележку (упала в бездну,
-- сгорела по простою) — упаковка возвращается сама (RestoreDelay), кнопка
-- ручного респавна больше не нужна и удалена.
--------------------------------------------------------------------------------
Config.CartPackage = {
	-- Ключ предмета в data.Gear и в хотбаре (uid "gear:CartPackage").
	GearKey = "CartPackage",
	-- v20.98: цвета коробки-плейсхолдера по тиру тележки (чем круче - тем
	-- богаче): Body - сама коробка, Accent - ленты/крышка, Trim - бант и рёбра.
	TierColors = {
		[1] = { Body = Color3.fromRGB(168, 124, 78),  Accent = Color3.fromRGB(228, 196, 130), Trim = Color3.fromRGB(200, 160, 100) }, -- картон
		[2] = { Body = Color3.fromRGB(130, 132, 140), Accent = Color3.fromRGB(200, 200, 205), Trim = Color3.fromRGB(90, 92, 100) },   -- камень
		[3] = { Body = Color3.fromRGB(70, 150, 75),   Accent = Color3.fromRGB(240, 235, 210), Trim = Color3.fromRGB(190, 120, 60) },  -- зелень
		[4] = { Body = Color3.fromRGB(45, 110, 200),  Accent = Color3.fromRGB(235, 240, 255), Trim = Color3.fromRGB(200, 205, 215) }, -- синий+серебро
		[5] = { Body = Color3.fromRGB(125, 60, 190),  Accent = Color3.fromRGB(255, 200, 80),  Trim = Color3.fromRGB(230, 225, 240) }, -- фиолет+золото
		[6] = { Body = Color3.fromRGB(200, 40, 50),   Accent = Color3.fromRGB(255, 210, 70),  Trim = Color3.fromRGB(255, 240, 200) }, -- красный+золото
		[7] = { Body = Color3.fromRGB(30, 190, 200),  Accent = Color3.fromRGB(255, 255, 255), Trim = Color3.fromRGB(255, 205, 60) },  -- бирюза
		[8] = { Body = Color3.fromRGB(255, 120, 200), Accent = Color3.fromRGB(120, 230, 255), Trim = Color3.fromRGB(255, 205, 60) },  -- неон-розовый
		[9] = { Body = Color3.fromRGB(28, 26, 34),    Accent = Color3.fromRGB(255, 205, 60),  Trim = Color3.fromRGB(170, 90, 255) },  -- обсидиан+золото
	},
	DisplayName = "Cart Package",
	Icon = "📦",

	-- ПОСТАНОВКА.
	--
	-- v12.1: пороги СИЛЬНО ослаблены. Первая версия проверяла место одним
	-- лучом и раздутой коробкой, из-за чего превью краснело почти везде —
	-- любая кочка, бордюр или стык частей читались как "нет твёрдой
	-- поверхности"/"место занято". Теперь земля замеряется девятью лучами
	-- по площади тележки, а ровность считается по перепаду высот между
	-- ними (см. Shared/CartPlacement.Validate).
	MaxDistance = 34,      -- дальше этого от игрока поставить нельзя (превью краснеет)
	MinDistance = 2.5,     -- ближе — тоже нельзя, иначе тележка встаёт в игрока
	DefaultDistance = 10,  -- куда падает превью, если луч прицела ни во что не попал
	-- v14.3: тележку можно ставить на ЛЮБУЮ поверхность, кроме стен.
	MaxSlope = 70,         -- градусов: круче — это уже стена под центром
	MaxGroundSpread = 0,   -- 0 = перепад высот под тележкой не проверяется
	GroundRayUp = 8,       -- с какой высоты над точкой бьют лучи-замеры
	GroundRayDown = 60,    -- как глубоко они ищут пол
	-- Насколько найденная земля может быть выше/ниже самого игрока. Без
	-- этого прицел в стену над обрывом ставил бы тележку на дно ущелья.
	MaxHeightDifference = 16,
	-- ЗАЗОР ДО ЗЕМЛИ: тележка намеренно встаёт ЧУТЬ ВЫШЕ самой высокой
	-- точки под собой и оседает/выравнивается физикой сама (см.
	-- CartService:_settleUpright). Так неровная поверхность перестаёт быть
	-- помехой: ничего не проваливается в бугор и не встаёт враскоряку.
	-- v14.3: подняли с 0.9 — тележка больше не проваливается в меши/текстуры.
	GroundGap = 1.6,
	-- Коробка проверки "место свободно" УЖЕ габаритов тележки (ужимается на
	-- столько по X и Z) и ниже её (доля высоты). Цель — ловить стены и
	-- столбы, а не бордюр под колёсами.
	ClearanceShrink = 0.8,
	ClearanceHeightFactor = 0.55,
	-- Ставить можно где угодно на проходимой земле. true — только внутри
	-- своего участка (как сундуки, см. GearService:_placeChest).
	OwnPlotOnly = false,
	PlaceCooldown = 0.6,   -- антиспам на серверный remote

	-- ЦВЕТА ПРЕДПРОСМОТРА.
	PreviewOkColor = Color3.fromRGB(70, 255, 120),
	PreviewBadColor = Color3.fromRGB(255, 70, 70),
	PreviewTransparency = 0.55,   -- прозрачность самого призрака тележки
	PreviewFillTransparency = 0.7, -- заливка Highlight поверх призрака

	-- "НАДУВАНИЕ" ПРИ ПОСТАНОВКЕ: тележка появляется крошечной и резко
	-- раздувается до нормального размера с перелётом (Back/Out).
	Inflate = {
		StartScale = 0.12,
		Duration = 0.42,
		Overshoot = 1.12, -- максимум, до которого перелетает, прежде чем осесть в 1
		SettleDuration = 0.16,
	},

	-- ОСЕДАНИЕ ПОСЛЕ ПОСТАНОВКИ. Тележку отпускают на GroundGap выше земли,
	-- и она падает на неё сама. Чтобы на неровности её не завалило набок,
	-- на это время включается временный AlignOrientation, удерживающий её
	-- вертикально (поворот вокруг Y он не трогает).
	Settle = {
		Seconds = 1.6,      -- сколько держим вертикаль после отпускания
		Responsiveness = 35, -- жёсткость удержания (как у Attach)
	},

	-- Потерял тележку (бездна/деспавн по простою) — через столько секунд
	-- упаковка возвращается в рюкзак. Заменяет старую физическую кнопку
	-- "Spawn New" с её 180-секундным кулдауном.
	RestoreDelay = 8,
	-- Угнанную (в руках чужого игрока) тележку упаковка НЕ дублирует —
	-- иначе кража теряет смысл. Возврат произойдёт, только когда та
	-- окончательно исчезнет (деспавн по простою).
}

--------------------------------------------------------------------------------
-- КИРКА
-- ВАЖНО (Catch-Up): урон по здоровью НЕ растёт с тиром.
-- Тир кирки = внешний вид + СКОЛЬКО кристаллов выбивается за удар + цвет VFX.
--------------------------------------------------------------------------------
-- Cooldown и Damage — теперь ГЛАВНАЯ ось прогрессии кирки (не только
-- выбивание кристаллов): тир 1 бьёт редко и слабо (сильный catch-up для
-- новичков — почти не боец), тир 8 бьёт часто и сильно. Damage считается
-- относительно стандартных 100 HP: тир 1 требует ~13 попаданий, тир 8 —
-- ~3, при этом тир 8 ещё и почти в 7 раз чаще бьёт — разрыв в PvP-силе
-- между тирами специально большой, это и есть награда за прокачку кирки.
Config.PickaxeTiers = {
	-- KnockoutMax теперь ЗАФИКСИРОВАН на 5 для всех тиров (было по нарастающей
	-- 4→22) — процент от груза жертвы (KnockoutPercent) всё ещё растёт с
	-- тиром как раньше, просто абсолютный потолок за один удар одинаков у
	-- всех кирок. Cooldown переработан: минимум 1.5с у любого тира (было
	-- падало до 0.75с), первый тир снижен с 6.5с до 3.5с.
	[1] = { Scale = 1.0, KnockoutPercent = 0.15, KnockoutMax = 5, VfxColor = Color3.fromRGB(200, 200, 200), Cooldown = 1.0, Damage = 8 },
	[2] = { Scale = 1.1, KnockoutPercent = 0.20, KnockoutMax = 5, VfxColor = Color3.fromRGB(120, 255, 160), Cooldown = 1.0, Damage = 12 },
	[3] = { Scale = 1.2, KnockoutPercent = 0.25, KnockoutMax = 5, VfxColor = Color3.fromRGB(255, 220, 100), Cooldown = 1.0, Damage = 16 },
	[4] = { Scale = 1.3, KnockoutPercent = 0.30, KnockoutMax = 5, VfxColor = Color3.fromRGB(255, 130, 220), Cooldown = 1.0, Damage = 20 },
	[5] = { Scale = 1.4, KnockoutPercent = 0.35, KnockoutMax = 5, VfxColor = Color3.fromRGB(255, 90, 90),   Cooldown = 1.0, Damage = 25 },
	[6] = { Scale = 1.5, KnockoutPercent = 0.40, KnockoutMax = 5, VfxColor = Color3.fromRGB(180, 100, 255), Cooldown = 1.0, Damage = 31 },
	[7] = { Scale = 1.6, KnockoutPercent = 0.45, KnockoutMax = 5, VfxColor = Color3.fromRGB(90, 160, 255),  Cooldown = 1.0, Damage = 38 },
	[8] = { Scale = 1.7, KnockoutPercent = 0.50, KnockoutMax = 5, VfxColor = Color3.fromRGB(255, 255, 255), Cooldown = 1.0, Damage = 46 },
	[9] = { Scale = 1.8, KnockoutPercent = 0.55, KnockoutMax = 5, VfxColor = Color3.fromRGB(255, 215, 0),   Cooldown = 1.0, Damage = 55 },
	-- v20.60: +2 кирки (всего 11).
	[10] = { Scale = 1.9, KnockoutPercent = 0.60, KnockoutMax = 5, VfxColor = Color3.fromRGB(90, 230, 255),  Cooldown = 1.0, Damage = 65 },
	[11] = { Scale = 2.0, KnockoutPercent = 0.65, KnockoutMax = 5, VfxColor = Color3.fromRGB(200, 60, 255),  Cooldown = 1.0, Damage = 76 },
}
-- v20.60: ОБЫЧНЫЕ КИРКИ (прокачка у торговца улучшениями). Модель тира N —
-- ReplicatedStorage.Assets.Pickaxe_TierN (Tool с Handle), как и раньше.
Config.PickaxeNames = {
	"Small Stone Pickaxe", "Basic Pickaxe", "Iron Pickaxe", "Copper Pickaxe", "Gold Pickaxe",
	"Adamantite Pickaxe", "Royal Pickaxe", "Whirlwind Pickaxe", "Fury Pickaxe", "Storm Pickaxe", "Chaos Pickaxe",
}
for tier, info in Config.PickaxeTiers do
	info.DisplayName = Config.PickaxeNames[tier] or ("Pickaxe T" .. tier)
end

--------------------------------------------------------------------------------
-- 3 НЕЗАВИСИМЫЕ ВЕТКИ ПРОКАЧКИ: Шахта / Тележка / Кирка.
-- У каждой свой пьедестал на участке и свой прогресс (Config хранит только
-- стоимость каждого шага — тир = 1 + число купленных шагов в этой ветке).
--
-- ЗАВИСИМОСТЬ МЕЖДУ ВЕТКАМИ: нельзя купить тир, если он окажется больше
-- чем на 2 тира выше САМОЙ ОТСТАЮЩЕЙ из двух других веток — качать в отрыв
-- можно, но не более чем на 2 шага (см. UpgradeService:_canAfford).
--------------------------------------------------------------------------------
-- ЦЕНЫ ПРОКАЧКИ — пересчитаны (прогрессия была слишком быстрой).
--
-- Единица измерения при калибровке — ПОЛНЫЙ РЕЙС ТЕЛЕЖКИ предыдущего тира
-- (вся тележка доверху × цена руды этого тира × комбо-множитель на 100%
-- заполнения). Было: ~2.4-3.0 рейса на то, чтобы поднять ВСЕ ТРИ ветки на
-- следующий тир — то есть один полный тир окупался буквально за пару
-- ходок, и игрок пролетал всю прогрессию, не успевая ничего почувствовать.
-- Стало: ~4 рейса на самом первом апгрейде (чтобы не отпугнуть новичка) с
-- плавным ростом до ~10 рейсов на девятом (последнем) тире.
--
-- Множители к старым ценам: T2 ×1.6, T3 ×2.6, T4 ×2.8, T5 ×3.0, T6 ×3.2,
-- T7 ×3.4, T8 ×3.6, T9 ×3.8 — то есть чем дальше по игре, тем
-- ощутимее замедление, а самое начало почти не тронуто.
--
-- ВАЖНО про ощущение темпа: игроку НЕ обязательно поднимать все три ветки
-- сразу — Config.BranchMaxGap (2) позволяет увести Шахту на два тира
-- вперёд, а она одна и определяет цену добываемой руды. Так что реальный
-- рост дохода наступает быстрее, чем "суммарная цена трёх веток / рейс".
-- ЦЕНЫ АПГРЕЙДОВ — пересчитаны ПОСЛЕ смены масштаба экономики (см.
-- Config.Crystal_BaseValue выше). База — реальный доход ПОЛНОСТЬЮ гружёной
-- тележки на 100% заполнении с учётом комбо-множителя текущего тира
-- (Config.Cart.ComboThresholds), а не голая цена руды без комбо — так
-- ощущается для игрока, который реально возит полные тележки. Целимся в
-- ~8 таких рейсов на тир Шахты, ~11 на Тележку, ~14 на Кирку — И ЭТО ЧИСЛО
-- ОДИНАКОВО НА ВСЕХ 9 ТИРАХ (раньше росло с 6 до 427 — см. историю
-- переписки/коммит выше по файлу), то есть темп прокачки не ускоряется и
-- не замедляется на всей дистанции игры, только сами суммы растут вместе
-- с экономикой.
-- ЦЕЛЬ ТЕМПА ПРОКАЧКИ (v2, ×3 к предыдущей версии по прямому запросу —
-- "забираю почти весь первый тир пещеры за один раз", хочет дольше
-- фармить). Раньше было 3→8 рейсов на тир — ощущалось слишком быстро.
-- Просто утроил все цены — сам темп (плавный рост от ранних тиров к
-- поздним, единый для всех трёх веток) не менял, поднялась только
-- магнитуда. Специально остановился РОВНО на ×3, не больше: предыдущая
-- версия ДО этого ребаланса (16-28 рейсов на тир, через
-- Config.Economy.ProgressionSlowdown=2.07) прямым текстом называлась
-- скучной — ×3 даёт 9-24 рейса, заметно дольше нынешних 3-8, но всё ещё
-- ощутимо мягче того, от чего уже один раз уходили.
--   тир →  2     3      4       5        6         7          8           9
--   рейсов 9     9      12      15       18        21         24          24
--------------------------------------------------------------------------------
-- ЭКОНОМИКА v3 — ПРОКАЧКА (выбор Б2: пещера главная, тележка и кирка — перки).
--
-- ПЕЩЕРА (ветка Mine) — единственная ось, которая открывает новую руду.
-- 15 пещер. Кап по ребёртам: без ребёрта — пещера 5, каждый ребёрт +2
-- (5 → 7 → 9 → 11 → 13 → 15, до финальной пещеры пять ребёртов).
-- ТЕЛЕЖКА и КИРКА (9 уровней) — перки: не упираются в кап ребёрта и в
-- «отрыв веток» (BranchMaxGap убран), потолок — только длина цепочки.
-- На ребёрте сбрасывается ВСЁ (пещера, тележка, кирка, деньги).
--
-- Калибровка — в «полных тележках» (Config.CartValue: средний дроп, x3
-- комбо) при естественном тире тележки для этой пещеры: шаг пещеры стоит
-- 2 → 2.5 → 3 → … → 9 тележек. Примерное время без пассов: пещера 5
-- (первый ребёрт) ≈ 30 мин + ≈ 6 мин на сам ребёрт; дальше шаги растут
-- плавно — до ~1 часа на пещеру 14→15.
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
-- ЭКОНОМИКА v4 (темп «быстрый, но не слишком»): цены посчитаны симуляцией
-- (Config.IncomePerMinute × 0.75 — реальный игрок возит не каждую тележку
-- на x3) по целевым минутам на шаг:
--   пещера 2→8: 2.5 … 5.5 мин на шаг, пещера 9→15: 6.5 … 12.5 мин;
--   тележка ≈ 3.5 мин дохода, кирка ≈ 2 мин дохода в момент покупки.
-- Итог без пассов и престижа: пещера 8 (первый престиж) ≈ 45 мин, пещера
-- 15 + всё докачано ≈ 2.3 ч. Цены ФИКСИРОВАННЫЕ (не зависят от игрока).
--------------------------------------------------------------------------------
-- v20: цены пещер +15% (прогрессия была слишком быстрой).
Config.MineChain = {
	{ Tier = 2, Cost = 140 },
	{ Tier = 3, Cost = 330 },
	{ Tier = 4, Cost = 750 },
	{ Tier = 5, Cost = 1500 },
	{ Tier = 6, Cost = 2400 },
	{ Tier = 7, Cost = 5200 },
	{ Tier = 8, Cost = 8600 },
	{ Tier = 9, Cost = 21000 },
	{ Tier = 10, Cost = 39000 },
	{ Tier = 11, Cost = 67000 },
	{ Tier = 12, Cost = 130000 },
	{ Tier = 13, Cost = 220000 },
	{ Tier = 14, Cost = 430000 },
	{ Tier = 15, Cost = 690000 },
}
Config.CartChain = {
	{ Tier = 2, Cost = 330 },
	{ Tier = 3, Cost = 930 },
	{ Tier = 4, Cost = 3100 },
	{ Tier = 5, Cost = 8400 },
	{ Tier = 6, Cost = 14000 },
	{ Tier = 7, Cost = 42000 },
	{ Tier = 8, Cost = 110000 },
	{ Tier = 9, Cost = 240000 },
}
if Config.MineRework and Config.MineRework.Enabled then
	for _, step in Config.MineChain do
		step.Cost = Config.NiceNumber(step.Cost * (Config.MineRework.MineCostScale or 1))
	end
end
Config.PickaxeChain = {
	{ Tier = 2, Cost = 200 },
	{ Tier = 3, Cost = 640 },
	{ Tier = 4, Cost = 1800 },
	{ Tier = 5, Cost = 5400 },
	{ Tier = 6, Cost = 9100 },
	{ Tier = 7, Cost = 24000 },
	{ Tier = 8, Cost = 64000 },
	{ Tier = 9, Cost = 140000 },
	{ Tier = 10, Cost = 330000 }, -- v20.60: Storm Pickaxe
	{ Tier = 11, Cost = 760000 }, -- v20.60: Chaos Pickaxe
}
-- v20: цены — в масштабе дохода пещеры, где их покупают (Config.NumberGrowth):
-- пещеру N оплачивает доход пещеры N-1, тележку/кирку тира T — доход
-- пещеры, для которой этот тир «родной».
function Config.CaveNumberScale(cave)
	local info = Config.MineTiers[math.clamp(math.floor(tonumber(cave) or 1), 1, #Config.MineTiers)]
	return info and info.NumberScale or 1
end
local function caveForNineTierLocal(tier)
	return math.clamp(1 + math.floor((tier - 1) * (#Config.MineTiers - 1) / 8 + 0.5), 1, #Config.MineTiers)
end
-- v20.2: РАСТЯЖКА ПОЗДНЕЙ ИГРЫ (по данным DevForum: первые ~45 мин не
-- трогаем — быстрые награды и первый престиж держат новичка; конец раньше
-- проходился за 1–2 вечера). Множитель цены по пещере; плавный, без скачка.
-- Первое прохождение до пещеры 15 ≈ 3.5 ч активной игры.
Config.LateGameStretch = { [9] = 1.35, [10] = 1.5, [11] = 1.65, [12] = 1.75, [13] = 1.75, [14] = 1.75, [15] = 1.75 }
local function stretchFor(cave)
	return Config.LateGameStretch[cave] or 1
end
-- v20.64: ЭКОНОМИКА ДЛИННЕЕ. Мутации раньше почти утраивали доход
-- (средний множитель цены руды ×2.98), с ChanceScale 0.5 - ×1.74, то есть
-- реальный доход упал на ~42%. Сверху - цены: пещеры +30%, тележка и кирка
-- +15%. Итог: путь до пещеры 15 примерно в 2 раза дольше, чем было
-- (≈70 → ≈140 мин активной игры без пассов), а каждая мутация снова
-- заметная находка.
-- v20.66: двухэтапные мутации срезали их вклад ещё сильнее (средний
-- множитель цены руды ×1.74 → ×1.11), поэтому наценку на прокачку
-- вернули к 1.0 - одних редких мутаций хватает, чтобы путь стал заметно
-- длиннее (≈64 → ≈170 мин по симуляции). Хочешь ещё дольше - поднимай.
Config.ProgressionCostMult = { Mine = 1.0, Cart = 1.0, Pickaxe = 1.0 }
for _, entry in Config.MineChain do
	entry.BaseCost = entry.Cost
	entry.Cost = niceNumber(entry.Cost * Config.CaveNumberScale(entry.Tier - 1) * stretchFor(entry.Tier) * Config.ProgressionCostMult.Mine)
end
for kind, chain in { Cart = Config.CartChain, Pickaxe = Config.PickaxeChain } do
	for _, entry in chain do
		entry.BaseCost = entry.Cost
		local cave = caveForNineTierLocal(entry.Tier)
		entry.Cost = niceNumber(entry.Cost * Config.CaveNumberScale(cave) * stretchFor(cave) * (Config.ProgressionCostMult[kind] or 1))
	end
end

-- v3: отрыв веток больше не ограничивается (Б2). Оставлено числом, чтобы
-- старый код, если где-то читает поле, не падал на nil.
Config.BranchMaxGap = math.huge
-- Какие ветки упираются в кап ребёрта. Перки (тележка, кирка) — нет.
Config.TierCappedBranches = { Mine = true }

-- ДОХОД С ПОЛНОЙ ТЕЛЕЖКИ (средний дроп × вместимость × максимальное комбо),
-- без ребёртов/пассов. Единая «линейка» для цен, наград, пассивки, паков.
function Config.CartValue(mineTier, cartTier)
	local mine = Config.MineTiers[math.clamp(math.floor(tonumber(mineTier) or 1), 1, #Config.MineTiers)]
	local cart = Config.CartTiers[math.clamp(math.floor(tonumber(cartTier) or 1), 1, #Config.CartTiers)]
	if not (mine and cart) then return 0 end
	local thresholds = Config.Cart.ComboThresholds
	local maxCombo = thresholds[#thresholds] and thresholds[#thresholds].Multiplier or 1
	return mine.ExpectedValue * cart.Capacity * maxCombo
end

-- Примерная длительность рейса (минуты): заходы в шахту до полной тележки + дорога.
Config.Economy_TripSecondsPerExpedition = 25
Config.Economy_TripSecondsOverhead = 30
function Config.TripMinutes(mineTier, cartTier)
	local mine = Config.MineTiers[math.clamp(math.floor(tonumber(mineTier) or 1), 1, #Config.MineTiers)]
	local cart = Config.CartTiers[math.clamp(math.floor(tonumber(cartTier) or 1), 1, #Config.CartTiers)]
	if not (mine and cart) then return 2 end
	local expeditions = math.ceil(cart.Capacity / math.max(1, mine.OreYield))
	return (expeditions * Config.Economy_TripSecondsPerExpedition + Config.Economy_TripSecondsOverhead) / 60
end

-- Активный доход в минуту (без ребёртов/пассов).
function Config.IncomePerMinute(mineTier, cartTier)
	return Config.CartValue(mineTier, cartTier) / math.max(0.1, Config.TripMinutes(mineTier, cartTier))
end

--------------------------------------------------------------------------------
-- PVP
-- Урон одинаков для всех (Catch-Up: богатый — цель, а не угроза).
--------------------------------------------------------------------------------
Config.Combat = {
	KnockoutMin = 1, -- минимум кристаллов за удар (доля/максимум — в PickaxeTiers)

	-- Жёсткий потолок на кол-во руды, вылетающей ИЗ ТЕЛЕЖКИ за ОДИН удар —
	-- НЕЗАВИСИМО от тира кирки атакующего (у топовых тиров KnockoutMax в
	-- PickaxeTiers доходит до 18 — без этого потолка один удар мог вынести
	-- почти всю телегу разом). Руки жертвы (HandCarryService) этот потолок
	-- не трогает — там свой отдельный knockoutMax по тому же тиру.
	CartKnockoutMaxPerHit = 5,

	-- ХИТБОКС УДАРА: большой прямоугольный объём ВОКРУГ атакующего
	-- (центр совпадает с HumanoidRootPart), поэтому прежний охват сохраняется
	-- равномерно спереди, сбоку и сзади.
	-- Это ЖЕ САМАЯ геометрия, что рисует debugDrawHitbox — больше нет
	-- расхождения между "визуальным ориентиром" и реальным попаданием.
	-- Растёт вместе с тиром кирки (Config.PickaxeTiers[tier].Scale), как и
	-- сама модель кирки (см. PlaceholderFactory.Pickaxe).
	HitboxSize = Vector3.new(19, 17, 19), -- v20.118: было 15.5 - удар кирки дотягивается дальше
	HitboxForwardOffset = 0,
	HitboxActiveDuration = 0.02, -- хитбокс следует за атакующим ещё 20 мс
	SwingAnimationDuration = 1.9, -- полный замах: прежние 0.9 сек + 1 сек
	SwingReturnFadeTime = 0.22, -- v17: плавнее возврат из замаха в idle-позу (было 0.14)
	MaxPingCompensation = 0.15, -- учитываем не больше 150 мс, чтобы задержку нельзя было абьюзить
	MaxPingHitboxPadding = 2.5, -- максимальное расширение X/Z на высокой задержке

	-- МИКРО-СТАН: жертва на мгновение теряет скорость при попадании (см.
	-- CombatService:ApplyHit) — даёт атакующему реальное окно, а не
	-- мгновенный разворот жертвы обратно за выбитой рудой. Сопровождается
	-- лёгкой тряской на месте (см. StunShakeAmplitude ниже).
	MicroStunDuration = 1.5,

	-- ТРЯСКА ПРИ СТАНЕ: едва заметное дрожание персонажа на месте (не
	-- перемещение) на всё время микро-стана — чисто визуальная обратная
	-- связь "тебя оглушили", амплитуда нарочно крошечная.
	StunShakeAmplitude = 0.18, -- студы, в каждую сторону от текущей позиции
	StunShakeInterval = 0.05,  -- сек между "рывками" тряски

	-- ВЫБИТИЕ РУДЫ: гарантированно ОТ тележки/жертвы по радиусу (не
	-- случайный разброс) — физически не может приземлиться обратно внутрь
	-- тележки. На время полёта у выбитого кристалла отключена коллизия с
	-- источником (тележкой или самим игроком, см. CrystalService:MakeLoose),
	-- иначе застревал в её геометрии на едущей тележке.
	KnockoutEjectUpSpeed = NumberRange.new(18, 28),
	KnockoutEjectOutSpeed = NumberRange.new(14, 22), -- горизонтально, строго по радиусу наружу
	KnockoutEjectNoCollideTime = 0.6,

	-- РЕАЛЬНЫЙ CATCH-UP: раньше тир кирки давал разрыв не только по урону,
	-- но и по ЧАСТОТЕ выбития руды (через общий Cooldown замаха) — топ-тир
	-- фармил новичка кратно быстрее по всем трём осям сразу. Теперь выбитие
	-- руды (и из тележки, И из рук) ограничено ОБЩИМ кулдауном на САМУ
	-- ЖЕРТВУ, не зависящим от тира кирки атакующего: ЭТОГО игрока нельзя
	-- ограбить чаще раза в KnockoutCooldown секунд, даже если бьёт другой
	-- атакующий следом. HP-урон + микро-стан применяются КАЖДЫМ удачным
	-- ударом всегда, вне зависимости от этого кулдауна — тир кирки по-прежнему
	-- полностью решает, как быстро и часто прилетает урон (страх перед
	-- прокачанным противником никуда не делся), просто больше не решает,
	-- как часто можно физически обчищать карман.
	KnockoutCooldown = 7.5,

	-- БЕЗОПАСНЫЕ ЗОНЫ: своя база (весь PlotPad — см. PlotService) и зона
	-- сдачи руды в банке (SellZone — см. WorldService) НЕ являются PvP-зоной.
	-- Работает как позиционная проверка ЖЕРТВЫ (и тела, и тележки отдельно —
	-- см. findVictim/consider) — правило зоны, а не привязка к владельцу:
	-- защищён любой, кто физически стоит внутри, будь то хозяин базы или
	-- случайно забежавший чужак. Атаковать НАРУЖУ из зоны по-прежнему можно —
	-- защита только от того, чтобы самому стать целью. YPadding — запас по
	-- высоте поверх плоского Part зоны (иначе обычный прыжок/неровность
	-- рельефа технически "выводил" бы игрока за пределы зоны по Y).
	SafeZoneYPadding = 50,

	-- VFX-плейсхолдер на месте удара киркой (свой ассет "PickaxeHitVFX" из
	-- Assets — заменишь позже, см. PlaceholderFactory) — сколько живёт перед
	-- автоматическим удалением.
	HitVfxDuration = 0.8,
}

--------------------------------------------------------------------------------
-- PVP v2 — ШКАЛА ОГЛУШЕНИЯ + РАГДОЛЛ (см. CombatService, StaggerFX.client.lua,
-- shared/CombatUiBuilder.lua, tools/BuildAllUI.lua).
--
-- Удар киркой по игроку больше НЕ снимает HP и не бьёт по тележке в руках —
-- он заполняет шкалу оглушения над головой жертвы. Полная шкала → рагдолл
-- на RagdollSeconds, жертву отбрасывает, вылетает РОВНО 1 руда (самая
-- дорогая: сначала из рук, потом из тележки). Потом — неуязвимость.
-- Встречные удары в пределах ClashWindow = ПАРИРОВАНИЕ: оба отлетают,
-- шкала не растёт (очко, которое успел набить соперник, возвращается).
--------------------------------------------------------------------------------
Config.Stagger = {
	Enabled = true,
	PlayerHitsDealDamage = false, -- true вернёт старый урон по HP/тележке поверх шкалы

	-- Сколько ударов нужно на полную шкалу — по ТИРУ КИРКИ атакующего.
	HitsByPickaxeTier = { 4, 4, 3, 3, 3, 3, 2, 2, 2 },
	-- Пасс DoubleDamage ускоряет заполнение, DoubleHealth жертвы — замедляет
	-- (вместо урона/здоровья, чтобы купленные пассы не потеряли смысл).
	DoubleDamageProgressMultiplier = 1.34,
	DoubleHealthProgressMultiplier = 0.75,

	Pips = 4,                 -- сколько делений рисует шкала (заполнение дробное)
	DecayDelay = 4,           -- сек без ударов, после которых шкала начинает спадать
	DecayPerSecond = 0.35,    -- доля шкалы в секунду при спаде

	RagdollSeconds = 4, -- v20.104: +1 сек (было 3)
	ImmunitySeconds = 3,      -- после подъёма: удары не заполняют шкалу
	KnockbackSpeed = 42,      -- горизонтальный отлёт при рагдолле
	KnockbackUp = 30,

	DropCount = 2,            -- v20.104: каждый нокдаун = -2 руды (рука → инвентарь → в руках → тележка)

	-- ПАРИРОВАНИЕ (только встречные удары, отдельной кнопки блока нет).
	ClashWindow = 0.3,        -- оба замахнулись друг на друга в пределах этого окна
	ClashFacingDot = 0.2,     -- «смотрит на соперника» (скалярное произведение)
	ClashKnockback = 30,
	ClashKnockUp = 14,

	-- НАГРАДА ЗА ГОЛОВУ: у игрока с загруженной тележкой над головой
	-- появляется компактный значок 💰$X. Кто уронит его в рагдолл — получает
	-- X (деньги из воздуха, у жертвы сверх 1 руды ничего не списывается).
	-- Выплачивается ОДИН раз, пока тележка снова не опустеет ниже порога.
	BountyEnabled = true,
	BountyMinFill = 0.7,      -- доля заполнения тележки, с которой объявляется награда
	BountyShare = 0.15,       -- награда = доля текущей стоимости тележки (с комбо)
	BountyRefresh = 1,        -- сек, как часто пересчитывается значок

	-- КОМБО-СЧЁТЧИК атакующего (чисто визуальный).
	ComboWindow = 3,          -- сек между попаданиями, чтобы серия не прервалась

	-- Шаблоны интерфейса (tools/BuildAllUI.lua → StarterGui/CombatUi).
	UiVersion = 1,
	BillboardMaxDistance = 90,
	BillboardHeight = 3.1,
}

--------------------------------------------------------------------------------
-- ЗАЩИТА: временная неуязвимость от атак — кнопка на экране (рядом с
-- кнопкой "Заспавить тележку"). Защищённого нельзя атаковать вообще
-- (findVictim в CombatService его пропускает), но если он САМ атакует
-- кого-то — щит тут же спадает (наказание за агрессивное использование,
-- честная "передышка", а не бесплатная неуязвимость для охоты на других).
--------------------------------------------------------------------------------
Config.Protection = {
	FreeDuration = 30,  -- сек защиты бесплатно
	FreeCooldown = 180, -- сек до следующей бесплатной активации

	-- Разовая защита новичку при самом первом заходе (см. DataService:LoadProfile) —
	-- покрывает прохождение гайда и первые пару апгрейдов шахты, чтобы не
	-- умереть/не быть ограбленным раньше, чем разберётся в игре. НЕ
	-- складывается по кругу — активируется один раз при первом заходе.
	NewbieDuration = 300,

	-- Платное продление — требует настоящего Developer Product в Roblox
	-- (создаётся вручную в Studio/Creator Dashboard, см. README). ID = 0 —
	-- продукт ещё не создан, кнопка покупки будет неактивна/предупредит.
	-- Разовая покупка (Developer Product), НЕ навсегда — в отличие от
	-- геймпасса GoldenShield (Config.GamePasses.GoldenShield) ниже, который
	-- меняет саму БАЗОВУЮ бесплатную защиту навсегда. Эти два эффекта
	-- складываются: владелец GoldenShield тоже может докупить +80 сек сверху.
	PaidDuration = 80,   -- сек, которые добавляет платное продление
	PaidProductId = 3711468020,
	PriceRobux = 9, -- v10: «щит сейчас» — дешёвая импульсная покупка

	-- Единый зелёный цвет щита — им же красится и VFX над тележкой, и
	-- обводка (Highlight) игрока/тележки, и индикатор на кнопке в UI.
	Color = Color3.fromRGB(120, 255, 150),
	-- На какой высоте над ГОЛОВОЙ ДЕРЖАТЕЛЯ висит VFX щита (см.
	-- CombatService — приварен к Head, едет вместе с персонажем, не с
	-- тележкой). Меньше, чем раньше (было 7 — рассчитано на то, чтобы
	-- перекрыть всю тележку сверху; над головой столько не нужно).
	VfxHeight = 3,
}

--------------------------------------------------------------------------------
-- МОНЕТИЗАЦИЯ
-- Все Id — плейсхолдеры (0). Создаёшь Game Pass/Developer Product в Creator
-- Dashboard → вписываешь сюда реальный Id → дальше ничего в коде трогать не
-- нужно (MonetizationService сам подхватит). Пока Id = 0 — эффект просто
-- никому не выдаётся (ownership-чек на Id=0 всегда false), игра не падает.
--
-- GAME PASS (разовая покупка, эффект НАВСЕГДА, кэшируется на игрока при
-- входе в MonetizationService — см. UserOwnsGamePassAsync там же).
--------------------------------------------------------------------------------
Config.GamePasses = {
	----------------------------------------------------------------------------
	-- v10: НОВЫЙ НАБОР ГЕЙМПАССОВ (дешёвые, «импульсные» 49–149 R$).
	-- PriceRobux здесь — только для отображения; реальную цену ставишь в
	-- Creator Hub (Monetization → Passes). Id = 0 — пасс ещё не создан:
	-- в магазине кнопка неактивна, эффект никому не выдаётся.
	----------------------------------------------------------------------------
	DoubleCash = {   -- 💰 2x Money: ×2 к продаже руды
		Id = 1966130783, Multiplier = 2, PriceRobux = 99,
	},
	DoubleLuck = {   -- 🍀 2x Luck: ×2 шанс мутаций + наклон к редкой руде
		Id = 1967851320, PriceRobux = 129, OreLuck = 0.2, MutationMultiplier = 2,
	},
	OreMagnet = {    -- 🧲 руда сама летит к тебе, большой радиус подбора
		Id = 2003174297, PriceRobux = 69, PickupRadius = 22,
	},
	ExtraPouch = {   -- 🎒 Mega Backpack: +12 слотов, больше стак
		Id = 1966154793, BonusCapacity = 2, BonusSlots = 12, PriceRobux = 49,
	},
	GeodeMaster = {  -- 🪨 открытие по 3/5 + автовскрытие (без тапанья)
		Id = 1966202799, PriceRobux = 59,
	},
	DemolitionExpert = { -- 🧨 откат динамита ×0.5 + 1 бесплатный динамит своего уровня в день
		Id = 1998819611, PriceRobux = 79, CooldownMultiplier = 0.5, DailyFreeSeconds = 20 * 3600,
	},
	CartGuard = {    -- 🛡 щит тележки дольше, откат щита короче, золотая обводка
		Id = 1966819564, PriceRobux = 59, Duration = 60, Cooldown = 90,
		OutlineColor = Color3.fromRGB(255, 215, 60),
	},
	FastSmelter = {  -- ⚡ печь ×2 быстрее, +1 слот
		Id = 1970684830, PriceRobux = 49, SpeedMultiplier = 0.5, BonusSlots = 1,
	},
	RocketPickaxe = { -- 🚀 см. Config.RocketPickaxe
		Id = 1999701550, PriceRobux = 149,
	},
	DoubleDrops = {  -- 2x награды из жеод (оставлен, подешевел)
		Id = 1968449069, RewardCount = 2, PriceRobux = 39,
	},
	AutoHammer = {   -- v20.80: 🔨 автоудар при раскалывании жеод (кнопка AUTO в сцене)
		Id = 1999329630, PriceRobux = 49,
	},
	DoubleSafe = {   -- v4: 🏦 2x Safe Income — пассивка кристалла на подиуме ×2 (OreIncome.PerMinuteForPlayer)
		Id = 2003618262, Multiplier = 2, PriceRobux = 79,
	},

	----------------------------------------------------------------------------
	-- СТАРЫЕ ПАССЫ — сняты с продажи (Legacy). Их Id проверяются, и владельцу
	-- выдаются новые пассы из GrantsTo (см. MonetizationService). Не удалять,
	-- пока в игре есть их владельцы.
	----------------------------------------------------------------------------
	QuadCash = { Id = 1968313301, Legacy = true, GrantsTo = { "DoubleCash", "DoubleLuck" } },
	OctupleCash = { Id = 1969483065, Legacy = true, GrantsTo = { "DoubleCash", "DoubleLuck" } },
	GoldenShield = { Id = 1968217308, Legacy = true, GrantsTo = { "CartGuard" } },
	SpeedBoost = { Id = 1968685101, Legacy = true, GrantsTo = { "CartGuard" } },
	DoubleDamage = { Id = 1966268777, Legacy = true, GrantsTo = { "CartGuard" } },
	TripleGeodeOpen = { Id = 1969119088, Legacy = true, GrantsTo = { "GeodeMaster" } },
	-- v20.112: SextupleCash / DoubleHealth / FastMining / FiveGeodeOpen убраны -
	-- их Id теперь у новых пассов DoubleLuck / CartGuard / FastSmelter / GeodeMaster.
}

Config.CashPasses = { "DoubleCash" }
Config.CashPassMode = "Highest"

--------------------------------------------------------------------------------
-- v10: 🚀 ROCKET PICKAXE (геймпасс). Включается кнопкой/клавишей R.
-- Плюс: удар по игроку сразу валит в рагдолл и далеко отбрасывает.
-- Минусы: большой откат этого удара; пока режим включён — кирка слабо
-- копает (валуны, шахта), медленнее машет.
--------------------------------------------------------------------------------
Config.RocketPickaxe = {
	SkinId = "TurboPickaxe", -- v10: это СКИН кирки, а не отдельная кнопка
	-- v20.65: без кнопки/иконки на экране. Надел скин - готовый удар по
	-- игроку подкидывает его ВВЕРХ с кувырками и рагдоллом.
	Cooldown = 18,              -- сек между «ракетными» ударами
	KnockbackSpeed = 25,        -- в сторону (было 120 - улетал вдаль)
	KnockbackUp = 115,          -- вверх (обычный: 30)
	Spin = 16,                  -- кувырки в полёте
	HitStop = 0.08,             -- миг «замирания» перед взлётом
	RagdollSeconds = 3.5,
	DropCount = 1,
	-- Дебаффы, пока режим включён:
	MineYieldMultiplier = 0.5,  -- руды из шахты за раскопку
	BoulderHitsMultiplier = 1.8, -- ударов на валун больше
	DamageMultiplier = 0.4,     -- урон кирки (тележки, завалы)
	SwingCooldownMultiplier = 1.35,
}

--------------------------------------------------------------------------------
-- v10: КОНТЕКСТНЫЕ ПРЕДЛОЖЕНИЯ (OfferPrompts.client.lua) — маленькие кнопки
-- с ценой в тот момент, когда товар нужен. ShowWithoutId = true покажет
-- кнопки даже у товаров с Id = 0 (для проверки в Studio).
--------------------------------------------------------------------------------
Config.Offers = {
	ShowWithoutId = false,
	ShieldThreatRadius = 28,     -- чужой игрок ближе — предлагаем щит (если несёшь телегу)
	RevengeWindow = 90,          -- сек, пока можно «вернуть украденное»
	RevengeShare = 0.5,          -- какую долю потерянного возвращает покупка
	CartFillAtLeast = 0.5,       -- тележка заполнена ≥ 50% — предлагаем «заполнить»
	MineRushRadius = 26,         -- стоишь у своей шахты — предлагаем Mine Rush
	HideSeconds = 45,            -- после закрытия/игнора то же предложение не всплывает
}

--------------------------------------------------------------------------------
-- DEVELOPER PRODUCT (расходуемая, повторная покупка — обрабатывается в
-- ЕДИНСТВЕННОМ MarketplaceService.ProcessReceipt на всю игру, который живёт
-- в MonetizationService — см. предупреждение там же про то, почему нельзя
-- заводить второй такой колбэк где-то ещё).
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
-- v20.82: ДОНАТЫ «SUPPORT US» - девпродукты без игровой выдачи: просто
-- поддержать игру. Каждая покупка идёт в TOP DONATION (RobuxSpent), игроку
-- - «спасибо», серверу - объявление (AnnounceFrom и дороже).
-- Id = 0 - товар ещё не создан (в магазине карточка неактивна). Создай
-- Developer Product в Creator Hub с этой ценой и впиши Id.
--------------------------------------------------------------------------------
Config.Donations = {
	AnnounceFrom = 100, -- от скольки R$ объявлять всему серверу
	Items = {
		{ Key = "Donate10",   Id = 3715529117, PriceRobux = 10,   Title = "🍬 Candy",        Description = "A tiny thank-you!" },
		{ Key = "Donate50",   Id = 3715529154, PriceRobux = 50,   Title = "☕ Coffee",       Description = "Keeps the devs awake!" },
		{ Key = "Donate100",  Id = 3715529201, PriceRobux = 100,  Title = "🍕 Pizza",        Description = "Fuel for a new update!" },
		{ Key = "Donate500",  Id = 3715529250, PriceRobux = 500,  Title = "💎 Diamond Fan",  Description = "You're amazing! Top Donation board!" },
		{ Key = "Donate1000", Id = 3715529301, PriceRobux = 1000, Title = "👑 Legend",       Description = "A true legend of the mine!" },
		{ Key = "Donate5000", Id = 3715529332, PriceRobux = 5000, Title = "🌟 Mega Patron",  Description = "Your statue deserves the plaza!" },
	},
}

Config.DevProducts = {
	-- ПОГОДНЫЕ ИВЕНТЫ ЗА ROBUX — по прямому запросу, самые первые в списке
	-- dev-продуктов. Покупка мгновенно запускает соответствующий ивент
	-- (см. Config.WeatherEvents) для ВСЕГО сервера — та же механика, что и
	-- у админ-панели (WeatherService:ForceEvent), но без проверки прав:
	-- сама покупка и есть допуск (см. WeatherService:PurchaseTriggerEvent
	-- и её вызов из MonetizationService.lua). Цена растёт вместе с
	-- редкостью/силой ивента — Solar Eclipse (самый редкий в естественном
	-- ролле, 1%, плюс гарантированная мутация части руды) стоит заметно
	-- больше остальных.
	-- v10: цены снижены — поменяй их и в Creator Hub.
	WeatherNight = { Id = 3711466808, PriceRobux = 19, EventId = "Night" },
	WeatherRain = { Id = 3711466844, PriceRobux = 25, EventId = "Rain" },
	WeatherThunderstorm = { Id = 3711466903, PriceRobux = 35, EventId = "Thunderstorm" },
	WeatherBloodMoon = { Id = 3711466978, PriceRobux = 49, EventId = "BloodMoon" },
	WeatherSolarEclipse = { Id = 3711467023, PriceRobux = 79, EventId = "SolarEclipse" },

	-- ПРЯМАЯ ПАЧКА ДЕНЕГ В КОШЕЛЁК.
	--
	-- Суммы подняты вслед за подорожавшей прокачкой (см. Config.MineChain
	-- и комментарий там). Множитель у каждого пака СВОЙ, а не общий, потому
	-- что цены прокачки выросли неравномерно: раннее начало почти не
	-- тронуто (×1.6), поздние тиры подорожали сильно (×4.0). Каждый пак
	-- продаётся игроку на своей стадии игры, поэтому масштабировать их
	-- одним числом было бы неверно — Small обесценился бы меньше, чем
	-- Large.
	--
	-- Считалось так, чтобы пак давал РОВНО ТУ ЖЕ долю прогресса, что и до
	-- ребаланса (доля = сумма пака / цена поднять все 3 ветки на тир,
	-- характерный для стадии этого пака):
	--
	--   Small  250K → 400K   (×1.6): было 1.85 тира на стадии T1, стало 1.95
	--   Medium 2.5M → 6.5M   (×2.6): было 1.72 тира на стадии T2, стало 1.71
	--   Large  100M → 300M   (×3.0): было 0.80 тира на стадии T4, стало 0.79
	--
	-- ВАЖНО: подписи карточек в Config.Shop.Items ниже ("$400K Cash" и
	-- т.п.) теперь СЧИТАЮТСЯ ИЗ ЭТИХ ЖЕ ЧИСЕЛ автоматически (см. cashLabel).
	-- Раньше они были вписаны текстом руками и разъехались бы с реальной
	-- выдачей при любой правке суммы — а это уже не косметика, а неверное
	-- описание платного товара.
	-- Amount пересчитан вместе со сменой масштаба экономики (÷100, см.
	-- Config.Crystal_BaseValue) — цена в Robux не меняется, меняется только
	-- сколько игровых денег пак выдаёт. Title в Config.Shop.Items считается
	-- из Amount автоматически (см. cashLabel там же).
	-- Суммы пересчитаны под ТЕКУЩИЙ масштаб экономики (см. тот же комментарий
	-- у StarterPack ниже) — на старых цифрах (4,000/65,000/3,000,000) самый
	-- маленький пак стоил бы меньше 10 рейсов на тир-1 (480 за рейс с
	-- комбо), то есть практически ничего не решал. $/Robux растёт с
	-- размером пака (стандартный стимул "бери больше — выгоднее"), но
	-- ВСЕ они ниже, чем у StarterPack (см. ниже) — одноразовое предложение
	-- новичку остаётся лучшей ставкой в магазине специально.
	-- v3: паки дают «N минут твоего дохода» (Config.MoneyPackAmount) —
	-- ценность пака одинаковая на любом этапе игры. Amount — минимальная
	-- сумма (для самого начала). Бонус «бери больше — выгоднее» — в минутах.
	MoneyPackSmall = { Id = 3711467104, Minutes = 15, Amount = 600, PriceRobux = 25 },
	MoneyPackMedium = { Id = 3711467797, Minutes = 45, Amount = 2000, PriceRobux = 59 },
	MoneyPackLarge = { Id = 3711467883, Minutes = 100, Amount = 5000, PriceRobux = 119 },

	----------------------------------------------------------------------------
	-- v10: МИКРОТРАНЗАКЦИИ (повторяемые). Выдача — MonetizationService
	-- (ветка Micro). Id = 0 — ещё не создан в Creator Hub.
	----------------------------------------------------------------------------
	Micro = {
		GetUp          = { Id = 3715529524, PriceRobux = 5,  Title = "Get Up Now", Icon = "🧍" },
		Revenge        = { Id = 3715529596, PriceRobux = 19, Title = "Get Back 50%", Icon = "💢" },
		DynamiteSmall  = { Id = 3715529650, PriceRobux = 9,  Title = "5 Small Dynamite", Icon = "🧨", Gear = "Dynamite", Count = 5 },
		DynamiteMedium = { Id = 3715529713, PriceRobux = 19, Title = "5 Dynamite Bundles", Icon = "🧨", Gear = "Dynamite_Medium", Count = 5 },
		DynamiteMega   = { Id = 3715529763, PriceRobux = 29, Title = "3 Mega TNT", Icon = "💣", Gear = "Dynamite_Mega", Count = 3 },
		MineRush       = { Id = 3715529830, PriceRobux = 15, Title = "Mine Rush x2 (3 digs)", Icon = "⛏", Charges = 3 },
		PerfectStrike  = { Id = 3715529899, PriceRobux = 9,  Title = "Perfect Boulder", Icon = "🎯", Charges = 1 },
		LuckPotion     = { Id = 3715530010, PriceRobux = 19, Title = "Luck x2 · 15 min", Icon = "🍀", Seconds = 15 * 60, OreLuck = 0.15, MutationMultiplier = 2 },
		ServerLuck2    = { Id = 3715530063, PriceRobux = 49, Title = "SERVER Luck x2 · 15 min", Icon = "🌐", Seconds = 15 * 60, OreLuck = 0.12, MutationMultiplier = 2 },
		ServerLuck3    = { Id = 3715530116, PriceRobux = 99, Title = "SERVER Luck x3 · 30 min", Icon = "🌐", Seconds = 30 * 60, OreLuck = 0.2, MutationMultiplier = 3 },
		MoneyRush      = { Id = 3715530172, PriceRobux = 15, Title = "Money x2 · 5 min", Icon = "💵", Seconds = 5 * 60 },
		SmeltNow       = { Id = 3715530244, PriceRobux = 5,  Title = "Finish Smelting", Icon = "🔥" },
		-- Личный перезаброс стока торговца (кнопка RESTOCK в его окне). Id
		-- создать в Creator Dashboard; при 0 кнопка сообщает, что покупка
		-- не настроена.
		MerchantRestock = { Id = 3715530311, PriceRobux = 19, Title = "Merchant Restock", Icon = "🔄" },
		-- v4: сейф сразу заполняется до потолка (3 ч дохода текущего кристалла).
		-- Без кристалла на подиуме — FallbackMinutes твоего активного дохода.
		FillSafe = { Id = 3715530363, PriceRobux = 29, Title = "Fill the Safe", Icon = "🏦", FallbackMinutes = 30 },
	},

	-- v4: СКИП ПРОКАЧКИ — отдельный Developer Product на КАЖДЫЙ тир каждой
	-- ветки (индекс = тир, который покупается). Покупка доводит деньги
	-- игрока ровно до цены этого шага и сразу проводит апгрейд обычной
	-- логикой (UpgradeService). Если шаг уже куплен другим путём — деньги
	-- (полная цена шага) остаются на счету. Кнопка «⚡ SKIP R$X» видна в
	-- окне улучшений, когда денег не хватает и у шага Id ~= 0.
	UpgradeSkip = {
		Mine = {
			[2] = { Id = 0, PriceRobux = 9 },
			[3] = { Id = 0, PriceRobux = 9 },
			[4] = { Id = 0, PriceRobux = 12 },
			[5] = { Id = 0, PriceRobux = 12 },
			[6] = { Id = 0, PriceRobux = 15 },
			[7] = { Id = 0, PriceRobux = 19 },
			[8] = { Id = 0, PriceRobux = 25 },
			[9] = { Id = 0, PriceRobux = 29 },
			[10] = { Id = 0, PriceRobux = 35 },
			[11] = { Id = 0, PriceRobux = 39 },
			[12] = { Id = 0, PriceRobux = 49 },
			[13] = { Id = 0, PriceRobux = 59 },
			[14] = { Id = 0, PriceRobux = 69 },
			[15] = { Id = 0, PriceRobux = 79 },
		},
		Cart = {
			[2] = { Id = 0, PriceRobux = 9 },
			[3] = { Id = 0, PriceRobux = 12 },
			[4] = { Id = 0, PriceRobux = 15 },
			[5] = { Id = 0, PriceRobux = 19 },
			[6] = { Id = 0, PriceRobux = 25 },
			[7] = { Id = 0, PriceRobux = 35 },
			[8] = { Id = 0, PriceRobux = 45 },
			[9] = { Id = 0, PriceRobux = 59 },
		},
		Pickaxe = {
			[2] = { Id = 0, PriceRobux = 5 },
			[3] = { Id = 0, PriceRobux = 9 },
			[4] = { Id = 0, PriceRobux = 9 },
			[5] = { Id = 0, PriceRobux = 12 },
			[6] = { Id = 0, PriceRobux = 15 },
			[7] = { Id = 0, PriceRobux = 19 },
			[8] = { Id = 0, PriceRobux = 25 },
			[9] = { Id = 0, PriceRobux = 35 },
		},
	},

	-- Повторяемая покупка моментального заполнения. Для каждого тира нужен
	-- отдельный Developer Product с указанной ценой в Creator Dashboard:
	-- дешёвый продукт не должен заполнять более дорогую тележку после апгрейда.
	CartFillByTier = {
		[1] = { Id = 3711468119, PriceRobux = 5, MaxCrystals = Config.CartTiers[1].Capacity },
		[2] = { Id = 3711468144, PriceRobux = 6, MaxCrystals = Config.CartTiers[2].Capacity },
		[3] = { Id = 3711468180, PriceRobux = 8, MaxCrystals = Config.CartTiers[3].Capacity },
		[4] = { Id = 3711468213, PriceRobux = 9, MaxCrystals = Config.CartTiers[4].Capacity },
		[5] = { Id = 3711468279, PriceRobux = 11, MaxCrystals = Config.CartTiers[5].Capacity },
		[6] = { Id = 3711468369, PriceRobux = 13, MaxCrystals = Config.CartTiers[6].Capacity },
		[7] = { Id = 3711468436, PriceRobux = 16, MaxCrystals = Config.CartTiers[7].Capacity },
		[8] = { Id = 3711468491, PriceRobux = 20, MaxCrystals = Config.CartTiers[8].Capacity },
		[9] = { Id = 3711468550, PriceRobux = 25, MaxCrystals = Config.CartTiers[9].Capacity },
	},

	-- "СКИП РЕБЁРТА" — покупка добавляет игроку РОВНО недостающую сумму до
	-- цены его ТЕКУЩЕГО ребёрта (не даёт денег сверху, не даёт денег, если
	-- их и так хватает) и сразу же пытается провести ребёрт (см.
	-- MonetizationService/RebirthService:_tryRebirth). Если 3 ветки ещё не
	-- прокачаны до тир-капа — деньги всё равно зачисляются, просто ребёрт
	-- не срабатывает автоматически (сработает, когда игрок докачается).
	--
	-- Индекс — НОМЕР ребёрта, на который копит игрок (GetRebirths+1), а НЕ
	-- тир шахты — тот же принцип роста цены, что у CartFillByTier: чем
	-- дальше по прогрессии, тем дороже цена ребёрта (см. Config.Rebirth.
	-- CostGrowth = 10x за ребёрт), тем больше денег в среднем придётся
	-- доложить, поэтому и цена скипа растёт. Если ребёртов больше 10 —
	-- используется цена последнего индекса (см. RebirthSkipPriceFor ниже).
	--
	-- Id заполнены реальными Developer Product'ами из Creator Dashboard.
	RebirthSkip = {
		[1] = { Id = 3711468698, PriceRobux = 15 },
		[2] = { Id = 3711468808, PriceRobux = 19 },
		[3] = { Id = 3711468872, PriceRobux = 25 },
		[4] = { Id = 3711468922, PriceRobux = 33 },
		[5] = { Id = 3711468963, PriceRobux = 44 },
		[6] = { Id = 3711469010, PriceRobux = 58 },
		[7] = { Id = 3711469047, PriceRobux = 76 },
		[8] = { Id = 3711469179, PriceRobux = 100 },
		[9] = { Id = 3711469262, PriceRobux = 133 },
		[10] = { Id = 3711469305, PriceRobux = 180 },
	},

	-- "Купить жеоду" — по ОДНОЙ штуке нужного типа за покупку, повторяемо
	-- сколько угодно раз (умышленно Developer Product, а не Game Pass: Game
	-- Pass у Roblox покупается на аккаунт ровно ОДИН раз навсегда, повторно
	-- купить нельзя — для расходуемого товара это не подходит).
	--
	-- Id заполнены реальными Developer Product'ами из Creator Dashboard
	-- (по одному на каждый тип жеоды, см. Config.Geodes.Order). PriceRobux —
	-- декоративный текст для кнопки в UI, должен совпадать с реальной
	-- ценой продукта в Dashboard.
	--
	-- ВАЖНО (Roblox-политика "Random Item Generators"): жеода при открытии
	-- выдаёт случайную награду (см. GeodeService:OpenGeode — руда/деньги/
	-- скин/пыль по шансам). Если жеода продаётся за Robux (пусть даже
	-- косвенно, как здесь), шансы выпадения ОБЯЗАНЫ быть видны игроку прямо
	-- в игре — в этом проекте это уже показывает панель DropInfoPanel
	-- (кнопка "i" на карточке жеоды в GeodeUI.client.lua). Не убирай её и
	-- держи актуальной, если меняешь шансы.
	GeodePacks = {
		Stone   = { Id = 3711469407, PriceRobux = 9 },
		Crystal = { Id = 3711469488, PriceRobux = 15 },
		Amber   = { Id = 3711469546, PriceRobux = 19 },
		Topaz   = { Id = 3711469593, PriceRobux = 25 },
		Jade    = { Id = 3711469635, PriceRobux = 35 },
		Onyx    = { Id = 3711469687, PriceRobux = 45 },
		Aurora  = { Id = 3711469725, PriceRobux = 55 },
		Nebula  = { Id = 3711469766, PriceRobux = 65 },
		-- Тиры 9-10 раньше нельзя было купить за робуксы вообще (только
		-- добыча на своём тире шахты) — теперь тоже доступны, с реальными
		-- Developer Product Id из Creator Dashboard.
		Quasar      = { Id = 3711469815, PriceRobux = 79 },
		Singularity = { Id = 3711469837, PriceRobux = 89 },
	},

	-- СТАРТОВЫЙ ПАК — по прямому запросу переделан из "сборной солянки"
	-- (деньги + скин + щит + перманентные флаги ExtraPouch/SpeedBoost) в
	-- ЧИСТЫЙ донат деньгами — как и остальные Money Pack'и выше, просто
	-- отдельная, более щедрая ставка специально для НОВОГО игрока (тот же
	-- принцип "первая покупка выгоднее" сохранён, просто без лишней
	-- механики поверх денег). Skin/ShieldSeconds ниже НЕ убраны из кода
	-- нарочно — MonetizationService и так пропускает их, если поле nil
	-- (см. "if pack.Skin and ..."/"if pack.ShieldSeconds and ..."), но
	-- сама выдача ExtraPouch/SpeedBoost теперь убрана из кода (см.
	-- MonetizationService:ProcessReceipt) — оставлять её включённой при
	-- пустых полях означало бы тихо продолжать раздавать бонус, который
	-- по конфигу как бы уже не входит в пак.
	--
	-- Money — сумма подобрана под ТЕКУЩИЙ масштаб экономики (после
	-- пересчёта цен апгрейдов на 3-8, затем ×3 до 9-24 рейсов за тир —
	-- см. Config.MineChain/CartChain/PickaxeChain) И так, чтобы ставка
	-- $/Robux (~859) была ЧЁТКО выше любого из трёх Money Pack'ов выше
	-- (лучший из них, Large, даёт ~655) — одноразовое предложение новичку
	-- обязано быть самой выгодной покупкой в магазине, иначе сама идея
	-- "специальной сделки" не работает.
	StarterPack = {
		Id = 3711467948,
		PriceRobux = 49,
		WorthRobux = 199, -- v10: зачёркнутая «стоит» цена в предложении
		Money = 3000,   -- v3: минимальная сумма; реально — Minutes твоего дохода
		Minutes = 60,
		OfferWindowSeconds = 600, -- 10 минут — окно, пока держится баннер-предложение у нового игрока (см. StarterPackUI.client.lua)
		-- Строки для экрана "что внутри" (StarterPackUI.client.lua строит их
		-- в столбик один в один по этому списку) — правишь текст тут, а не
		-- в самом билдере/раннере.
		Contents = {
			"1 HOUR OF CASH",
		},
	},
}

-- v3: сумма денежного пака/стартового пака для игрока с данными тирами.
-- rebirthMultiplier — множитель цены руды от ребёртов (DataService:GetCrystalMultiplier).
-- v20.38: НЕ ХВАТАЕТ ДЕНЕГ → ПОВТОРНЫЙ КЛИК → ОКНО ПОКУПКИ ПАКА ДЕНЕГ.
-- Игрок жмёт покупку (прокачка, торговец, динамит, острова, престиж), денег
-- нет → обычное «Not enough money». Жмёт ТО ЖЕ САМОЕ ещё раз в течение
-- RepeatSeconds → Roblox-окно покупки пака, которого хватит на недостающую
-- сумму (самый дешёвый подходящий из Packs; не хватит ни одного — самый
-- крупный). После показа — пауза CooldownSeconds. Паки с Id = 0 пропускаются.
Config.MoneyPackOffer = {
	Enabled = true,
	RepeatSeconds = 6,
	CooldownSeconds = 20,
	Packs = { "MoneyPackSmall", "MoneyPackMedium", "MoneyPackLarge" },
}

function Config.MoneyPackAmount(pack, mineTier, cartTier, rebirthMultiplier)
	if type(pack) ~= "table" then return 0 end
	local floorAmount = tonumber(pack.Amount or pack.Money) or 0
	local minutes = tonumber(pack.Minutes) or 0
	if minutes <= 0 or not Config.IncomePerMinute then return floorAmount end
	local byIncome = minutes * Config.IncomePerMinute(mineTier, cartTier) * (tonumber(rebirthMultiplier) or 1)
	return math.floor(math.max(floorAmount, byIncome) + 0.5)
end

--------------------------------------------------------------------------------
-- РЕБЁРТ
-- НПС стоит на КАЖДОМ участке (не один общий у банка). Доступен, когда
-- ВСЕ 3 ветки прокачки этого игрока достигли текущего rebirth-cap (до T10).
-- Сброс всех трёх веток за постоянный множитель цены кристаллов.
--------------------------------------------------------------------------------
Config.Rebirth = {
	MultiplierPerRebirth = 0, -- v8: престиж больше не даёт множителей — только очки перков (Config.Prestige)
	SpeedBonusPerRebirth = 0, -- v8: скорость теперь перк Swift Feet
	SpeedBonusPerRebirthLegacy = 1.03125, -- каждый ребёрт: +1.03125 к WalkSpeed персонажа (на 50% меньше текущего бонуса), полностью применяется только без тележки
	CartSpeedBonusPercent = 0.05, -- с тележкой в руках — вместо полного плоского бонуса ребёртов, только 5% от обычной (без тележки) скорости ходьбы — иначе с полной тележкой набегало слишком много скорости
	ResetMoney = true,          -- ребёрт обнуляет и деньги (иначе он почти бесплатен)

	-- ТИР-КАП ОТ РЕБЁРТОВ: без единого ребёрта потолок тира — BaseTierCap
	-- (не физический максимум 10) во ВСЕХ 3 ветках. Каждый ребёрт поднимает
	-- потолок на TierCapPerRebirth, вплоть до MaxTierCap (= реальный предел
	-- цепочек, 9). Чтобы дойти до T9, нужно четыре rebirth при базе T5.
	-- v3: кап действует только на ПЕЩЕРУ (Config.TierCappedBranches). Первый
	-- ребёрт — после пещеры 5 (~35 мин игры), каждый ребёрт +2 пещеры.
	BaseTierCap = 15, -- v8: лимитов на пещеру нет (престиж — с Config.Prestige.MinCave)
	TierCapPerRebirth = 0,
	MaxTierCap = 15, -- v3: = число пещер (Config.MineChain + 1). Слайм больше не гейт ребёрта, так что его MaxLevel (9) с этим не связан.

	-- Денежная стоимость самого ребёрта — СВЕРХ того, что уже потрачено на
	-- прокачку до текущего потолка (тот прогресс так и так сбрасывается).
	-- Растёт геометрически с каждым следующим ребёртом.
	-- ЦЕНА РЕБЁРТА — тоже пересчитана, и здесь разрыв был самым диким:
	-- при старых 150M первый ребёрт стоил 0.4 ПОЛНОЙ ТЕЛЕЖКИ на тир-капе
	-- T5 (payout ~375M), то есть фактически выдавался бесплатно вместе с
	-- любой случайной ходкой. Даже шестой ребёрт стоил всего ~2 рейса.
	-- Теперь база 3B = ровно 8 полных рейсов на T5, а рост 10 (вместо 12)
	-- держит следующие ребёрты в коридоре 7-11 рейсов, вместо того чтобы
	-- сначала отставать от дохода, а потом резко улетать вперёд.
	-- ЦЕНА РЕБЁРТА пересчитана вместе с общей сменой масштаба экономики
	-- (см. Config.Crystal_BaseValue выше, 1000→10, тот же ÷100). Была
	-- откалибрована как "8 полных тележек на T5" под старую шкалу
	-- (3B ÷ 375M-payout); теперь то же соотношение (8 рейсов) на НОВЫЙ
	-- T5-payout (3.75M): 8 × 3,750,000 = 30,000,000. Рост (CostGrowth)
	-- не трогаем — это коэффициент, а не абсолютная сумма.
	-- v3: ≈3 полные тележки на пещере-капе; рост x3.4 = рост дохода за +2 пещеры.
	CostBase = 4100,
	CostGrowth = 3.4,
	-- v3: уровень слайма больше НЕ условие ребёрта — только бонус к продаже.
	-- v3: для ребёрта нужна только пещера на капе (перки можно не докачивать).
	RequireOnlyCappedBranches = true,

	-- РОСТ ЦЕНЫ ПОСЛЕ ТОГО, КАК ТИР-КАП УПЁРСЯ В MaxTierCap.
	--
	-- Зачем отдельное число: пока каждый ребёрт поднимает потолок тира на
	-- +1, доход игрока растёт примерно в 10 раз за ребёрт (следующий тир
	-- руды дороже примерно во столько же) — и CostGrowth = 10 ровно за ним
	-- поспевает. Но как только потолок дошёл до MaxTierCap (это происходит
	-- на ребёрте MaxTierCap - BaseTierCap = 4), новых тиров больше нет, и
	-- доход дальше растёт ТОЛЬКО за счёт MultiplierPerRebirth, то есть
	-- ЛИНЕЙНО (+50% от базы за ребёрт: x3.0 → x3.5 → x4.0 ...). Цена же
	-- продолжала расти геометрически ×10 — и разрыв мгновенно становился
	-- непроходимым (цифры ниже — из истории тюнинга ЕЩЁ ПРИ MaxTierCap=10,
	-- сам вывод/1.30 не поменялись со снижением потолка до 9): по расчёту
	-- ребёрт №7 стоил ~43 полных рейса, №8 — уже ~380. Это не "сложно",
	-- это глухая стена, за которой игра кончается.
	--
	-- 1.30 подобрано чуть выше реального прироста дохода на этом участке
	-- (он около +9..17% за ребёрт), поэтому каждый следующий ребёрт всё
	-- равно ощутимо дороже предыдущего — прогрессия продолжает замедляться,
	-- как и просили, — но остаётся проходимой сколько угодно долго
	-- (≈5 → 6 → 7 → 8 → 10 рейсов и так далее плавно вверх).
	LateCostGrowth = 1.30,
}

--------------------------------------------------------------------------------
-- ЭКОНОМИКА / ТЕМП ПРОГРЕССИИ (см. DataService.effectiveCost) — запрос
-- "прогрессию сделать дольше, цены в процентах от денежных бонусов, чтобы
-- x2/x4 деньги не давали покупать по несколько тиров за один заход".
--------------------------------------------------------------------------------
Config.Economy = {
	-- v3 — ребаланс «цифры слишком большие». Старые профили: деньги/сейф/слайм
	-- x LegacyMoneyScaleV3, индексы веток обрезаются до новых цепочек.
	Version = 3,
	LegacyMoneyScaleV3 = 0.0125,
	LegacyMoneyScale = 125,
	MaxCurrency = 1e300, -- практический предел BigNum: фактически без игрового потолка
	-- Общий множитель поверх базовых цен цепочек. Раньше был 2.07
	-- ("замедление ещё на 15%") — теперь 1 (выключен): цель по темпу
	-- прокачки (3→8 рейсов на тир) уже напрямую зашита в самих цифрах
	-- Config.MineChain/CartChain/PickaxeChain выше, второй множитель
	-- сверху был бы двойным счётом и снова замедлил бы всё в 2+ раза.
	ProgressionSlowdown = 1,
}

--------------------------------------------------------------------------------
-- КРИСТАЛЛЫ
--------------------------------------------------------------------------------
Config.Crystal = {
	LooseLifetime = 30,    -- сек жизни выбитого кристалла на земле
	PickupTweenTime = 0.35,
	PickupLockoutTime = 5,  -- сек, пока выбитый кристалл вообще нельзя подобрать (см. CrystalService:MakeLoose)
}

--------------------------------------------------------------------------------
-- РУДА В РУКАХ (без тележки)
-- Выбитые в PvP кристаллы (см. CombatService:_swing → CrystalService:MakeLoose)
-- можно подобрать не только в тележку, но и голыми руками — способ для тех,
-- кто не хочет угонять/тащить целую тележку. Компромисс "мало, но надёжно":
--   • Вместимость зависит ТОЛЬКО от тира кирки (растёт с прокачкой).
--   • НЕ выбивается повторно в PvP (см. HandCarryService) — но роняется
--     на землю при смерти держателя, как и содержимое тележки.
--   • Продаётся в той же зоне банка, что и тележка, но БЕЗ её
--     комбо-множителя — тележка остаётся более выгодным, но рискованным путём.
--------------------------------------------------------------------------------
Config.HandCarry = {
	-- Максимум кусков руды в руках по тиру кирки (индекс = тир 1..8).
	-- Растёт вместе с прокачкой кирки, но упирается в потолок на тире 5 —
	-- дальше кирка продолжает расти в бою (урон/кулдаун), не в переноске.
	CapacityByPickaxeTier = { 2, 4, 6, 8, 10, 10, 10, 10, 10, 10, 10 },

	-- ЗАМЕДЛЕНИЕ (отдельно от замедления тележки, см. Config.Cart) —
	-- линейно за каждый кусок на горбу, независимо от того, несёт ли игрок
	-- ещё и тележку одновременно (эффекты перемножаются, см. CartService).
	SlowdownPerItem = 0.055, -- ~5.5% скорости за штуку
	MaxSlowdown = 0.5,       -- потолок — даже с полными руками не встаёт колом
	ReturnToOwnerPerHit = 1, -- столько украденных кусков возвращается в тележку владельца за удар по вору
	-- Продажа руки БЕЗ комбо тележки, ЗАТО ворованный кусок (OwnerUserId
	-- принадлежит кому-то другому, см. HandCarryService:SellOne) продаётся
	-- с этим множителем — риск удачной кражи должен окупаться, а не
	-- обесцениваться до голой базовой цены. На СВОЮ переполненную руду (не
	-- украдена ни у кого) множитель не действует — руки для неё остаются
	-- осознанно слабее полной тележки, это не баг, а мотивация прокачивать
	-- вместимость.
	StolenOreMultiplier = 5,
}

--------------------------------------------------------------------------------
-- БАНК
--------------------------------------------------------------------------------
-- Общая таблица цветов редкости — переиспользуется и клиентом (GeodeUI/SkinUI),
-- и сервером (AnnounceService для цветных сообщений в чат про находки).
Config.RarityColors = {
	Common = Color3.fromRGB(205, 205, 205),
	Uncommon = Color3.fromRGB(100, 235, 130),
	Rare = Color3.fromRGB(95, 175, 255),
	Epic = Color3.fromRGB(195, 100, 255),
	Legendary = Color3.fromRGB(255, 190, 55),
	Mythic = Color3.fromRGB(235, 45, 95),
}

--------------------------------------------------------------------------------
-- МУТАЦИИ РУДЫ (см. src/server/Services/CrystalService.lua:Create) — по
-- образцу "Grow a Garden": редкий шанс при добыче (роллится в момент захода
-- куска руды в тележку, без предупреждения/подсветки заранее — сюрприз).
-- Независимые роллы — мутации МОГУТ комбинироваться на одном куске
-- (Multiplier'ы перемножаются между собой и с обычной ценой руды).
-- Порядок ниже используется и для роллов, и для сортировки в чат-сообщении.
--------------------------------------------------------------------------------
Config.Mutations = {
	-- ПОРЯДОК = ОТ ЧАСТЫХ К РЕДКИМ. На него опираются сразу три вещи:
	-- MutationRoll.Roll идёт по нему при броске, объявление в чат берёт
	-- ПОСЛЕДНЮЮ выпавшую как "самую редкую" (см. CrystalService), а книга
	-- коллекции рисует ячейки в этом же порядке.
	Order = {
		"Mossy", "Rusty", "Cracked", "Frozen", "Soaked", "Tiny", "Toxic", "Gigantic",
		"Void", "Electric", "Molten", "Sanguine", "Golden", "Radiant", "Glitched",
		"Prismatic", "Celestial", "Eclipsed",
	},

	-- ВЗАИМОИСКЛЮЧАЮЩИЕ ГРУППЫ: из одной группы выпадает максимум одна
	-- мутация. Пока нужна только для размера — руда не может быть
	-- одновременно гигантской и крошечной. Без группы результат зависел бы
	-- от того, какой Scale применился последним, то есть от порядка в Order,
	-- а множители при этом перемножились бы оба.
	ExclusiveGroups = {
		Gigantic = "Size",
		Tiny = "Size",
	},

	-- УДАЧА ОТ ПРОГРЕССА. Прибавка ОТНОСИТЕЛЬНАЯ (см. MutationRoll.
	-- EffectiveChance): при luck = 0.5 шанс становится в полтора раза выше
	-- базового. Работает только для мутаций с ScalesWithLuck = true, то есть
	-- для редких — иначе Mossy со своими 12% забил бы весь пул.
	--
	-- На 10 ребёртах и 10 тире шахты: 10*0.04 + 9*0.015 = 0.535, то есть
	-- +53.5% к базовому шансу. Celestial с 0.30% поднимется до 0.46%.
	LuckBonus = {
		PerRebirth = 0, -- v8: удача — перк Luck/Mutations
		PerMineTier = 0.015,
		MaxTotal = 1.5, -- жёсткий потолок: шанс не вырастет больше чем в 2.5 раза
	},

	-- ПОТОЛОК МУТАЦИИ ДЛЯ ПАССИВНОГО ДОХОДА. Множитель мутации применяется и
	-- к установленному в коллекции кристаллу (см. PassiveIncomeService), но
	-- НЕ целиком: Celestial со своими x15 на Titanheart дал бы 840 млрд/мин,
	-- а это 25% всего Config.Economy.MaxCurrency за одну суточную оффлайн-
	-- выплату. При потолке 3.0 получается около 5% — заметная награда, но
	-- экономика не заканчивается за четыре захода. На ПРОДАЖУ руды из шахты
	-- потолок не распространяется, там множитель работает полностью.
	-- Потолок бонуса мутаций к ПАССИВНОМУ доходу (на цену руды при продаже
	-- он не влияет — там мутации работают в полную силу).
	-- Снижен с 3.0 до 1.5 по прямому запросу («процент маленький от
	-- мутаций»). Причина не только в просьбе: пассивный доход теперь
	-- привязан к экономике самого игрока (см. OreIncome.lua), и множитель
	-- x3 поверх этой привязки означал бы, что одна удачная мутация даёт
	-- больше, чем два тира прогрессии подряд. x1.5 оставляет мутацию
	-- приятной находкой, но не заменой прокачке.
	IncomeMultiplierCap = 1.2, -- было 1.5 — часть общего нерфа пассивного дохода (см. Config.Geodes.PassiveIncomePercentOfCart)

	--------------------------------------------------------------------------
	-- ЧТО ИЗ ЭТОГО ПОПАДАЕТ В ЧАТ (см. CrystalService:Create → shouldAnnounce)
	--
	-- ПРОБЛЕМА, КОТОРУЮ ЭТО ЧИНИТ. Раньше в чат уходила ЛЮБАЯ мутация без
	-- исключений. При текущих шансах мутирует 43% всей руды, а шахта выдаёт
	-- кусок раз в 1.2-1.7 сек — то есть на сервере из 8 человек сообщение
	-- «X found a rare ... ore!» печаталось несколько раз В СЕКУНДУ. Редкая
	-- находка полностью терялась в потоке обычных: вау-эффекта не было ни у
	-- одной строки, потому что их было слишком много.
	--
	-- ИНДЕКСЫ НИЖЕ — ЭТО ПОЗИЦИИ В Order (см. выше), от частых к редким:
	--   1 Mossy   2 Rusty    3 Cracked   4 Frozen    5 Tiny      6 Toxic
	--   7 Gigantic 8 Void    9 Electric 10 Molten   11 Golden   12 Radiant
	--  13 Glitched 14 Prismatic 15 Celestial 16 Eclipsed
	-- Порядок и есть источник правды о редкости — отдельного «уровня
	-- редкости» заводить не пришлось.
	--
	-- ДВА ПРАВИЛА, ровно как задумано («только редкие и сочетания сразу
	-- нескольких»):
	--   • ОДНА мутация  → в чат, только если её индекс >= AnnounceSingleMinIndex
	--   • ДВЕ И БОЛЬШЕ  → в чат, только если САМАЯ РЕДКАЯ из них >= AnnounceComboMinIndex
	-- Порог для сочетаний намеренно НИЖЕ: две мутации сразу — уже само по
	-- себе событие, поэтому планка мягче. Но она есть: без неё в чат летели
	-- бы «Mossy + Rusty», а это 1.2% всей руды, то есть снова спам.
	--
	-- ЧТО ПОЛУЧАЕТСЯ НА ЭТИХ ЧИСЛАХ (посчитано симуляцией на 800k роллов):
	--   в чат уходит 0.89% всей руды вместо прежних 43% — в 48 раз меньше;
	--   ≈1 сообщение на игрока раз в 2.6 минуты, ≈3 в минуту на полном сервере.
	--
	-- Хочешь ещё реже — поднимай AnnounceSingleMinIndex до 15 (только
	-- Celestial/Eclipsed поодиночке). Хочешь чаще — опускай оба на 1-2.
	AnnounceSingleMinIndex = 14,
	AnnounceComboMinIndex = 13,

	-- ЖЁСТКИЙ ПОТОЛОК ЧАСТОТЫ, независимый от шансов выше. Сколько секунд
	-- обязано пройти между ЛЮБЫМИ двумя сообщениями о мутациях в чате
	-- (общий на весь сервер, не на игрока). Нужен как страховка: тир шахты
	-- и число игроков влияют на поток руды напрямую, и без этого потолка
	-- полный сервер на T10 снова превратил бы чат в ленту. Находка при этом
	-- не пропадает — она просто не печатается: книга мутаций
	-- (MutationBookService) и цена кристалла считаются как обычно.
	AnnounceGlobalCooldown = 20,

	-- ИСКЛЮЧЕНИЕ ИЗ ПОТОЛКА. Мутации с индексом >= этого печатаются ВСЕГДА,
	-- даже если кулдаун ещё не прошёл: Celestial (0.2%) и Eclipsed (0.1%) —
	-- это то самое событие, ради которого весь механизм и существует, его
	-- нельзя проглатывать из-за того, что секундой раньше кто-то нашёл
	-- Prismatic.
	AnnounceBypassCooldownIndex = 15,

	Rusty = {
		DisplayName = "Rusty",
		Chance = 0.10,
		Multiplier = 1.5,
		-- Визуал: вся модель в CorrodedMetal (штатный "ржавый" материал
		-- Roblox) — самая частая мутация, самый простой визуал.
		Visual = "MaterialSwap",
		Material = Enum.Material.CorrodedMetal,
		Color = Color3.fromRGB(150, 85, 45),
		IconId = 86749456196690,
	},
	-- v20.57: у мутаций, которые красят руду (MaterialSwap/Particles/Flicker/
	-- Rainbow), с мешей снимается текстура и SurfaceAppearance, иначе цвет и
	-- материал мутации не видны. false — оставить текстуры как есть.
	StripMeshTextures = true,
	Frozen = {
		DisplayName = "Frozen",
		Chance = 0.05,
		Multiplier = 2,
		-- Визуал: просто увеличенный прозрачный куб поверх модели (см.
		-- CrystalService:_applyMutationVisual, ветка "Shell").
		Visual = "Shell",
		ShellScale = 1.25,
		ShellTransparency = 0.55,
		Color = Color3.fromRGB(140, 210, 255),
		IconId = 126538759721150,
	},
	-- НОВАЯ МУТАЦИЯ — под систему погодных ивентов (см. Config.WeatherEvents,
	-- ивент "Rain"): подходящей "мокрой/дождевой" мутации в игре не было
	-- (Frozen — про лёд, тематически другое), поэтому завели отдельную.
	-- Визуал: глянцевое стекло (Glass, а не Neon/обычный материал — даёт
	-- "мокрый блеск" без лишнего источника света) + капли-частицы поверх.
	Soaked = {
		DisplayName = "Soaked",
		Chance = 0.045,
		Multiplier = 2.2,
		Visual = "MaterialSwap",
		Material = Enum.Material.Glass,
		Color = Color3.fromRGB(90, 150, 210),
		IconId = 0,
	},
	Void = {
		DisplayName = "Void",
		ScalesWithLuck = true,
		Chance = 0.021,
		Multiplier = 5,
		-- Визуал: вся модель в Neon, чёрно-фиолетовый — между Frozen и
		-- Molten по редкости.
		Visual = "MaterialSwap",
		Material = Enum.Material.Neon,
		Color = Color3.fromRGB(45, 15, 70),
		IconId = 99187993068732,
	},
	Molten = {
		DisplayName = "Molten",
		ScalesWithLuck = true,
		Chance = 0.017,
		Multiplier = 4,
		-- Визуал: вся модель целиком перекрашивается в Neon (без обводки/
		-- Highlight) — см. CrystalService:applyMaterialSwap. Цвет
		-- приглушённый оранжевый — Neon и так сильно светится сам по себе,
		-- слишком насыщенный/яркий оттенок был бы уже "слепящим".
		Visual = "MaterialSwap",
		Material = Enum.Material.Neon,
		Color = Color3.fromRGB(235, 130, 45),
		IconId = 90747633101368,
	},
	-- НОВАЯ МУТАЦИЯ — под систему погодных ивентов (см. Config.WeatherEvents,
	-- ивент "BloodMoon"): подходящей кроваво-красной мутации в игре не
	-- было (ни одна существующая не в этом цвете), поэтому завели новую.
	Sanguine = {
		DisplayName = "Sanguine",
		ScalesWithLuck = true,
		Chance = 0.015,
		Multiplier = 4.5,
		Visual = "MaterialSwap",
		Material = Enum.Material.Neon,
		Color = Color3.fromRGB(180, 15, 25),
		IconId = 0,
	},
	Radiant = {
		DisplayName = "Radiant",
		ScalesWithLuck = true,
		Chance = 0.0075,
		Multiplier = 10,
		-- Визуал: тот же прозрачный куб, что у Frozen, но цвет непрерывно
		-- бежит по радуге (см. _applyMutationVisual, ветка "RainbowShell").
		Visual = "RainbowShell",
		ShellScale = 1.45,
		ShellTransparency = 0.5,
		-- Сам визуал процедурно радужный (без фиксированного цвета), а это —
		-- только акцентный цвет для текста в чат-объявлении.
		Color = Color3.fromRGB(255, 215, 0),
		IconId = 130005396462921,
	},
	Celestial = {
		DisplayName = "Celestial",
		ScalesWithLuck = true,
		Chance = 0.002,
		Multiplier = 15,
		-- Визуал: вся модель в Neon, светло-синий — самая редкая мутация.
		Visual = "MaterialSwap",
		Material = Enum.Material.Neon,
		Color = Color3.fromRGB(120, 200, 255),
		IconId = 106103658699441,
	},
	--------------------------------------------------------------------------
	-- НОВЫЕ МУТАЦИИ. Все визуалы — чистый скрипт, без отдельных моделей (см.
	-- MutationVisuals). VFX-заготовки (искры, капли) лежат в
	-- PlaceholderFactory.MutationVfx и заменяются своими: положи Attachment с
	-- именем MutationVFX_<ИмяМутации> в ReplicatedStorage/Assets.
	--------------------------------------------------------------------------
	Mossy = {
		DisplayName = "Mossy",
		Chance = 0.12,
		Multiplier = 1.3,
		-- Самая частая мутация, поэтому и визуал самый спокойный: штатный
		-- материал Grass, приглушённый зелёный.
		Visual = "MaterialSwap",
		Material = Enum.Material.Grass,
		Color = Color3.fromRGB(95, 130, 65),
		IconId = 130456229961659,
	},
	Cracked = {
		DisplayName = "Cracked",
		Chance = 0.08,
		Multiplier = 1.8,
		-- Тёмная почти непрозрачная оболочка — руда выглядит "в сколах".
		-- Shell, а не MaterialSwap, чтобы не спорить с Mossy/Rusty за цвет.
		Visual = "Shell",
		ShellScale = 1.12,
		ShellTransparency = 0.72,
		Color = Color3.fromRGB(60, 55, 50),
		IconId = 109838712637324,
	},
	Tiny = {
		DisplayName = "Tiny",
		Chance = 0.04,
		Multiplier = 2.5,
		-- Взаимоисключающа с Gigantic (см. ExclusiveGroups).
		Visual = "Scale",
		ScaleFactor = 0.55,
		Color = Color3.fromRGB(180, 220, 255),
		IconId = 111788924594491,
	},
	-- v20.104: ИСТИННАЯ руда - вся руда с ВАЛУНОВ (не из шахты) получает её
	-- гарантированно, поверх обычных мутаций: +50% к цене, мотивация ломать
	-- валуны. Не случайная (Chance = 0, нет в Order), в книгу мутаций и
	-- объявления в чат не идёт; видна строкой «True» над рудой.
	True = {
		DisplayName = "True",
		Chance = 0,
		Multiplier = 1.5,
		Color = Color3.fromRGB(255, 236, 140),
	},
	Toxic = {
		DisplayName = "Toxic",
		Chance = 0.035,
		Multiplier = 3.5,
		Visual = "Particles",
		VfxName = "Toxic",
		Material = Enum.Material.Neon,
		Color = Color3.fromRGB(120, 230, 60),
		IconId = 111705649547353,
	},
	Gigantic = {
		DisplayName = "Gigantic",
		Chance = 0.026,
		Multiplier = 6,
		ScalesWithLuck = true,
		-- Взаимоисключающа с Tiny. Множитель 1.6 подобран так, чтобы руда
		-- заметно выделялась в тележке, но не вылезала из слота: у руды и
		-- так уже есть разброс размеров +-8% (см. PlaceholderFactory.Crystal)
		-- и рост Size по тирам, слоты к этому привычны.
		Visual = "Scale",
		ScaleFactor = 1.6,
		Color = Color3.fromRGB(255, 200, 120),
		IconId = 92382951194763,
	},
	Electric = {
		DisplayName = "Electric",
		Chance = 0.021,
		Multiplier = 5,
		ScalesWithLuck = true,
		Visual = "Particles",
		VfxName = "Electric",
		Material = Enum.Material.Neon,
		Color = Color3.fromRGB(120, 200, 255),
		IconId = 118410111514487,
	},
	Golden = {
		DisplayName = "Golden",
		Chance = 0.012,
		Multiplier = 8,
		ScalesWithLuck = true,
		-- Foil + высокий Reflectance вместо света: в тележке T10 помещается
		-- 225 кристаллов, и по источнику света на каждый золотой — это
		-- прямая потеря кадров. Отражение бесплатно.
		Visual = "MaterialSwap",
		Material = Enum.Material.Foil,
		Reflectance = 0.6,
		Color = Color3.fromRGB(255, 205, 70),
		IconId = 126506048942736,
	},
	Glitched = {
		DisplayName = "Glitched",
		Chance = 0.006,
		Multiplier = 12,
		ScalesWithLuck = true,
		-- Скриптовое подрагивание прозрачности и цвета, останавливается само
		-- при уничтожении руды (см. MutationVisuals, ветка Flicker).
		Visual = "Flicker",
		Material = Enum.Material.Neon,
		Color = Color3.fromRGB(255, 90, 200),
		FlickerInterval = 0.09,
		IconId = 120414234334179,
	},
	Prismatic = {
		DisplayName = "Prismatic",
		Chance = 0.0035,
		Multiplier = 18,
		ScalesWithLuck = true,
		-- Радуга бежит по САМОЙ руде, а не по оболочке поверх неё — этим и
		-- отличается от Radiant, у которого RainbowShell.
		Visual = "RainbowSwap",
		Material = Enum.Material.Neon,
		Color = Color3.fromRGB(255, 255, 255),
		IconId = 138217680097811,
	},
	Eclipsed = {
		DisplayName = "Eclipsed",
		Chance = 0.001,
		Multiplier = 25,
		ScalesWithLuck = true,
		-- Самая редкая мутация в игре: почти чёрная руда с тёмным ореолом
		-- частиц вокруг.
		Visual = "Particles",
		VfxName = "Eclipsed",
		Material = Enum.Material.Neon,
		Color = Color3.fromRGB(18, 10, 28),
		IconId = 119367714761462,
	},
}

--------------------------------------------------------------------------------
-- ПОГОДНЫЕ ИВЕНТЫ — по прямому запросу. Раз в RollIntervalSeconds сервер
-- перебрасывает кубик и выбирает, что будет твориться на карте следующие
-- RollIntervalSeconds (тот же интервал — ивент длится РОВНО до следующего
-- броска, отдельного поля Duration нет специально, чтобы не расходилось).
-- См. WeatherService.lua — там сам бросок, смена освещения, синхронизация
-- с клиентами и применение бустов к мутациям (через MutationRoll —
-- CrystalService/RockService передают туда BoostedMutations текущего
-- ивента при каждом броске мутации на новую руду).
--
-- Chance — АБСОЛЮТНАЯ вероятность именно этого ивента при каждом броске
-- (не "из оставшихся", а от общего пула) — сумма всех Chance ниже меньше 1,
-- остаток — это "Clear" (обычная погода, без ивента, не описан отдельной
-- записью — WeatherService просто ничего не применяет, если ни один Chance
-- не выпал). Порядок — от частого к редкому, как и Config.Mutations.Order.
--------------------------------------------------------------------------------
Config.WeatherEvents = {
	Enabled = true,
	RollIntervalSeconds = 300, -- 5 минут

	-- v20.26: ЯСНАЯ ПОГОДА (между ивентами) — тот же формат, что Look/Effects
	-- у ивентов ниже. Небо — градиент Atmosphere, без картинок-скайбоксов.
	ClearLook = {
		Atmosphere = { Density = 0.28, Offset = 0.22, Color = Color3.fromRGB(192, 222, 255), Decay = Color3.fromRGB(118, 160, 224), Glare = 0.3, Haze = 1.2 },
		ColorCorrection = { TintColor = Color3.fromRGB(255, 255, 255), Saturation = 0.1, Contrast = 0.05, Brightness = 0 },
		Bloom = { Intensity = 0.3, Size = 24, Threshold = 2 },
		Sky = { StarCount = 3000, SunAngularSize = 21, MoonAngularSize = 11, CelestialBodiesShown = true },
	},
	ClearEffects = {}, -- например { "Pollen" } — лёгкая пыльца в солнечную погоду
	LookTweenSeconds = 6,
	-- Картинки-скайбоксы ("<Id>Sky", "DaySky", "NightSky" в Assets) больше не
	-- нужны. true — если такие Sky лежат в Assets, они всё ещё ставятся.
	UseSkyboxAssets = false,

	-- v20.26: ЭФФЕКТЫ ПО ВСЕЙ КАРТЕ (client/WeatherFX). Карта делится на
	-- клетки CellSize×CellSize; в каждой клетке рядом с камерой (Radius)
	-- работают эмиттеры эффекта — частицы живут в МИРЕ, а не едут за
	-- камерой: отошёл — дождь остался идти там же, поднялся повыше — видно,
	-- что он идёт по всей карте. Ближе FullRateRadius — полная плотность,
	-- к краю Radius — FarRate от неё. Rate эмиттера = частиц в секунду
	-- на ОДНУ клетку.
	Fx = {
		CellSize = 64,
		Radius = 260,
		FullRateRadius = 100,
		FarRate = 0.3,
		FadeSeconds = 2.5,      -- плавное появление/затухание при смене погоды
		MapBounds = nil,        -- { Min = Vector2.new(x, z), Max = Vector2.new(x, z) }; nil — по размеру карты
		MaxMapSize = 3000,      -- автоматический размер карты не больше этого (стадов)
		RainTexture = "",       -- своя текстура капли-штриха (rbxassetid://…); пусто — встроенная
	},

	-- v20.26: МОЛНИИ в грозу (Events[].Lightning = true).
	Lightning = {
		IntervalMin = 4, IntervalMax = 11,   -- сек между ударами
		FarDistance = { 90, 260 },           -- обычный удар — вдали, на земле
		NearChance = 0.22,                   -- шанс удара РЯДОМ с игроком
		NearDistance = { 14, 26 },
		GrassBlocks = { 12, 18 },            -- сколько «блоков травы» разлетается
		GrassColors = { Color3.fromRGB(90, 170, 70), Color3.fromRGB(70, 145, 55), Color3.fromRGB(120, 190, 80), Color3.fromRGB(105, 80, 55) },
		ShakeNear = 0.35,                    -- тряска камеры при ударе рядом (стадов)
		ShakeFar = 0.06,
		ThunderSoundIds = {},                -- { "rbxassetid://…", … } — гром (задержка по расстоянию)
		ThunderVolume = 0.8,
	},

	Events = {
		{
			Id = "Night",
			DisplayName = "Nightfall",
			Chance = 0.135, -- по прямому запросу — все 5 ивентов вместе теперь дают 40%, чистое небо 60%
			-- IsDark — для скайбокса (см. WeatherService:_applySky ниже):
			-- если у конкретного ивента своего скайбокса нет, тёмные
			-- (IsDark=true) откатываются на общий "NightSky", светлые — на
			-- общий "DaySky".
			IsDark = true,
			-- Небо/звёзды — тематически ближе всего к ночи из уже готовых
			-- мутаций: Celestial ("небесный", голубое сияние) и Void
			-- (тёмный, почти чёрный) — усиливаем СРАЗУ ДВЕ, как и просили
			-- ("либо сразу на два типа мутаций").
			-- Void теперь ОСНОВНАЯ мутация ночи — по прямому запросу
			-- "специфичная руда должна выпадать даже чаще обычной". Базовый
			-- шанс 0.021 × 26 ≈ 55% при luck=0 — чаще, чем "обычная" руда
			-- без мутации, и растёт ещё выше с прокачанным luck (Void
			-- ScalesWithLuck=true). Celestial остаётся редким бонусом
			-- поверх (тот же множитель, что и был) — "остальные мутации
			-- реже, чем эта".
			BoostedMutations = { Celestial = 6, Void = 26 },
			-- Яркость поднята по прямому запросу ("не такой тёмной, но
			-- чтобы было понятно что всё ещё ночь") — Brightness почти
			-- вдвое выше, Ambient/OutdoorAmbient светлее, но оттенок
			-- остался тем же холодным сине-фиолетовым, ClockTime всё ещё
			-- полночь — ночь читается сразу, просто не кромешная тьма.
			-- Яркость теперь СЧИТАЕТСЯ ОТНОСИТЕЛЬНО реального дня (см.
			-- WeatherService:_applyDarknessRatio), а не зашита абсолютным
			-- числом — по прямому запросу "примерно на 20% темнее чем
			-- днём, чтобы фонари не понадобились". Хардкод (2.2 и т.п.)
			-- работал бы только если день на карте ровно такой яркости,
			-- какую я себе представлял — с DarknessRatio это верно всегда,
			-- на любой карте. 0.8 = 80% от дневной яркости (то есть на 20%
			-- темнее).
			-- Затемнение снижено ещё сильнее по повторному запросу — свои
			-- скайбоксы теперь несут атмосферу ночи сами, Lighting не
			-- обязан затемнять так сильно. 0.95 = 95% от дневной яркости.
			-- FogColor/FogEnd ниже DarknessRatio не трогает вообще (только
			-- Brightness/Ambient/OutdoorAmbient) — атмосфера/туман остаются
			-- как заданы, не "осветляются" вместе с этим.
			DarknessRatio = 0.95,
			Lighting = {
				ClockTime = 0, -- полночь
				Brightness = 2.2, -- запасное значение, если DarknessRatio почему-то не применится
				Ambient = Color3.fromRGB(55, 55, 85),
				OutdoorAmbient = Color3.fromRGB(50, 50, 80),
				FogColor = Color3.fromRGB(30, 30, 50),
				FogEnd = 900,
			},
			-- v20.26: НЕБО-ГРАДИЕНТ И СВЕТ (WeatherService, плавный переход).
			-- Atmosphere даёт градиент «горизонт → зенит» (Color — дымка у
			-- горизонта, Decay — цвет выше, Density/Offset/Haze/Glare — сила).
			-- ColorCorrection/Bloom — свои объекты WeatherColorCorrection /
			-- WeatherBloom в Lighting. Sky — только звёзды/луна/солнце у
			-- текущего Sky. Clouds — если задать (Cover/Density/Color).
			-- Свой вид из Studio: Assets/Weather/<Id>/Look (см. WeatherService).
			Look = {
				Atmosphere = { Density = 0.32, Offset = 0.12, Color = Color3.fromRGB(78, 88, 160), Decay = Color3.fromRGB(34, 28, 86), Glare = 0, Haze = 1.4 },
				ColorCorrection = { TintColor = Color3.fromRGB(214, 222, 255), Saturation = -0.05, Contrast = 0.08, Brightness = 0 },
				Bloom = { Intensity = 0.35, Size = 28, Threshold = 1.6 },
				Sky = { StarCount = 5000, MoonAngularSize = 14, CelestialBodiesShown = true },
			},
			-- v20.26: ЭФФЕКТЫ ПО ВСЕЙ КАРТЕ — имена из библиотеки
			-- Assets/WeatherFX/<Имя> (или встроенные плейсхолдеры, см. WeatherFX).
			Effects = { "Fireflies", "StarDust" },
			VfxKind = "Night", -- см. WeatherFX.client.lua — какие частицы/цвет использовать
			AnnounceText = "🌙 NIGHTFALL - Celestial and Void ore are far more common while it lasts!",
		},
		{
			Id = "Rain",
			DisplayName = "Rainstorm",
			Chance = 0.162, -- по прямому запросу — все 5 ивентов вместе теперь дают 40%, чистое небо 60%
			IsDark = false,
			-- По прямому запросу — затемнение на 13% относительно реального
			-- дня (см. WeatherService:resolveLightingTarget), то есть
			-- DarknessRatio = 0.87.
			DarknessRatio = 0.645, -- было 0.7 — ещё на 5.5% темнее, по прямому запросу
			-- Базовый шанс 0.045 × 13 ≈ 60% при luck=0 — чаще, чем обычная
			-- руда без мутации, по прямому запросу.
			BoostedMutations = { Soaked = 13 },
			Lighting = {
				Brightness = 1.4, -- запасное значение, если DarknessRatio почему-то не применится
				Ambient = Color3.fromRGB(60, 65, 75),
				OutdoorAmbient = Color3.fromRGB(70, 75, 85),
				FogColor = Color3.fromRGB(120, 130, 140),
				FogEnd = 550,
			},
			Look = {
				Atmosphere = { Density = 0.42, Offset = 0.05, Color = Color3.fromRGB(172, 182, 198), Decay = Color3.fromRGB(108, 120, 140), Glare = 0, Haze = 2.2 },
				ColorCorrection = { TintColor = Color3.fromRGB(226, 234, 246), Saturation = -0.2, Contrast = 0.03, Brightness = -0.02 },
				Bloom = { Intensity = 0.2, Size = 24, Threshold = 2 },
				Sky = { StarCount = 0, CelestialBodiesShown = false },
			},
			Effects = { "RainDrops", "RainSplashes", "Mist" },
			VfxKind = "Rain",
			AnnounceText = "🌧️ RAINSTORM - Soaked ore is much more common while it lasts!",
		},
		{
			Id = "Thunderstorm",
			DisplayName = "Thunderstorm",
			Chance = 0.068, -- по прямому запросу — все 5 ивентов вместе теперь дают 40%, чистое небо 60%
			IsDark = false,
			DarknessRatio = 0.595, -- было 0.65 — ещё на 5.5% темнее, по прямому запросу
			-- Electric — прямое попадание (молния = электричество). Glitched
			-- добавлен вторым — визуально его "подрагивание" читается как
			-- нервная реакция на грозу, тот же принцип "два типа сразу".
			-- Electric теперь ОСНОВНАЯ мутация грозы — 0.021 × 26 ≈ 55% при
			-- luck=0, чаще обычной руды. Glitched остаётся второстепенным
			-- бонусом с прежним множителем — "остальные мутации реже, чем
			-- эта".
			BoostedMutations = { Electric = 26, Glitched = 5 },
			Lighting = {
				Brightness = 1.0, -- запасное значение
				Ambient = Color3.fromRGB(40, 40, 55),
				OutdoorAmbient = Color3.fromRGB(35, 35, 50),
				FogColor = Color3.fromRGB(30, 30, 45),
				FogEnd = 450,
			},
			Look = {
				Atmosphere = { Density = 0.5, Offset = 0, Color = Color3.fromRGB(96, 106, 122), Decay = Color3.fromRGB(52, 58, 80), Glare = 0, Haze = 2.6 },
				ColorCorrection = { TintColor = Color3.fromRGB(206, 222, 216), Saturation = -0.3, Contrast = 0.12, Brightness = -0.03 },
				Bloom = { Intensity = 0.25, Size = 24, Threshold = 1.8 },
				Sky = { StarCount = 0, CelestialBodiesShown = false },
			},
			Effects = { "StormRain", "RainSplashes", "Mist" },
			Lightning = true, -- молнии (Config.WeatherEvents.Lightning)
			VfxKind = "Thunderstorm",
			AnnounceText = "⛈️ THUNDERSTORM - Electric and Glitched ore are surging!",
		},
		{
			Id = "BloodMoon",
			DisplayName = "Blood Moon",
			Chance = 0.027, -- по прямому запросу — все 5 ивентов вместе теперь дают 40%, чистое небо 60%
			IsDark = true,
			-- Sanguine — новая мутация, см. Config.Mutations (подходящей
			-- кроваво-красной не было, завели специально под этот ивент).
			-- Базовый шанс 0.015 × 40 ≈ 60% при luck=0 — чаще обычной руды,
			-- по прямому запросу.
			BoostedMutations = { Sanguine = 40 },
			-- Тоже посветлело по тому же запросу — красный оттенок остаётся
			-- ведущим (это и есть "кровавая луна"), но не тонет в почти
			-- полной черноте, как раньше.
			-- Та же логика DarknessRatio, что и у Night выше — 20% темнее
			-- реального дня на этой карте, а не абсолютное число.
			DarknessRatio = 0.95, -- было 0.8 — по повторному запросу светлее, свой скайбокс несёт атмосферу сам
			-- Красность снижена на ~20% по прямому запросу — R-канал
			-- уменьшен, G/B оставлены как были, так яркость/темнота (через
			-- DarknessRatio) не меняется, меняется именно насыщенность
			-- красного.
			Lighting = {
				ClockTime = 0,
				Brightness = 1.8, -- запасное значение
				-- v20.105: красного заметно МЕНЬШЕ, больше обычного цвета
				-- (красный - акцент неба/тумана, а не заливка всего мира).
				Ambient = Color3.fromRGB(70, 56, 60),
				OutdoorAmbient = Color3.fromRGB(66, 52, 56),
				FogColor = Color3.fromRGB(46, 28, 32),
				FogEnd = 900,
			},
			Look = {
				Atmosphere = { Density = 0.3, Offset = 0.1, Color = Color3.fromRGB(150, 96, 104), Decay = Color3.fromRGB(80, 40, 52), Glare = 0.3, Haze = 1.4 },
				ColorCorrection = { TintColor = Color3.fromRGB(255, 240, 240), Saturation = 0.05, Contrast = 0.08, Brightness = 0 },
				Bloom = { Intensity = 0.5, Size = 30, Threshold = 1.4 },
				Sky = { StarCount = 1500, MoonAngularSize = 30, CelestialBodiesShown = true },
			},
			Effects = { "Embers", "BloodDrizzle" },
			VfxKind = "BloodMoon",
			AnnounceText = "🔴 BLOOD MOON RISES - Sanguine ore is everywhere tonight!",
		},
		{
			Id = "SolarEclipse",
			DisplayName = "Solar Eclipse",
			Chance = 0.008, -- по прямому запросу — все 5 ивентов вместе теперь дают 40%, чистое небо 60%, но всё ещё САМОЕ РЕДКОЕ
			IsDark = true,
			-- Базовый шанс всего 0.001 (самая редкая руда в игре) —
			-- множитель поднят до 550 (0.001×550 ≈ 55% при luck=0), чтобы
			-- во время самого редкого ивента она была основной рудой, а
			-- не редким исключением из редкого исключения. Плюс
			-- ForcedMutationChance ниже — часть руды получает Eclipsed
			-- напрямую, минуя этот бросок вообще.
			BoostedMutations = { Eclipsed = 550 },
			-- ТОЛЬКО у затмения: часть добытой руды получает Eclipsed
			-- НАПРЯМУЮ, минуя обычный бросок (см. MutationRoll.ForceInclude)
			-- — самый редкий ивент должен ощущаться качественно иначе, а не
			-- просто "шанс чуть выше".
			ForcedMutationChance = 0.12,
			-- Та же система DarknessRatio, что и у Night/BloodMoon/Rain/
			-- Thunderstorm (см. WeatherService:resolveLightingTarget) — по
			-- прямому запросу "всё должно быть оранжевое +- как в кровавую
			-- луну": оттенок теперь ГАРАНТИРОВАННО остаётся ведущим
			-- (масштабируется от реальной яркости дня, сохраняя цвет, а не
			-- фиксированным абсолютным числом, которое на ярком дне могло
			-- бы смотреться тускло/невыразительно). 0.35 — заметно темнее,
			-- чем у кровавой луны (0.8): самый редкий ивент должен
			-- ощущаться качественно мрачнее, не просто "оранжевый день".
			DarknessRatio = 0.6, -- было 0.35 — по повторному запросу светлее (свой скайбокс несёт атмосферу), но всё ещё заметно темнее остальных — самый редкий ивент должен ощущаться мрачнее
			Lighting = {
				ClockTime = 12,
				Brightness = 0.2, -- запасное значение, если DarknessRatio почему-то не применится
				-- Оттенок усилен по прямому запросу — БЕЗ полноэкранного
				-- оверлея (тот убрали по повторному запросу), весь эффект
				-- держится на самом Lighting: R поднят заметно выше, G/B
				-- заметно ниже, чем в первой версии — более насыщенный,
				-- "чистый" оранжевый, а не размытый бежево-коричневый.
				Ambient = Color3.fromRGB(115, 48, 8),
				OutdoorAmbient = Color3.fromRGB(100, 40, 6),
				FogColor = Color3.fromRGB(80, 32, 5),
				FogEnd = 300,
			},
			Look = {
				Atmosphere = { Density = 0.36, Offset = 0.35, Color = Color3.fromRGB(62, 52, 44), Decay = Color3.fromRGB(205, 140, 60), Glare = 2, Haze = 1.6 },
				ColorCorrection = { TintColor = Color3.fromRGB(255, 236, 206), Saturation = -0.15, Contrast = 0.15, Brightness = 0 },
				Bloom = { Intensity = 0.6, Size = 32, Threshold = 1.3 },
				Sky = { StarCount = 2500, SunAngularSize = 30, CelestialBodiesShown = true },
			},
			Effects = { "Ash" },
			VfxKind = "SolarEclipse",
			AnnounceText = "🌑 SOLAR ECLIPSE - Eclipsed ore chance is off the charts, and some ore turns Eclipsed instantly!",
		},
	},
}

-- НА КАКОМ РАССТОЯНИИ ВИДНО ПОЛОСКИ ЗДОРОВЬЯ. BillboardGui.MaxDistance
-- скрывает подпись дальше указанного расстояния сам, на стороне каждого
-- клиента — скрипт для этого не нужен.
--
-- У валуна раньше ограничения не было вовсе: "BOULDER LV. 5  340/900" читался
-- через всю карту, и в поле зрения одновременно висело до шестнадцати таких
-- подписей. У гоблина стояло 70 — тоже далеко, полоска появлялась задолго до
-- того, как игрок вообще собирался драться.
Config.HealthDisplay = {
	BoulderMaxDistance = 55,
	GoblinMaxDistance = 55,
}

-- РАЗГОН ПРИ ДОЛГОЙ ХОДЬБЕ ("бег"). Игрок, который двигается без остановки
-- дольше BuildUpSeconds, плавно ускоряется на SpeedBonus. Стоит остановиться —
-- разгон так же плавно спадает.
--
-- Множитель применяется в CartService:recomputeWalkSpeed — это единственное
-- место в проекте, где выставляется WalkSpeed игрока, поэтому бег
-- автоматически совмещается со всем остальным: бонусом за ребёрты,
-- геймпассом Speed Boost, замедлением от руды в руках и оглушением.
Config.Sprint = {
	Enabled = true,
	BuildUpSeconds = 3,    -- сколько нужно двигаться без остановки, чтобы начать разгоняться
	SpeedBonus = 0.40,     -- +40% к итоговой скорости на полном разгоне
	RampSeconds = 0.8,     -- за сколько бонус набирается полностью (и спадает)
	-- Короткая остановка не сбрасывает разгон: иначе бег обрывался бы от
	-- любого шага назад, прыжка или упора в угол.
	StopGraceSeconds = 0.3,
	-- С тележкой разгон НЕ работает. Скорость толкания намеренно
	-- фиксированная (Config.Cart.FixedCartSpeed), чтобы доставка не зависела
	-- от прокачки и все игроки везли груз одинаково — бег бы это сломал.
	ApplyWhileHoldingCart = false,
}

-- v20.110: КОМПАС - кнопка слева под MENU. Открывает мини-карту (вид
-- сверху) и телепортирует в центр (торговцы), на свой плот или на свои
-- острова. Карта: MapImageId - твоя картинка вида сверху; чтобы метки
-- совпали с картинкой, поставь в workspace две невидимые детали
-- CompassMapMin (левый верхний угол картинки = минимальные X/Z) и
-- CompassMapMax (правый нижний = максимальные X/Z). Нет их - границы
-- считаются по плотам и центру.
Config.Compass = {
	Enabled = true,
	Cooldown = 5,            -- сек между телепортами
	MapImageId = 0,          -- картинка карты (вид сверху); 0 - схема
	ButtonImageId = 0,       -- иконка кнопки; 0 - 🧭
	CenterMarkerName = "CompassCenterMarker", -- куда телепорт «в центр» (иначе у зоны продажи)
	CenterOffset = Vector3.new(0, 0, 18),
	TowardBaseStuds = 22,    -- v20.121: телепорт «в центр» смещён на столько стадов в сторону своей базы
	MapSizePC = 440,
	MapSizePhone = 290,
	-- v20.121: карта = настоящий вид сверху (ViewportFrame с копией мира),
	-- пока MapImageId = 0. Метки - точки с маленькой подписью сверху.
	ViewportMap = true,
	ViewportMaxParts = 2500,      -- сколько деталей мира копировать (телефоны!)
	ViewportMinPartSize = 3,      -- мельче (по X/Z) - не копируется
	ViewportRefreshSeconds = 120, -- пересобирать вид не чаще
	-- Авто-метки: объект Workspace по имени → точка с подписью. Свои метки
	-- без кода: поставь любому объекту атрибут MapLabel = "ПОДПИСЬ".
	AutoMarkers = {
		{ Find = "BankMerchant", Label = "ORE SHOP", Color = Color3.fromRGB(255, 200, 60) },
		{ Find = "IslandKeeper", Label = "ISLANDS", Color = Color3.fromRGB(120, 220, 255) },
		{ Find = "SellZone", Label = "SELL", Color = Color3.fromRGB(90, 230, 120) },
		{ Find = "GoblinCamp", Label = "GOBLINS", Color = Color3.fromRGB(255, 90, 80) },
	},
}

-- v20.108: КРОТ-СКУПЩИК на зоне продажи. Зашёл в зону с рудой - перед
-- тобой из земли (в пределах зоны) вылезает крот и спрашивает:
-- SELL ALL (весь рюкзак, комбо за заполнение до x3) / SELL HAND (стопка в
-- руке) / NOT NOW. После ответа он зарывается обратно - комья земли
-- разлетаются и залетают в ямку. Модель: ReplicatedStorage/Assets/SellMole
-- (у неё должна быть деталь "Head" - над ней висит меню); нет - заглушка.
Config.SellMole = {
	Enabled = true,
	ModelName = "SellMole",
	Distance = 10.5,     -- насколько перед игроком вылезает (v20.121: +3.5 стада)
	EdgeMargin = 3,      -- отступ от края зоны
	Scale = 1,           -- масштаб модели
	RiseSeconds = 0.8,   -- v20.118: из-под земли глубже - вылезает чуть дольше
	BurrowSeconds = 0.6,
	VisibleHeight = 3.5, -- v20.119: сколько стадов верха модели торчит из земли (голова и плечи); остальное всегда под землёй
	BobAmount = 0.07,    -- v20.118: «дыхание» - растягивание ВВЕРХ-ВНИЗ (доля), ширина обратно
	BobSpeed = 1,
	SellDelay = 0.06,    -- сек между кусками при продаже
	SellSeconds = 2.5,   -- вся продажа не дольше этого
	DirtColor = Color3.fromRGB(110, 72, 40),
	DirtCount = 10,
	CrystalDeposit = true, -- v20.121: кристалл в руках сдаётся кроту кнопкой (а не пропадает сам на входе в зону)
	CrystalLine = "Ooh, a crystal! I'll keep it safe in the bank.",
	Lines = {
		"Psst! Got ore? I'll buy it all!",
		"Shiny rocks! I pay good coin!",
		"Selling today, friend?",
	},
}

Config.Bank = {
	-- v17: при сдаче руды торговцу (банку) крупное «+$…» пиксельным шрифтом
	-- на ЭКРАНЕ больше не показывается — доход и так считает счётчик над
	-- торговцем (client/SellFx). true — вернуть экранную надпись.
	ScreenMoneyPopupOnSell = false,
	-- Руда продаётся ТОЛЬКО тележкой (по прямому запросу). true вернёт
	-- старую продажу руды из рук (HandCarry) прямо в зоне банка.
	HandSellEnabled = false,

	--------------------------------------------------------------------------
	-- ПРОДАЖА РУДЫ ИЗ РЮКЗАКА (см. BankService:_sellBackpack).
	--
	-- ЗАЧЕМ. До первой тележки у игрока нет вообще никакого способа
	-- превратить руду в деньги — а тележку он получает только на шестом
	-- шаге обучения. Без этой продажи первые два шага (сломать валуны,
	-- отнести руду в центр) упирались бы в стену.
	--
	-- ПОЧЕМУ ЭТО НЕ ЛОМАЕТ ЭКОНОМИКУ. Рюкзак сознательно хуже тележки по
	-- двум осям сразу: комбо-множитель рейса (до x120, см.
	-- Config.Cart.ComboThresholds) на такую продажу НЕ начисляется вообще,
	-- а до покупки тележки рюкзак ужат до StarterSlots ячеек (см.
	-- Config.Inventory). Возить руду руками остаётся аварийным вариантом,
	-- а не заменой рейсу.
	InventorySellEnabled = true,
	InventorySellDelay = 0.12, -- пауза между кусками, чтобы продажа читалась как процесс
	SellDelayPerCrystal = 0.16,
	SellAcceleration = 0.82,
	SellMinimumDelay = 0.035,
}

--------------------------------------------------------------------------------
-- ТОРГОВЕЦ И БИРЖА РУДЫ (заменили слайма банка).
--
-- Торговец стоит в зоне банка ПОСТОЯННО (MerchantService). Раз в
-- CycleSeconds ОДНОВРЕМЕННО, для всего сервера:
--   • меняется КУРС — общий множитель цены продажи ВСЕЙ руды (Market);
--   • обновляется СТОК лавки — что и сколько продаётся (Items).
-- Таймер один на весь сервер: все видят одно и то же "New stock in 3m 17s"
-- и одинаковый курс, поэтому "x2.4 ПРЯМО СЕЙЧАС" — общее событие, ради
-- которого стоит доехать до банка или придержать тележку.
--
-- ЗАЧЕМ ИМЕННО ТАК (удержание онлайна):
--   • решение "продать сейчас или переждать обвал" — с риском, что
--     тележку по дороге угонят;
--   • редкий товар в стоке появляется не каждый цикл, а цикл короткий —
--     повод заглянуть через 5 минут;
--   • личный RESTOCK за Robux перебрасывает сток только себе.
--------------------------------------------------------------------------------
Config.Merchant = {
	Enabled = true,
	CycleSeconds = 5 * 60,

	-- Имя модели в ReplicatedStorage.Assets — своя модель торговца
	-- подставляется без правок кода (PlaceholderFactory.BankMerchant).
	AssetName = "BankMerchant",
	DisplayName = "Ore Merchant",
	PromptDistance = 12,

	--------------------------------------------------------------------------
	-- БИРЖА. Курс выбирается корзиной (по весу), внутри корзины —
	-- равномерно, с округлением до Step. Средний курс при случайной продаже
	-- ≈ x1.06 — экономика почти не разгоняется, а выигрыш даёт именно
	-- умение поймать хороший цикл. Корзины с Announce объявляются в чат.
	--------------------------------------------------------------------------
	Market = {
		Step = 0.05,
		-- Два обвала подряд — уже не игра, а наказание:
		-- после Crash следующий цикл не может снова быть Crash.
		NoRepeat = { Crash = true, Jackpot = true },
		-- v4: курс сужен до x0.7 … x1.8 (было x0.4 … x3). Средний ≈ x1.03.
		Buckets = {
			{ Id = "Crash",   Weight = 10, Min = 0.70, Max = 0.75, Label = "CRASH",   Color = Color3.fromRGB(255, 80, 80),  Announce = true },
			{ Id = "Low",     Weight = 28, Min = 0.75, Max = 0.95, Label = "LOW",     Color = Color3.fromRGB(255, 160, 90) },
			{ Id = "Normal",  Weight = 34, Min = 0.95, Max = 1.10, Label = "NORMAL",  Color = Color3.fromRGB(235, 235, 235) },
			{ Id = "High",    Weight = 18, Min = 1.10, Max = 1.35, Label = "HIGH",    Color = Color3.fromRGB(120, 255, 120) },
			{ Id = "Boom",    Weight = 8,  Min = 1.35, Max = 1.60, Label = "BOOM",    Color = Color3.fromRGB(70, 255, 170), Announce = true },
			{ Id = "Jackpot", Weight = 2,  Min = 1.70, Max = 1.80, Label = "JACKPOT", Color = Color3.fromRGB(255, 215, 60), Announce = true },
		},
	},

	--------------------------------------------------------------------------
	-- ЛАВКА. Показываются ВСЕ товары всегда (как в Grow a Garden): каждый
	-- цикл товар с шансом Chance получает сток в диапазоне Stock, иначе —
	-- "NO STOCK". Сток личный: у каждого игрока свои X шт. на цикл.
	--
	-- v4: цены ФИКСИРОВАННЫЕ (Price, в $) — не зависят от пещеры и тележки
	-- игрока. Прокачался — старые товары стали дешевле, пассы x2..x5
	-- реально ускоряют. Ориентир: зелье x2 Money ≈ 6K — дорого на пещере 5,
	-- копейки на пещере 12; скины — долгосрочные цели.
	--
	-- Kind:
	--   Potion  — кладётся в data.Potions, активируется тапом в панели
	--             зелий (баф из Config.Buffs[Buff] на Seconds секунд);
	--   Gear    — снаряжение (GearService:AddGear), Key = ключ Config.Dynamite.Types;
	--   Skin    — скин кирки (SkinService:GrantSkin), разовый.
	--------------------------------------------------------------------------
	Items = {
		-- В лавке ТОЛЬКО то, чего нигде больше не купить: бафы ×2 и скины
		-- кирок. Обычный динамит продаётся у торговца улучшениями всегда —
		-- здесь он не появляется, чтобы не занимать место в стоке.
		{ Id = "Potion_Speed",    Kind = "Potion", Potion = "Potion_Speed",    Rarity = "Common",    Chance = 1.00, Stock = { 2, 4 }, Price = 500 },
		{ Id = "Potion_Damage",   Kind = "Potion", Potion = "Potion_Damage",   Rarity = "Uncommon",  Chance = 0.80, Stock = { 1, 3 }, Price = 1500 },
		{ Id = "Skin_Radioactive",Kind = "Skin",   SkinId = "RadioactivePickaxe", DisplayName = "Radioactive Pickaxe", Icon = "⛏", Rarity = "Uncommon", Chance = 0.50, Stock = { 1, 1 }, Price = 20000 },
		{ Id = "Potion_Money",    Kind = "Potion", Potion = "Potion_Money",    Rarity = "Rare",      Chance = 0.60, Stock = { 1, 2 }, Price = 6000 },
		{ Id = "Potion_Luck",     Kind = "Potion", Potion = "Potion_Luck",     Rarity = "Rare",      Chance = 0.45, Stock = { 1, 2 }, Price = 9000 },
		{ Id = "Skin_Love",       Kind = "Skin",   SkinId = "LovePickaxe",        DisplayName = "Love Pickaxe",        Icon = "⛏", Rarity = "Rare",     Chance = 0.28, Stock = { 1, 1 }, Price = 120000 },
		{ Id = "Skin_BigWooden",  Kind = "Skin",   SkinId = "BigWoodenPickaxe",   DisplayName = "Big Wooden Pickaxe",  Icon = "⛏", Rarity = "Rare",     Chance = 0.28, Stock = { 1, 1 }, Price = 120000 },
		{ Id = "Potion_Mutation", Kind = "Potion", Potion = "Potion_Mutation", Rarity = "Epic",      Chance = 0.20, Stock = { 1, 1 }, Price = 30000 },
		{ Id = "Skin_Crystal",    Kind = "Skin",   SkinId = "CrystalPickaxe",     DisplayName = "Crystal Pickaxe",     Icon = "⛏", Rarity = "Epic",     Chance = 0.13, Stock = { 1, 1 }, Price = 450000 },
		{ Id = "Potion_MoneyX3",  Kind = "Potion", Potion = "Potion_MoneyX3",  Rarity = "Legendary", Chance = 0.07, Stock = { 1, 1 }, Price = 75000 },
		{ Id = "Skin_Void",       Kind = "Skin",   SkinId = "VoidPickaxe",        DisplayName = "Void Pickaxe",        Icon = "⛏", Rarity = "Legendary", Chance = 0.05, Stock = { 1, 1 }, Price = 1500000 },
		-- v20.28: ЖЕОДЫ. Тип — от пещеры игрока: GeodeOffset 0 = жеода своей
		-- пещеры, +1 = следующей, +3 = на три выше (не выше последней).
		-- Цена — PriceMinutes минут дохода игрока (Config.IncomePerMinute).
		-- Купленная жеода сразу в хранилище жеод (как из тележки).
		{ Id = "Geode_Own",     Kind = "Geode", GeodeOffset = 0, Icon = "🪨", Chance = 0.90, Stock = { 1, 3 }, PriceMinutes = 3 },
		{ Id = "Geode_Next",    Kind = "Geode", GeodeOffset = 1, Icon = "🪨", Chance = 0.45, Stock = { 1, 2 }, PriceMinutes = 8 },
		{ Id = "Geode_Jackpot", Kind = "Geode", GeodeOffset = 3, Icon = "💎", Chance = 0.08, Stock = { 1, 1 }, PriceMinutes = 25 },
		-- v20.28: ТОВАР «???» — случайная награда из Config.Merchant.Mystery.Pool.
		{ Id = "Mystery", Kind = "Mystery", DisplayName = "???", Icon = "❓", Rarity = "Mystery", Chance = 0.85, Stock = { 1, 2 }, PriceMinutes = 6 },
	},

	-- v20.28: ТОВАР «???». Что внутри — по весам Weight. Money — Minutes минут
	-- дохода игрока. Skin — случайная ещё не открытая кирка из Skins (только
	-- с ассетом); если все открыты — выпадает Fallback. Показывается
	-- карточкой открытия (RevealCards), как награда из сундука.
	Mystery = {
		Pool = {
			{ Kind = "Potion", Weight = 38 },                 -- любое зелье из Config.Potions
			{ Kind = "Geode", GeodeOffset = 0, Weight = 22 },
			{ Kind = "Geode", GeodeOffset = 1, Weight = 9 },
			{ Kind = "Decor", Weight = 16 },                  -- случайная мебель (по DecorWeights)
			{ Kind = "Money", Minutes = 10, Weight = 12 },
			{ Kind = "Skin", Weight = 3, Skins = { "RadioactivePickaxe", "LovePickaxe", "BigWoodenPickaxe", "CrystalPickaxe", "VoidPickaxe" }, Fallback = { Kind = "Money", Minutes = 20 } },
		},
	},

	-- v20.29: СУНДУК ЦИКЛА — самая верхняя, выделенная карточка вкладки SHOP.
	-- Каждый цикл редкость сундука выпадает по Weights, цена — PriceMinutes
	-- минут дохода игрока для этой редкости. Покупка — сундук в инвентарь
	-- (ставится на базу, как выпавший с валуна).
	FeaturedChest = {
		Enabled = true,
		Weights = { Common = 45, Rare = 32, Epic = 17, Legendary = 6 },
		-- v20.64: сундуки дороже. Цена = минуты дохода игрока, но не
		-- меньше MinPrice (на ранних пещерах легендарный стоил ~30K).
		PriceMinutes = { Common = 6, Rare = 18, Epic = 50, Legendary = 150 },
		MinPrice = { Common = 800, Rare = 8000, Epic = 60000, Legendary = 400000 },
		Stock = { 1, 2 },
		AlwaysInStock = false, -- v20.37: после покупки уходит из стока (бесконечны только Storage Chest и Ore Jar)
	},

	-- v20.28: СКИДКА ДНЯ. Раз в сутки (UTC) выбирается один товар из вкладки
	-- SHOP (не лимитка, не «???»): он всегда в стоке (Stock на игрока в
	-- цикл) и дешевле на Discount. Строка с плашкой «DEAL −30%».
	DailyDeal = { Enabled = true, Discount = 0.30, Stock = 1, Kinds = { Potion = true, Skin = true, Geode = true } },

	-- v20.28: «НАПОМНИ МНЕ». Звёздочка на товаре; когда отмеченный товар
	-- в новом цикле есть в стоке — уведомление игроку и «!» над торговцем.
	-- До MaxWishes звёздочек.
	Wishlist = { Enabled = true, MaxWishes = 8 },

	-- Редкий товар в стоке объявляется всему серверу — повод доехать до
	-- банка, пока не разобрали (сток личный, но цикл общий).
	AnnounceRarities = { Epic = true, Legendary = true, Mythic = true },

	-- Табло над торговцем: курс руды «ORE x1.00» + таймер нового товара.
	-- v20.17: курс показывается ТОЛЬКО здесь (там, где сдаёшь руду);
	-- плашка сверху экрана выключена (ShowTicker = false).
	ShowBoard = true,
	ShowTicker = false,

	-- Цвета плашек редкости в окне лавки.
	RarityColors = {
		Mystery   = Color3.fromRGB(255, 120, 230),
		Common    = Color3.fromRGB(170, 170, 170),
		Uncommon  = Color3.fromRGB(90, 200, 90),
		Rare      = Color3.fromRGB(60, 140, 255),
		Epic      = Color3.fromRGB(170, 80, 255),
		Legendary = Color3.fromRGB(255, 185, 40),
		Mythic    = Color3.fromRGB(255, 70, 90),
	},

	-- НАСЛЕДИЕ СЛАЙМА. Уровень слайма давал +1% к продаже за уровень.
	-- Прогресс кормления (data.SlimeFedValue) не выбрасывается: игрок
	-- получает тот же бонус навсегда, замороженным (DataService:
	-- GetLegacySellBonus). Новые игроки его не копят.
	LegacySlime = {
		BonusPerLevel = 0.01,
		Thresholds = { 0, 2000, 10000, 40000, 150000, 600000, 2500000, 10000000, 40000000 },
	},
}

--------------------------------------------------------------------------------
-- ЗЕЛЬЯ — снаряжение (data.Gear[key]), как динамит и сундуки: лежат в
-- инвентаре, ячеек рюкзака не тратят, ставятся в хотбар. Взял в руку — над
-- головой колба-пузырёк (client/PotionBubble.client.lua, у всех игроков),
-- клик — выпить (GearService:_drinkPotion → BuffService).
--
-- Amount — бонус сверх 1.0 в терминах BuffService: Money/Speed/Damage
-- читаются как множитель 1+Amount (1.0 = ×2), Luck — прямая добавка к
-- удаче (0.15 = та же сила, что Robux-продукт "Luck x2"), MutationPotion —
-- множитель шанса мутаций как есть (2 = ×2).
-- Второе зелье того же вида ПРОДЛЕВАЕТ действие, а не сгорает.
--------------------------------------------------------------------------------
Config.Potions = {
	Order = { "Potion_MoneyX3", "Potion_Money", "Potion_Luck", "Potion_Mutation", "Potion_Damage", "Potion_Speed" },
	MaxStack = 99,
	Types = {
		Potion_Speed    = { Buff = "Speed",          Amount = 0.25, Seconds = 180, DisplayName = "Speed Potion",    Icon = "⚡", Color = Color3.fromRGB(90, 200, 255) },
		Potion_Damage   = { Buff = "Damage",         Amount = 1.0,  Seconds = 180, DisplayName = "x2 Damage Potion",   Icon = "💪", Color = Color3.fromRGB(255, 90, 70) },
		Potion_Money    = { Buff = "Money",          Amount = 1.0,  Seconds = 180, DisplayName = "x2 Money Potion",    Icon = "💰", Color = Color3.fromRGB(255, 215, 70) },
		Potion_Luck     = { Buff = "Luck",           Amount = 0.15, Seconds = 300, DisplayName = "x2 Luck Potion",     Icon = "🍀", Color = Color3.fromRGB(110, 235, 120) },
		Potion_Mutation = { Buff = "MutationPotion", Amount = 2.0,  Seconds = 180, DisplayName = "x2 Mutation Potion", Icon = "🧪", Color = Color3.fromRGB(200, 110, 255) },
		Potion_MoneyX3  = { Buff = "Money",          Amount = 2.0,  Seconds = 120, DisplayName = "x3 Money Potion",    Icon = "💎", Color = Color3.fromRGB(255, 170, 40) },
	},
}


--------------------------------------------------------------------------------
	-- ТОЧНЫЕ ШАНСЫ ПО КАЖДОМУ ИСХОДУ (для честного раскрытия дропа, Roblox
-- Random Item Generator policy). Это НЕ отдельная таблица данных — цифры
	-- ниже лишь ДОКУМЕНТИРУЮТ то, что реально считают Types[x].MoneyChance/
-- MoneyChance ниже + Config.Skins.DropChance, разложенные поровну между
-- позициями внутри каждой корзины (Ores — GeodeService:levelForCopies не
-- участвует, это распределение ПЕРВОГО дропа; money — фиксированный сплит
-- 70/25/5% между Money[1]/[2]/[3]; skin — поровну между Pickaxe-скинами
-- этого типа, Cart-скины сейчас НЕ в пуле, см. Config.Skins.Definitions).
	-- Dust отключён: его бывшая доля добавлена к руде. Если поменяешь
	-- MoneyChance/Money[]/DropChance/список Ores или
-- список скинов — актуализируй и эту табличку, иначе расхождение между
-- увиденным игроком текстом и кодом = нарушение политики.
--
	-- Все типы жеод используют одинаковые корзины: 55% деньги, 25% руда,
	-- 5% скин, 15% временный бафф (см. Config.Buffs ниже — по прямому
	-- запросу "внутри по сути бесполезные скины и деньги, предложи как
	-- переделать"). Три денежные награды делят 55% как 70/25/5, руды и
	-- баффы делятся поровну между вариантами каждой категории.
--
-- Каждая строка выше в сумме даёт ровно 100.00% (проверено). Совпадает 1:1
-- с тем, что реально показывает панель "i" в GeodeUI.client.lua (та же
-- формула деления поровну), и с тем, что реально считает GeodeService:OpenGeode.
--------------------------------------------------------------------------------
Config.Geodes = {
	MaxPerCart = 3,
	SafeCollectHoldDuration = 1.5,
	-- Кристалл на подиуме — левитирует над центром и крутится вокруг себя
	-- (см. PassiveIncomeService:UpdateDisplay), а не стоит неподвижно.
	OreLevitateHeight = 0.15, -- небольшой зазор над "родной" точкой посадки
	OreBobHeight = 0.35,      -- студ, амплитуда лёгкого покачивания вверх-вниз
	OreBobSpeed = 1.5,        -- рад/сек, скорость покачивания
	OreSpinSpeed = 1.0,       -- рад/сек, скорость вращения вокруг себя
	CrystalSwitchCooldown = 0.6,
	SpawnPity = 40,
	OpenPity = 8,
	OfflineCapSeconds = 8 * 60 * 60, -- v3: было 24ч; сейф и так ограничен SafeCapTargetHours

	--------------------------------------------------------------------------
	-- ПОТОЛОК БАЛАНСА СЕЙФА — ДОЛЯ ОТ ЦЕНЫ ТЕКУЩЕГО РЕБЁРТА.
	--
	-- ЗАЧЕМ. Доход руды растёт примерно ×10 за тир (см. Ores ниже:
	-- 2K → 30K → 180K → 1.5M → 12M → 120M → 1.2B → 12B → 24B → 42B в минуту),
	-- а цена ребёрта после того, как тир-кап упёрся в MaxTierCap, растёт
	-- всего ×1.30 за ребёрт (Config.Rebirth.LateCostGrowth). Кривые
	-- расходятся, и в лейте ОДНА суточная выплата сейфа перекрывала целый
	-- ребёрт. Считано на реальных числах:
	--   Eclipse   (lvl 10, мутация ×3) = 9.85e13 за 24 ч, ребёрт №6 = 8.07e13
	--   Infinitum (lvl 10, мутация ×3) = 3.45e14 за 24 ч, ребёрт №12 = 3.90e14
	-- То есть игрок жал ОДНУ кнопку раз в сутки и получал ребёрт, полностью
	-- минуя активную петлю (шахта → тележка → банк). Это обесценивало и
	-- прокачку, и PvP, и комбо-множитель разом.
	--
	-- КАК РАБОТАЕТ. Накопление в PassiveIncomeService:Accrue не уходит выше
	-- SafeCapPercentOfRebirth × (цена СЛЕДУЮЩЕГО ребёрта этого игрока).
	-- Потолок ПЕРСОНАЛЬНЫЙ и растёт вместе с игроком сам: цена ребёрта
	-- считается через DataService:GetRebirthCost, то есть уже включает и
	-- Config.Economy.ProgressionSlowdown, и денежные пассы игрока. Отдельно
	-- пересчитывать при каждом ребалансе ничего не нужно.
	--
	-- ПОЧЕМУ ИМЕННО ДОЛЯ, А НЕ ФИКСИРОВАННОЕ ЧИСЛО. Фиксированный потолок
	-- пришлось бы переписывать после каждой правки цен, и он всё равно
	-- ломался бы на разных стадиях игры: 10 млрд — это целое состояние на
	-- T5 и пыль на T10. Доля держит один и тот же СМЫСЛ на всей дистанции:
	-- «сейф — ощутимая помощь к ребёрту, но никогда не сам ребёрт».
	--
	-- 0.55 = сейф закрывает максимум 55% следующего ребёрта, остальные 45%
	-- игрок обязан отвезти тележкой. Ставь меньше, если сейф всё ещё
	-- ощущается сильнее активной игры; больше — если наоборот, возвраты
	-- перестали радовать. Значение 0 полностью выключает потолок (прежнее
	-- поведение), 1.0 = ровно один ребёрт за одну выплату.
	--
	-- ЧТО ЭТО ЗНАЧИТ НА ПРАКТИКЕ при 0.55: полностью заполненный сейф — это
	-- чуть больше половины ребёрта. То есть возврат после суток отсутствия
	-- ощущается как крупный подарок (половина цели закрыта одной кнопкой),
	-- но вторую половину всё равно приходится возить тележкой, и активная
	-- петля остаётся обязательной. Для сравнения: ДО потолка одна суточная
	-- выплата в лейте перекрывала ребёрт ЦЕЛИКОМ и с запасом.
	SafeCapPercentOfRebirth = 0, -- v3: выключено (ребёрт теперь дешёвый, потолок резал пассивку в ноль)

	--------------------------------------------------------------------------
	-- ЦЕЛЕВОЕ ВРЕМЯ ЗАПОЛНЕНИЯ СЕЙФА (гибридный потолок).
	--
	-- ПРОБЛЕМА С ЧИСТЫМ "% ОТ РЕБЁРТА": время заполнения плавает от игрока к
	-- игроку — у кого-то 40 минут, у кого-то сутки, — поэтому обещать в UI
	-- конкретное "через 5 часов" было нечестно.
	--
	-- РЕШЕНИЕ: потолок сейфа теперь МИНИМУМ из двух ограничений:
	--   1) доход_в_минуту × 60 × SafeCapTargetHours — держит одно и то же
	--      ОЩУЩЕНИЕ времени у всех игроков, на любом тире;
	--   2) SafeCapPercentOfRebirth × цена_ребёрта — старый защитный потолок,
	--      который не даёт лейту одной выплатой перекрывать целый ребёрт
	--      (см. развёрнутое обоснование выше).
	-- Берём МЕНЬШЕЕ: для большинства игроков сработает пункт 1 (честные
	-- 5 часов), а на позднем тире, где доход уже космический, сработает
	-- пункт 2 и утащит потолок ниже — экономика остаётся защищённой.
	SafeCapTargetHours = 3,

	--------------------------------------------------------------------------
	-- ТРЕТИЙ ОГРАНИЧИТЕЛЬ СЕЙФА: «сколько это рейсов».
	--
	-- ЗАЧЕМ ЕЩЁ ОДИН. Двух прежних не хватало на РАННЕЙ игре, и это видно
	-- только если посчитать. Рейс на тире 1 занимает ~50 секунд, а сейф
	-- копит 5 часов — то есть полный сейф новичка равен примерно 265
	-- полным рейсам. Ограничитель «% от ребёрта» там не срабатывает вообще
	-- (цена ребёрта на старте астрономическая по сравнению с его доходом),
	-- поэтому новичок, отошедший на вечер, возвращался к сумме, которая
	-- разом перепрыгивала ему несколько тиров шахты. На тире 9 та же
	-- механика даёт всего ~9 рейсов — то есть смысл сейфа был совершенно
	-- разным на разных стадиях игры.
	--
	-- Этот потолок выражен в ЕДИНИЦАХ САМОЙ ИГРЫ: «полный сейф ≈ N хороших
	-- рейсов», и потому означает одно и то же на любом тире. 25 подобрано
	-- так, чтобы на тирах 4+ он вообще не срабатывал (там и так выходит
	-- 9-28 рейсов) и подрезал только ранний перекос.
	--
	-- 0 или nil выключает этот ограничитель, оставляя два прежних.
	SafeCapTripEquivalent = 0, -- v4: выключено — потолок сейфа только по времени (SafeCapTargetHours)

	-- БОНУС ЗА ПОЛНЫЙ СЕЙФ. Раньше не было разницы между "забрал в
	-- процессе" и "дождался полного" — сумма всё равно упиралась в потолок.
	-- Теперь забор РОВНО когда сейф полон (не раньше) даёт +25% к сумме —
	-- это и есть обещанное "через 5 часов — много денег", а не просто
	-- урезанная капель. 0 или nil выключает бонус.
	SafeFullBonusMultiplier = 1.25,

	-- ГЛОБАЛЬНЫЙ МНОЖИТЕЛЬ ПАССИВНОГО ДОХОДА С РУДЫ (тик в минуту).
	-- Раньше цифра на табличке подиума росла заметным темпом каждую минуту —
	-- ощущалось как отдельный источник дохода наравне с активной шахтой.
	-- Урезано вдвое: капает медленнее и незаметнее, а весь смысл сейфа
	-- переносится на разовую крупную выплату раз в SafeCapTargetHours часов
	-- (см. выше), а не на ежеминутный тикер.
	-- Общий рубильник силы пассивного дохода. Раньше стоял 0.5, потому что
	-- сами числа IncomePerMinute были заведомо завышены и их резали здесь.
	-- Теперь доход считается по формуле, которая изначально откалибрована
	-- по реальному доходу рейса (см. src/shared/OreIncome.lua) — резать
	-- нечего, множитель нейтральный. Крути ЕГО, если после теста весь
	-- пассивный доход целиком кажется сильным или слабым: он трогает все
	-- 40 руд разом и не ломает соотношения между ними.
	-- РЕБАЛАНС ЭКОНОМИКИ v2 (по прямому запросу — "кристаллы/пассивный
	-- доход слишком сильные, прогрессия должна идти за счёт шахтёрства").
	-- Подиумный доход больше НЕ считается по таблице IncomePerMinute на
	-- руду (это и разгоняло экономику само по себе — см. OreIncome.lua).
	-- Теперь это простая, честная и легко читаемая формула:
	--   доход/мин = PassiveIncomePercentOfCart × стоимость ПОЛНОЙ тележки
	--               на тире игрока × бонус уровня руды (мелкий) × мутация
	--   → копится в сейф, включая оффлайн (существующая механика сейфа,
	--     см. PassiveIncomeService/BankService — не тронута).
	-- 0.05 = ровно "+5% от продажи всей тележки", как и просили. Если
	-- по тесту это всё ещё много — крути только эту строку, не формулу.
	PassiveIncomePercentOfCart = 0.05, -- legacy (v3 использует CartShare кристалла, см. OreIncome.PerMinute)
	PassiveIncomeMultiplier = 1, -- v3: общий рубильник поверх CartShare -- доп. глобальный рубильник "максимально занерфить" поверх процента — эффективно ~2.5% в минуту устоявшегося дохода от полной тележки

	-- СБРОС КОЛЛЕКЦИИ ЖЕОД/РУД ПРИ РЕБЁРТЕ. По ТЗ автор сам не был
	-- уверен, оставить или нет — оставлено ВЫКЛЮЧЕННЫМ по умолчанию
	-- (коллекция — это прогресс, который приятно копить между ребёртами).
	-- Включить: поставить true — DataService/RebirthService должны при
	-- ребёрте чистить data.GeodeCollection и data.InstalledGeodeOre (это
	-- ещё предстоит подключить в RebirthService:Perform, см. ROADMAP.md).
	ResetCollectionOnRebirth = false,

	-- ВТОРАЯ ТАБЛИЧКА НАД ПОДИУМОМ (название руды + доход + мутации).
	--
	-- Выключена по прямому запросу. Над самим кристаллом теперь висит
	-- отдельная подпись "$X/SEC" (см. IncomeLabel в PassiveIncomeService),
	-- и эта табличка стала её дублем: она повторяла тот же доход, только
	-- в минутах, добавляла название и список мутаций — и всё это вторым
	-- слоем поверх модели кристалла, загораживая его.
	--
	-- Флаг влияет ТОЛЬКО на подиум с УСТАНОВЛЕННЫМ кристаллом. На пустом
	-- подиуме табличка ("NO ORE INSTALLED") показывается всегда,
	-- независимо от этого значения: там нечего дублировать, а без неё
	-- подиум выглядел бы безымянной тумбой.
	--
	-- true вернёт прежнее поведение — код надписи никуда не делся и
	-- продолжает исправно формироваться.
	ShowPodiumStatusLabel = false,

	-- Как часто сервер перерисовывает табличку сейфа с таймером «до
	-- заполнения» (см. PassiveIncomeService:_startSafeTimerLoop). Секунды.
	-- Мельче 1 не имеет смысла: таймер показывается в часах/минутах.
	SafeTimerRefresh = 1,

	DuplicateCopiesPerLevel = { 1, 3, 7, 12, 18, 25, 33, 42, 52, 63 },
	MaxOreLevel = 10,
	IncomePerLevel = 0.04, -- было 0.10 (макс. +90% на 10 уровне) → теперь макс. +36%, коллекционирование дублей даёт приятный, но не решающий бонус
	CartSpawnVfxDuration = 2.5,

	-- Порядок жеод 1:1 с тирами Шахты (Order[tier] = тип жеоды этого тира,
	-- см. SpawnByMineTier ниже). Меняешь порядок тут — автоматически
	-- меняется и то, какая пара типов выпадает на каждом тире шахты.
	Order = { "Stone", "Crystal", "Amber", "Topaz", "Jade", "Onyx", "Aurora", "Nebula", "Quasar", "Singularity" },

	-- РЕБАЛАНС v3 (см. ТЗ "предложи как переделать дроп жеод"): MoneyChance
	-- урезан с 0.85 до 0.55 у ВСЕХ типов (см. Types ниже), а освободившиеся
	-- 30% поделены между рудой (+15%, теперь 25%) и новыми временными
	-- баффами (15%, см. Config.Buffs). Комментарий сразу под этим — "частоту
	-- MoneyChance трогать не надо" — от ПРЕДЫДУЩЕГО прохода ребаланса,
	-- когда ещё не было баффов; суммы Money[] из того прохода не трогаем,
	-- их процент выпадения теперь просто ниже.
	BuffChance = 0.15,

	-- ПЕРЕБАЛАНС НАГРАД ЖЕОД — по прямому запросу ("слишком много денег
	-- падает"). Уточнение: частоту (MoneyChance = 0.85 у всех типов ниже)
	-- трогать НЕ НАДО — 85% денег/~5% скин/~10% руды остаётся как было.
	-- Урезаны САМИ СУММЫ — у каждого типа все три значения Money (обычная/
	-- средняя/джекпот) уменьшены РОВНО ВДВОЕ относительно прежних чисел.
	-- Соотношение между обычной/средней/джекпот-суммой внутри каждого типа
	-- не менялось (джекпот по-прежнему в 4-8 раз больше обычной — см.
	-- rewardIndex 70/25/5% в GeodeService), поэтому джекпот всё так же
	-- ощутимо крупнее и остаётся тем самым "праздничным" моментом, просто
	-- в абсолютных числах вдвое меньше, чем раньше.
	Types = {
		Stone = {
			DisplayName = "Stone Geode", Color = Color3.fromRGB(145, 155, 170),
			Rarity = "Common",
			DustChance = 0, MoneyChance = 0.55, Money = { 300, 600, 2400 },
			Ores = { "Quartz", "Amethyst", "GreenCrystal" },
		},
		Crystal = {
			DisplayName = "Crystal Geode", Color = Color3.fromRGB(90, 195, 255),
			Rarity = "Rare",
			DustChance = 0, MoneyChance = 0.55, Money = { 3000, 6000, 22500 },
			Ores = { "Sapphire", "Ruby", "Diamond" },
		},
		Amber = {
			DisplayName = "Amber Geode", Color = Color3.fromRGB(255, 165, 60),
			Rarity = "Uncommon",
			DustChance = 0, MoneyChance = 0.55, Money = { 22500, 45000, 170000 },
			Ores = { "Citrine", "Carnelian", "SunOpal" },
		},
		Topaz = {
			DisplayName = "Topaz Geode", Color = Color3.fromRGB(60, 220, 210),
			Rarity = "Rare",
			DustChance = 0, MoneyChance = 0.55, Money = { 300000, 600000, 2250000 },
			Ores = { "Aquamarine", "Turquoise", "Moonstone" },
		},
		Jade = {
			DisplayName = "Jade Geode", Color = Color3.fromRGB(70, 220, 140),
			Rarity = "Rare",
			DustChance = 0, MoneyChance = 0.55, Money = { 2250000, 4500000, 17000000 },
			Ores = { "Peridot", "Malachite", "Tourmaline" },
		},
		Onyx = {
			DisplayName = "Onyx Geode", Color = Color3.fromRGB(70, 55, 90),
			Rarity = "Epic",
			DustChance = 0, MoneyChance = 0.55, Money = { 25000000, 60000000, 190000000 },
			Ores = { "Garnet", "Bloodstone", "Obsidianite" },
		},
		Aurora = {
			DisplayName = "Aurora Geode", Color = Color3.fromRGB(255, 140, 220),
			Rarity = "Epic",
			DustChance = 0, MoneyChance = 0.55, Money = { 250000000, 600000000, 2000000000 },
			Ores = { "Starshard", "Moonlight", "Prism" },
		},
		Nebula = {
			DisplayName = "Nebula Geode", Color = Color3.fromRGB(150, 60, 230),
			Rarity = "Mythic",
			DustChance = 0, MoneyChance = 0.55, Money = { 2500000000, 6000000000, 20000000000 },
			Ores = { "Voidshard", "Stardust", "Eclipse" },
		},
		-- ТИРЫ 9 И 10. Раньше Order обрывался на Nebula (8 типов), а тиров
		-- шахты десять — игроки на 9-10 тире получали ту же Nebula, что и на
		-- 8, и прогрессия жеод для них заканчивалась досрочно.
		--
		-- Рост дохода здесь замедлен до x2 и x1.75 (по всей остальной шкале
		-- шаг x10) — ровно по той же причине, что и у валунных руд:
		-- Config.Economy.MaxCurrency = 9e15 стоит на пределе точного целого
		-- для double, а одна оффлайн-выплата это 1440 мин x 1.9 x доход.
		-- Продолжение кривой x10 дало бы 1.2 трлн/мин, то есть 36% всего
		-- потолка валюты за ОДИН сбор.
		Quasar = {
			DisplayName = "Quasar Geode", Color = Color3.fromRGB(120, 235, 255),
			Rarity = "Mythic",
			DustChance = 0, MoneyChance = 0.55, Money = { 5000000000, 12000000000, 40000000000 },
			Ores = { "Pulsarite", "Ionshard", "Quasarite" },
		},
		Singularity = {
			DisplayName = "Singularity Geode", Color = Color3.fromRGB(35, 15, 55),
			Rarity = "Mythic",
			DustChance = 0, MoneyChance = 0.55, Money = { 8750000000, 21000000000, 70000000000 },
			Ores = { "Riftstone", "Eventcore", "Infinitum" },
		},
	},

	-- Тир шахты → какая пара типов жеод может выпасть (см. Order выше).
	-- Chance — шанс спавна ЛЮБОЙ жеоды на этом тире (как раньше).
	-- NextWeight — из ДВУХ типов, доступных на этом тире (Order[tier] и
	-- Order[tier+1]), это шанс выпадения ИМЕННО второго/более редкого —
	-- прямая замена старого CrystalWeight, только теперь применяется к
	-- любой соседней паре, а не только к Stone/Crystal. Типов в Order
	-- сейчас 10, так что "следующего" нет только у последнего (Singularity)
	-- — там код клэмпит на Order[10] и NextWeight ни на что не влияет.
	-- (Раньше здесь было написано про тир 8 и Order[9] — это осталось от
	-- версии с восемью типами жеод.)
	SpawnByMineTier = {
		[1] = { Chance = 0.025, NextWeight = 0.05 }, -- Stone | Crystal
		[2] = { Chance = 0.025, NextWeight = 0.08 }, -- Crystal | Amber
		[3] = { Chance = 0.030, NextWeight = 0.20 }, -- Amber | Topaz
		[4] = { Chance = 0.030, NextWeight = 0.30 }, -- Topaz | Jade
		[5] = { Chance = 0.035, NextWeight = 0.50 }, -- Jade | Onyx
		[6] = { Chance = 0.035, NextWeight = 0.65 }, -- Onyx | Aurora
		[7] = { Chance = 0.040, NextWeight = 0.80 }, -- Aurora | Nebula
		[8] = { Chance = 0.040, NextWeight = 0.90 }, -- Nebula | Quasar
		[9] = { Chance = 0.045, NextWeight = 0.90 }, -- Quasar | Singularity
		[10] = { Chance = 0.045, NextWeight = 0.90 }, -- Singularity only
	},
	Ores = {
		-- Доходы снижены примерно в 6 раз, чтобы случайный редкий кристалл не
		-- позволял мгновенно перескочить несколько старых тиров.
		-- Stone geode
		Quartz = { DisplayName = "Quartz", Rarity = "Common", IncomePerMinute = 300, CartShare = 0.025, ImageId = 90540571354545, Color = Color3.fromRGB(225, 235, 245) },
		Amethyst = { DisplayName = "Amethyst", Rarity = "Uncommon", IncomePerMinute = 327, CartShare = 0.02707, ImageId = 78116664866705, Color = Color3.fromRGB(175, 105, 255) },
		GreenCrystal = { DisplayName = "Green Crystal", Rarity = "Uncommon", IncomePerMinute = 356, CartShare = 0.0293, ImageId = 103070984387374, Color = Color3.fromRGB(80, 235, 145) },
		-- Crystal geode
		Sapphire = { DisplayName = "Sapphire", Rarity = "Rare", IncomePerMinute = 388, CartShare = 0.03172, ImageId = 100189232384547, Color = Color3.fromRGB(70, 125, 255) },
		Ruby = { DisplayName = "Ruby", Rarity = "Rare", IncomePerMinute = 423, CartShare = 0.03435, ImageId = 88650086346270, Color = Color3.fromRGB(245, 65, 90) },
		Diamond = { DisplayName = "Diamond", Rarity = "Epic", IncomePerMinute = 460, CartShare = 0.03718, ImageId = 106478719229378, Color = Color3.fromRGB(135, 245, 255) },
		-- Amber geode
		Citrine = { DisplayName = "Citrine", Rarity = "Uncommon", IncomePerMinute = 502, CartShare = 0.04026, ImageId = 116861831841551, Color = Color3.fromRGB(255, 210, 90) },
		Carnelian = { DisplayName = "Carnelian", Rarity = "Uncommon", IncomePerMinute = 547, CartShare = 0.04358, ImageId = 102513826140913, Color = Color3.fromRGB(230, 105, 65) },
		SunOpal = { DisplayName = "Sun Opal", Rarity = "Rare", IncomePerMinute = 595, CartShare = 0.04718, ImageId = 111872338058594, Color = Color3.fromRGB(255, 190, 140) },
		-- Topaz geode
		Aquamarine = { DisplayName = "Aquamarine", Rarity = "Rare", IncomePerMinute = 649, CartShare = 0.05108, ImageId = 133295027981209, Color = Color3.fromRGB(95, 220, 215) },
		Turquoise = { DisplayName = "Turquoise", Rarity = "Rare", IncomePerMinute = 707, CartShare = 0.05531, ImageId = 127845132293561, Color = Color3.fromRGB(60, 200, 180) },
		Moonstone = { DisplayName = "Moonstone", Rarity = "Epic", IncomePerMinute = 770, CartShare = 0.05988, ImageId = 115417306860831, Color = Color3.fromRGB(210, 235, 245) },
		-- Jade geode
		Peridot = { DisplayName = "Peridot", Rarity = "Rare", IncomePerMinute = 839, CartShare = 0.06482, ImageId = 105773667329038, Color = Color3.fromRGB(165, 230, 90) },
		Malachite = { DisplayName = "Malachite", Rarity = "Epic", IncomePerMinute = 914, CartShare = 0.07018, ImageId = 71709900220158, Color = Color3.fromRGB(35, 155, 105) },
		Tourmaline = { DisplayName = "Tourmaline", Rarity = "Epic", IncomePerMinute = 996, CartShare = 0.07598, ImageId = 97740850725709, Color = Color3.fromRGB(60, 200, 150) },
		-- Onyx geode
		Garnet = { DisplayName = "Garnet", Rarity = "Epic", IncomePerMinute = 1080, CartShare = 0.08226, ImageId = 140081692580068, Color = Color3.fromRGB(155, 35, 55) },
		Bloodstone = { DisplayName = "Bloodstone", Rarity = "Epic", IncomePerMinute = 1180, CartShare = 0.08906, ImageId = 106678803949887, Color = Color3.fromRGB(90, 30, 40) },
		Obsidianite = { DisplayName = "Obsidianite", Rarity = "Legendary", IncomePerMinute = 1290, CartShare = 0.09642, ImageId = 129073724801216, Color = Color3.fromRGB(40, 35, 50) },
		-- Aurora geode
		Starshard = { DisplayName = "Starshard", Rarity = "Epic", IncomePerMinute = 1400, CartShare = 0.10438, ImageId = 96343160983705, Color = Color3.fromRGB(255, 235, 150) },
		Moonlight = { DisplayName = "Moonlight", Rarity = "Legendary", IncomePerMinute = 1530, CartShare = 0.11301, ImageId = 125944021953275, Color = Color3.fromRGB(220, 225, 255) },
		Prism = { DisplayName = "Prism", Rarity = "Legendary", IncomePerMinute = 1660, CartShare = 0.12235, ImageId = 96255917093476, Color = Color3.fromRGB(255, 175, 235) },
		-- Nebula geode
		Voidshard = { DisplayName = "Voidshard", Rarity = "Legendary", IncomePerMinute = 1810, CartShare = 0.13246, ImageId = 98952040742336, Color = Color3.fromRGB(130, 60, 200) },
		Stardust = { DisplayName = "Stardust", Rarity = "Legendary", IncomePerMinute = 1980, CartShare = 0.1434, ImageId = 81932662099402, Color = Color3.fromRGB(190, 130, 255) },
		Eclipse = { DisplayName = "Eclipse", Rarity = "Mythic", IncomePerMinute = 2150, CartShare = 0.15525, ImageId = 86128663179337, Color = Color3.fromRGB(90, 20, 160) },
		-- Quasar geode (тир 9)
		Pulsarite = { DisplayName = "Pulsarite", Rarity = "Legendary", IncomePerMinute = 2350, CartShare = 0.16808, ImageId = 129335514514909, Color = Color3.fromRGB(150, 240, 255) },
		Ionshard = { DisplayName = "Ionshard", Rarity = "Legendary", IncomePerMinute = 2560, CartShare = 0.18197, ImageId = 127090392935786, Color = Color3.fromRGB(95, 200, 255) },
		Quasarite = { DisplayName = "Quasarite", Rarity = "Mythic", IncomePerMinute = 2780, CartShare = 0.19701, ImageId = 128213369920061, Color = Color3.fromRGB(210, 250, 255) },
		-- Singularity geode (тир 10)
		Riftstone = { DisplayName = "Riftstone", Rarity = "Legendary", IncomePerMinute = 3030, CartShare = 0.21329, ImageId = 120316859917599, Color = Color3.fromRGB(110, 70, 160) },
		Eventcore = { DisplayName = "Eventcore", Rarity = "Mythic", IncomePerMinute = 3300, CartShare = 0.23092, ImageId = 99042977777005, Color = Color3.fromRGB(70, 35, 110) },
		Infinitum = { DisplayName = "Infinitum", Rarity = "Mythic", IncomePerMinute = 3600, CartShare = 0.25, ImageId = 124005785358129, Color = Color3.fromRGB(25, 10, 40) },
	},
	Images = {
		-- Один ключ на КАЖДЫЙ тип из Config.Geodes.Types (имя ключа = имя типа).
		Stone = 86200937826367, Crystal = 92528581177726, Amber = 134298089272556, Topaz = 113789409126204, Jade = 74227558316758, Onyx = 98510762488848, Aurora = 94849713036254, Nebula = 71319199046553,
		Quasar = 138757586861343, Singularity = 74785276598761,
		Dust = 136164605825300,
		MoneySmall = 127870015561896, MoneyLarge = 107293132746970, MoneyJackpot = 111166986298433,
		OfflineIncome = 0, Installed = 0,
		SlotBackground = 0, -- one grayscale image tinted by rarity
		CrackGlow = 126351598729764, -- текстура вспышки за раскалывающейся жеодой
	},
	DropOutlineThickness = 4,
	DropOutlineTransparency = 0,
	ResultDisplayDuration = 3,
	CrackTapCount = 5, -- v20.106: 5 ударов по жеоде до открытия (было 3)
	CrackTapCooldown = 0.32, -- минимальная пауза между засчитанными кликами
	CrackTapShakeDuration = 0.22,
	CrackTapGrowth = 18, -- на сколько пикселей увеличивается жеода после каждого клика

	--------------------------------------------------------------------------------
	-- 3D-ПОСТАНОВКА ОТКРЫТИЯ (по ТЗ: "камера отдаляется так, чтобы было
	-- видно и жеоду на наковальне, и игрока... удар молотком... 2-3 раза,
	-- ФОВ подскакивает как пружинка... после раскола жеода прокручивается
	-- и уменьшается, дроп разлетается кривыми, камера возвращается").
	-- ВАЖНО: экономика (что именно выпало) считается ТОЛЬКО сервером,
	-- как и раньше (см. GeodeService:OpenGeode, не тронут) — вся эта
	-- секция чисто визуальная, на CLIENT (см. GeodeUI.client.lua),
	-- разыгрывается ПОВЕРХ уже существующего 2D-тап-цикла, не вместо
	-- него: то же количество тапов (CrackTapCount выше), тот же момент
	-- отправки запроса серверу (последний засчитанный тап).
	--------------------------------------------------------------------------------
	-- ID анимации удара молотком (Humanoid). 0 — анимация не проигрывается
	-- (только перемещение/камера), пока не вставишь свой AnimationId (по
	-- ТЗ — "я просто вставлю айди анимки").
	HammerAnimationId = 0,

	-- Камера: радиус/высота орбиты вокруг игрока (по прямому запросу —
	-- "камера отдаётся и вращается вокруг игрока медленно") и скорость
	-- перехода FOV в начале.
	CameraBackOffset = 12, -- радиус орбиты
	CameraUpOffset = 7,    -- высота камеры над игроком на орбите
	CameraDollySeconds = 1.1,
	CameraFOVDefault = 70,
	CameraFOVCracking = 64, -- чуть уже во время ударов — фокус на жеоде

	-- Скорость вращения камеры вокруг игрока (радиан/сек) — по прямому
	-- запросу ("камера отдаётся и вращается вокруг игрока медленно").
	CameraOrbitSpeed = 0.35,

	-- FOV-"пружинка" на каждый засчитанный удар (см. ТЗ "резко но
	-- плавно") — тот же приём, что и у мини-игры шахты (см.
	-- Config.MineExpedition.HitFOVKick).
	HitFOVKick = -5,
	HitFOVKickSeconds = 0.2,

	-- Раскалывание (по прямому запросу — "будто ломается или трескается
	-- с партами вокруг"): сколько осколков разлетается от декоративной
	-- жеоды в момент раскола, чисто визуально.
	ShatterPieceCount = 7,
	ShatterFlightSeconds = 0.4,

	-- Разлёт дропа после раскола: сколько декоративных "капель" лута
	-- разлетается (не больше реального числа наград — если наград
	-- меньше, разлетается ровно столько, сколько есть), высота дуги
	-- полёта, время полёта, радиус разброса точек приземления вокруг
	-- игрока, и сколько секунд камера ждёт перед тем, как окончательно
	-- вернуться игроку в руки.
	--
	-- ПО ПРЯМОМУ ЗАПРОСУ ("сделай разлёт сильно привлекательнее") —
	-- капли теперь разлетаются НАМНОГО дальше (было 7 студов радиус,
	-- стало 16), НЕМНОГО медленнее и плавнее (время полёта 0.55 → 0.85,
	-- дуга выше — 6 → 9, так медленный полёт не выглядит вялым), и на
	-- приземлении слегка "приплющиваются" пружинкой (см. LandingSquash*
	-- ниже и spawnScatterDrop в GeodeUI.client.lua) — секунду шире и
	-- ниже, чем обычно, потом плавно назад к нормальной форме.
	ScatterMaxDrops = 8,
	ScatterArcHeight = 9,
	ScatterFlightSeconds = 0.85,
	ScatterRadius = 16,
	-- "Приплющивание" при приземлении — доля от нормального размера по
	-- вертикали/горизонтали в момент удара (0.6 = на 40% ниже и на 25%
	-- шире, чем обычно) и сколько секунд занимает пружинка туда-обратно.
	LandingSquashVertical = 0.6,
	LandingSquashHorizontal = 1.25,
	LandingSquashSeconds = 0.35,
	CameraReturnSeconds = 0.9,
	-- Через сколько секунд после раскола камера возвращается игроку
	-- В ЛЮБОМ случае, даже если не все капли лута ещё собраны — чтобы
	-- нельзя было залипнуть в катсцене, гоняясь за последней каплей.
	CameraReturnTimeout = 6,
}

--------------------------------------------------------------------------------
-- ВРЕМЕННЫЕ БАФФЫ ИЗ ЖЕОД (см. ТЗ, Config.Geodes.BuffChance выше и
-- BuffService.lua — там же подробно расписано, где именно каждый бафф
-- применяется). Amount — бонус СВЕРХ 1.0 для Money/Speed/Damage (0.5 =
-- +50%, здесь везде 1.0 = "х2", как и просили), и прямая ДОБАВКА к удаче
-- для Luck (см. комментарий в BuffService.lua про то, почему удача не
-- множится). Durations — пул длительностей в секундах, на каждый бафф
-- роллится случайно одна из них (по ТЗ: "на минуту, 5 минут").
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
-- ИНВЕНТАРЬ (рюкзак + хотбар + кирки/скины)
--
-- ПРАВИЛА, согласованные напрямую:
--   • Руда подбирается ПРОСТО НАСТУПАНИЕМ на неё (не нужен промпт).
--   • Куда попадёт: тележка В РУКАХ → в тележку; иначе → в рюкзак.
--     (См. InventoryService:TryPickup — одна точка правды на оба случая.)
--   • Продавать можно И из рюкзака, И из тележки.
--   • Рюкзак защищён: при смерти игрока выпадает только DeathDropFraction
--     (25%) СЛУЧАЙНЫХ предметов, остальное остаётся.
--   • Слоты: BaseSlots + ExtraPouch.BonusSlots (+12), а InfinitePouch
--     снимает лимит вовсе.
--   • Хотбар: центральный слот ВСЕГДА кирка (клавиша F), по бокам —
--     обычные слоты 1..6 под руду; выбранная руда берётся в руки, над ней
--     висит её редкость. Зажать ЛКМ на другом игроке с рудой в руках —
--     подарить (см. GiftHoldSeconds).
--------------------------------------------------------------------------------
-- v20.108: ТЕЛЕЖЕК БОЛЬШЕ НЕТ. Вся руда - в рюкзаке; ветка улучшений
-- «Cart» у торговца теперь «Backpack» и растит вместимость рюкзака
-- (сколько кусков руды влезает всего). Замедления от рюкзака нет.
-- false - вернуть тележки как было.
Config.NoCarts = true
Config.Backpack = {
	-- вместимость по тиру ветки = вместимость тележки того же тира, чтобы
	-- экономика (Config.CartValue) не поехала. «SELL ALL» у крота даёт то же
	-- комбо за заполнение, что тележка (до x3 на полном рюкзаке).
	Capacity = { 12, 20, 30, 45, 60, 80, 105, 140, 180 },
	MinCapacity = 12, -- не меньше этого даже на тире 1
	TutorialCapacity = 30, -- пока идёт обучение
	ExtraPouchBonus = 20,  -- геймпасс Extra Pouch
	Icon = "🎒",
}
function Config.BackpackCapacity(tier)
	local list = Config.Backpack.Capacity
	return list[math.clamp(math.floor(tonumber(tier) or 1), 1, #list)]
end

Config.Inventory = {
	-- v20.112: в инвентаре только последняя открытая кирка, надета всегда она.
	-- false - старое поведение (карточка на каждый открытый тир).
	OnlyBestPickaxe = true,
	-- v20.63: руда в инвентаре/хотбаре - 3D-модель (вариация + мутации),
	-- а не нарисованная иконка. PreviewOutline - обводка силуэта:
	-- цвет (чёрный читается на любом фоне), толщина - доля размера ячейки.
	ModelPreviews = true,
	PreviewOutline = true,
	PreviewOutlineColor = Color3.fromRGB(0, 0, 0),
	PreviewOutlineScale = 0.12,
	BaseSlots = 24,        -- базовая вместимость рюкзака (стопки, см. StackSize)
	-- СТАРТОВЫЙ РЮКЗАК — пока не куплена первая тележка (Data.CartUnlocked).
	-- Держит в честных рамках продажу руды из рюкзака (см.
	-- Config.Bank.InventorySellEnabled): руками можно донести немного, а не
	-- заменить этим рейс тележкой. Расширяется до BaseSlots автоматически в
	-- момент покупки тележки (см. InventoryService:GetSlotCount).
	StarterSlots = 5,
	TutorialSlots = 15,    -- v20.40: ячеек рюкзака, пока идёт обучение (потом снова StarterSlots/BaseSlots)
	StackSize = 99,        -- сколько одинаковых предметов лежит в одной ячейке
	PickupRadius = 7.5,    -- стадов: насколько близко надо подойти, чтобы "наступить" на руду (было 4.5 — увеличено на ~65%)
	PickupCooldown = 0.08, -- сек между подборами, чтобы куча не всасывалась одним кадром
	-- Перелив ВСЕЙ руды в свою тележку, когда игрок ближе Config.Cart.
	-- DepositDistance к ней: по одному куску раз в столько секунд.
	CartAutoDepositInterval = 0.08,

	-- 25% случайного лута выпадает при смерти (по прямому запросу — рюкзак
	-- "по сути защищённая штука"). Остальное сохраняется.
	DeathDropFraction = 0.25,
	-- v10: при смерти руда реально падает на землю — не больше этого числа
	-- кусков, крутятся на месте и ждут, пока их подберут.
	DeathDropMaxItems = 5,
	DeathDropSpinSpeed = 2.5,

	-- Хотбар: 6 обычных слотов + центральный слот кирки (F).
	HotbarSlots = 6,
	PickaxeKey = Enum.KeyCode.F,

	-- Держать ЛКМ на игроке столько секунд, чтобы подарить ему предмет из
	-- руки. Достаточно долго, чтобы не дарить случайно в толпе.
	GiftHoldSeconds = 1.2,
	GiftMaxDistance = 18,

	-- Ярлык редкости над рудой в руках.
	HeldRarityBillboardHeight = 2.4,
}

--------------------------------------------------------------------------------
-- СКИНЫ КИРОК — небольшие баффы, чтобы у выбитых скинов был смысл (по
-- прямому запросу). Складываются с характеристиками самой кирки; скины
-- НЕ заменяют тир кирки, только слегка его подкручивают, поэтому бонусы
-- намеренно маленькие — скин не должен обгонять апгрейд.
--
-- Ключи = имена скинов из Config.Skins (см. ниже по файлу). Скин, не
-- перечисленный здесь, просто не даёт бонуса — это не ошибка.
--------------------------------------------------------------------------------
Config.PickaxeSkinBuffs = {
	Default = { Damage = 0.00, Luck = 0.00, Speed = 0.00 },
	Bronze  = { Damage = 0.02, Luck = 0.01, Speed = 0.00 },
	Silver  = { Damage = 0.03, Luck = 0.02, Speed = 0.01 },
	Gold    = { Damage = 0.05, Luck = 0.03, Speed = 0.01 },
	Diamond = { Damage = 0.07, Luck = 0.05, Speed = 0.02 },
	Crystal = { Damage = 0.08, Luck = 0.06, Speed = 0.02 },
	Void    = { Damage = 0.10, Luck = 0.08, Speed = 0.03 },
}

-- БАФФЫ.
--
-- Множители добычи ("1.5x mining") убраны как неликвид: они ускоряли то,
-- что игрок и так делает, и на результат ролла не влияли никак — то есть
-- не меняли НИЧЕГО интересного. Их место заняли баффы, которые влияют
-- на то, ЧТО выпадает:
--
--   Luck           — сдвигает ролл руды к редким слотам тира;
--   MutationPotion — поднимает шанс мутаций выше, чем у обычной руды
--                    (см. MutationRoll.Roll → rollMultiplier);
--   Money/Speed    — оставлены, они честно полезны и понятны.
--
-- Description — текст всплывающей подсказки в панели баффов (см.
-- client/BuffBar.client.lua): игрок должен понимать, что именно ему дали.
Config.Buffs = {
	Order = { "Luck", "MutationPotion", "Money", "Speed" }, -- дроп жеод; Damage сюда не входит
	-- Урон — только из зелья торговца (Config.Potions), из жеод не падает;
	-- запись нужна панели бафов (BuffBar) для иконки и подписи.
	Damage = {
		DisplayName = "2X DAMAGE",
		Amount = 1.0,
		Rarity = "Rare",
		ImageId = 0,
		IconText = "DMG",
		Color = Color3.fromRGB(255, 90, 70),
		Description = "Doubles your pickaxe damage.",
	},
	Durations = { 60, 300 },

	Luck = {
		DisplayName = "LUCK",
		Amount = 0.05,
		Rarity = "Epic",
		ImageId = 0,
		IconText = "LK",
		Color = Color3.fromRGB(120, 235, 140),
		Description = "Increases luck: ore rolls land on rarer slots of the tier more often.",
	},
	MutationPotion = {
		DisplayName = "MUTATION POTION",
		-- Множитель шанса мутаций. 2.5 означает, что мутации выпадают в
		-- 2.5 раза чаще обычного — заметно, но не гарантированно: иначе
		-- мутации перестали бы быть событием.
		Amount = 2.5,
		Rarity = "Legendary",
		ImageId = 0,
		IconText = "MU",
		Color = Color3.fromRGB(215, 130, 255),
		Description = "Mutation potion: mined ore is far more likely to roll a mutation.",
	},
	Money = {
		DisplayName = "2X MONEY",
		Amount = 1.0,
		Rarity = "Epic",
		ImageId = 0,
		IconText = "$",
		Color = Color3.fromRGB(255, 215, 110),
		Description = "Doubles the money you earn from selling ore.",
	},
	Speed = {
		DisplayName = "+25% SPEED",
		Amount = 0.25, -- v20.104: было x2 - слишком быстро
		Rarity = "Rare",
		ImageId = 0,
		IconText = "SP",
		Color = Color3.fromRGB(120, 200, 255),
		Description = "+25% movement speed.",
	},
}

Config.Boulders = {
	--------------------------------------------------------------------------
	-- ВАЛУНЫ НА СВОЕЙ БАЗЕ (см. RockService:SetupPlot).
	--
	-- Обычные валуны стоят по карте на точках workspace.RubbleBoulderSpawnPoints
	-- и общие для всех. Эти — ЛИЧНЫЕ: по одному на каждый маркер
	-- BoulderMarkerN внутри PlotTemplate (обычный BasePart, как MineMarker;
	-- код прячет его сам). Именно они держат вход в шахту в начале игры и
	-- остаются на базе навсегда как способ добыть руду, не заходя внутрь.
	--
	-- ТИР. Растёт вместе с шахтой, НО никогда не уходит дальше, чем на
	-- Config.BoulderGame.MaxDiffWithPickaxe от кирки игрока. Без этой
	-- привязки база вставала бы намертво: валун на 2+ тира выше кирки
	-- физически не ломается ничем, кроме динамита (см. boulderHitsNeeded в
	-- RockService), и игрок с прокачанной шахтой, но отставшей киркой
	-- оставался бы с двумя вечными камнями у входа.
	--
	-- ДРОП. Денег НЕ дают вообще (в отличие от карты) — только руду своего
	-- тира и иногда жеоду. Причина простая: на первом тире обычный валун
	-- роняет сразу ~$67 (RewardMoneyByTier ниже), то есть новичок получал
	-- бы деньги на починку шахты, ни разу не дойдя до банка — и шаг
	-- "продай руду" схлопывался бы сам собой ещё до того, как игрок узнал,
	-- где вообще находится банк.
	--------------------------------------------------------------------------
	Base = {
		MarkerPrefix = "BoulderMarker", -- BoulderMarker1, BoulderMarker2, ...
		MaxPerPlot = 8,                 -- страховка от случайных 50 маркеров в шаблоне
		RespawnDelay = 75,              -- дольше обычных 12 сек: это личный, бесконкурентный источник руды
		-- СКОЛЬКО КУСКОВ РУДЫ ПАДАЕТ С ОДНОГО ВАЛУНА.
		--
		-- 2-3 штуки на ЛЮБОМ тире, и до починки шахты, и после. Число
		-- намеренно маленькое и намеренно НЕ растёт с тиром: валун стоит
		-- прямо на базе, ломается без всякой подготовки и респавнится сам,
		-- так что щедрый дроп быстро обесценил бы поход в шахту — а шахта
		-- это и есть основной цикл игры. Валуны должны оставаться
		-- подспорьем между рейсами, а не их заменой.
		--
		-- На старте этого достаточно: копить в прологе больше не на что —
		-- и починка шахты, и первая тележка бесплатны.
		OreCountBroken = { 2, 3 },
		OreCountRepaired = { 2, 3 },
		GeodeChance = 0.18,
		-- Разлёт руды вокруг валуна.
		OreSpreadStuds = 6,
		OreUpSpeed = 26,
		OreOutSpeed = 13,
	},

	IconImage = "rbxassetid://115197451246697",
	MaxActive = 16,
	RespawnDelay = 12,
	EliteChance = 0.08,
	EliteHealthMultiplier = 2.5,
	GroupDamageMultiplier = 0.18,
	CrystalChance = 0.075,
	GeodeNextWeight = 0.12,
	RewardCountExtraChance = 0.12,
	CrystalPickupHoldDuration = 1.2,

	-- ЦВЕТ ОСКОЛКОВ ПО ТИРУ ВАЛУНА (см. RockService:_spawnHitDebris) — по
	-- прямому запросу, один цвет на каждый из 9 тиров.
	HitDebrisColors = {
		[1] = Color3.fromRGB(150, 150, 150), -- серый
		[2] = Color3.fromRGB(70, 175, 235),  -- сине-голубой, ближе к голубому
		[3] = Color3.fromRGB(150, 80, 20),   -- тёмно-оранжевый
		[4] = Color3.fromRGB(255, 200, 60),  -- золотой
		[5] = Color3.fromRGB(60, 200, 90),   -- зелёный
		[6] = Color3.fromRGB(25, 25, 25),    -- чёрный
		[7] = Color3.fromRGB(40, 90, 220),   -- синий
		[8] = Color3.fromRGB(150, 60, 220),  -- фиолетовый
		[9] = Color3.fromRGB(110, 20, 20),   -- красно-чёрный
	},

	-- АНИМАЦИЯ РАЗРУШЕНИЯ ВАЛУНА (см. RockService:Break → playBreakAnimation).
	-- "Сжатие и хлопок": валун сперва приседает/сплющивается, потом резко
	-- раздувается и лопается вспышкой партиклов. Специально НЕ создаёт ни
	-- одной новой физической детали — работает одинаково и с кастомной
	-- моделью Boulder_TierN (через Model:ScaleTo), и с шаром-плейсхолдером
	-- (через прямое изменение Size, там сплющивание получается настоящим,
	-- неравномерным). Тайминги вынесены сюда, а не захардкожены, как и
	-- везде в проекте.
	-- РОТАЦИЯ ТИРОВ У НЕТРОНУТЫХ ВАЛУНОВ. Валун, который никто не начал
	-- бить в течение IdleSeconds, тихо подменяется валуном другого тира на
	-- той же точке. Смысл — чтобы карта не застывала в одной раскладке
	-- тиров: игрок, доросший до тира 6, рано или поздно увидит валун своего
	-- уровня рядом, даже если точку рядом с ним изначально расставили под
	-- тир 1.
	--
	-- КАК ТОЛЬКО ПО ВАЛУНУ УДАРИЛИ ХОТЬ РАЗ — таймер для него не идёт
	-- больше НИКОГДА (state.Damaged, см. RockService:Damage). Валун, в
	-- который вложились, обязан дожить до того, кто его добьёт: подменить
	-- его на другой тир значило бы стереть чужой прогресс.
	-- СЛУЧАЙНЫЙ РАЗВОРОТ ПРИ СПАВНЕ. Валун ставится повёрнутым на кратный
	-- SpawnRotationStep угол вокруг вертикальной оси — при шаге 90 это один
	-- из четырёх вариантов: 0, 90, 180, 270. Одна и та же модель за счёт
	-- этого читается по-разному, и ряд одинаковых валунов не выглядит
	-- штампованным.
	--
	-- Кратный угол, а не произвольный, выбран намеренно: валуны часто
	-- вытянутые или с плоской гранью, и произвольный поворот у таких моделей
	-- заметно меняет силуэт и посадку на землю. Кратность 90 сохраняет
	-- задуманную ориентацию, просто разворачивая её.
	--
	-- Разворот применяется и при ротации тиров, и при обычном респавне после
	-- слома — оба пути идут через SpawnAtPoint.
	SpawnRotationStep = 90, -- поставь 0, чтобы отключить разворот совсем

	TierRotation = {
		Enabled = true,
		IdleSeconds = 90,      -- сколько валун должен простоять нетронутым
		CheckInterval = 5,     -- как часто проверяем (не чаще — это фон)
		-- Не подменяем валун, если рядом есть игрок: подмена прямо на
		-- глазах выглядит как баг. Ждём, пока отойдёт.
		MinPlayerDistance = 70,
		FadeDuration = 0.35,   -- плавное растворение старого и появление нового
	},

	-- АНИМАЦИЯ РАЗРУШЕНИЯ — "замах и усадка" (см. RockService,
	-- playBreakAnimation). Раньше валун раздувался и лопался, из-за чего
	-- читался как надувной шарик; теперь он коротко замахивается и быстро
	-- уменьшается почти в точку, оседая в землю и растворяясь.
	BreakFx = {
		AnticipateDuration = 0.10, -- фаза 1: короткий замах перед усадкой
		AnticipateScale = 1.14,    -- до чего раздувается в замахе (1 = исходный размер)
		AnticipateStretch = 0.90,  -- насколько при этом поджимается вширь (только одиночная деталь)
		ShrinkDuration = 0.34,     -- фаза 2: усадка (в конце модель удаляется)
		ShrinkScale = 0.03,        -- во что уменьшается перед исчезновением
		SpinDegrees = 55,          -- лёгкая подкрутка за время усадки; 0 — отключить
		BreakDebrisBursts = 3,     -- сколько пачек осколков разлетается в момент разлома
	},
	-- Денежный дроп с валунов уменьшен примерно в 6 раз, чтобы он не
	-- позволял перескакивать ранние тиры после одного удачного выпадения.
	RewardMoneyByTier = { 1000, 3000, 10000, 40000, 150000, 533333, 2000000, 7500000, 28333333, 108333333 },
	-- v8: скины больше НЕ падают из валунов напрямую — только из сундуков
	-- (Config.Chests, очень маленький шанс). Их 7.5% ушли в деньги.
	RewardOdds = { Money = 0.725, Geode = 0.20, Crystal = 0.075, Skin = 0 },
	CustomOres = {
	-- ДОХОД ВАЛУННЫХ РУД ПРИВЯЗАН К ЖЕОДНОЙ ШКАЛЕ (Config.Geodes.Ores).
	-- Раньше эти числа шли от 5 до 35 000/мин, тогда как жеодные руды — от
	-- 2 000 до 12 000 000 000. То есть Titanheart, мифическая руда с валуна
	-- 10 тира, стоил меньше восемнадцати Quartz — обычной руды из самой
	-- первой жеоды. Судя по комментарию у Config.Geodes.Ores ("относительно
	-- T8 = $15,000/мин") и по тому, что Wyrmglass стоил ровно 15 000,
	-- валунные руды просто остались на старой шкале, когда жеодные
	-- перебалансировали вверх. Денежная награда с валунов (RewardMoneyByTier)
	-- при этом уже была на новой шкале — отстал только кристалл.
	--
	-- Теперь каждая руда стоит примерно на треть больше лучшей ЖЕОДНОЙ руды
	-- того же тира. Надбавка оправдана редкостью: кристалл выпадает с шансом
	-- RewardOdds.Crystal = 0.075 за ролл, то есть примерно с каждого
	-- тринадцатого валуна, а сами валуны общие — за них конкурируют.
	--
	-- Тиры 9 и 10 растут медленнее (x2 и x1.75 вместо x10): выше 8 тира
	-- жеод нет, а продолжать кривую x10 нельзя из-за потолка валюты.
	-- Config.Economy.MaxCurrency = 9e15 выбран по пределу точного целого для
	-- double, а максимум одной оффлайн-выплаты равен 1440 мин x 1.9 (10 ур.)
	-- x доход. Доходы кристаллов намеренно ограничены примерно шестой частью
	-- прежней шкалы, чтобы редкая находка не ломала прогрессию тиров.
		Rubblegem = { DisplayName = "Rubblegem", Rarity = "Common", IncomePerMinute = 409, CartShare = 0.03384, ImageId = 114573292246340, Color = Color3.fromRGB(165, 165, 175) },
		Ironflake = { DisplayName = "Ironflake", Rarity = "Uncommon", IncomePerMinute = 529, CartShare = 0.04294, ImageId = 101505497180338, Color = Color3.fromRGB(150, 170, 185) },
		Coalheart = { DisplayName = "Coalheart", Rarity = "Uncommon", IncomePerMinute = 684, CartShare = 0.05448, ImageId = 138466835816471, Color = Color3.fromRGB(55, 55, 65) },
		Duskstone = { DisplayName = "Duskstone", Rarity = "Rare", IncomePerMinute = 884, CartShare = 0.06914, ImageId = 93068330467531, Color = Color3.fromRGB(105, 85, 135) },
		["VerdantCore"] = { DisplayName = "Verdant Core", Rarity = "Rare", IncomePerMinute = 1143, CartShare = 0.08773, ImageId = 98810385642509, Color = Color3.fromRGB(70, 190, 105) },
		Emberite = { DisplayName = "Emberite", Rarity = "Epic", IncomePerMinute = 1475, CartShare = 0.11133, ImageId = 108659852563633, Color = Color3.fromRGB(245, 95, 45) },
		Frostvein = { DisplayName = "Frostvein", Rarity = "Epic", IncomePerMinute = 1913, CartShare = 0.14126, ImageId = 131041812268177, Color = Color3.fromRGB(125, 220, 255) },
		Wyrmglass = { DisplayName = "Wyrmglass", Rarity = "Legendary", IncomePerMinute = 2475, CartShare = 0.17925, ImageId = 87444139967682, Color = Color3.fromRGB(85, 235, 170) },
		["UmbralShard"] = { DisplayName = "Umbral Shard", Rarity = "Legendary", IncomePerMinute = 3200, CartShare = 0.22746, ImageId = 79470978502778, Color = Color3.fromRGB(75, 45, 115) },
		Titanheart = { DisplayName = "Titanheart", Rarity = "Mythic", IncomePerMinute = 4125, CartShare = 0.28865, ImageId = 100833451509872, Color = Color3.fromRGB(255, 185, 55) },
	},
}
for oreId, info in Config.Boulders.CustomOres do
	Config.Geodes.Ores[oreId] = info
end

--------------------------------------------------------------------------------
-- ЭКОНОМИКА v3: ДЕНЕЖНЫЙ ДРОП ЖЕОД И ВАЛУНОВ — в «полных тележках».
-- Раньше суммы были абсолютными и росли x10 за тип (как цены апгрейдов,
-- а не как доход): Crystal-жеода на старте давала до ~19 тележек, а на
-- поздних тирах денежный дроп почти ничего не значил. Теперь каждая сумма
-- = доля полной тележки пещеры, к которой относится жеода/валун
-- (Config.CartValue), поэтому награда одинаково ощутима на любом этапе.
-- Меняешь щедрость — правь только эти коэффициенты.
--------------------------------------------------------------------------------
local function niceMoney(value)
	value = math.max(1, value)
	if value < 100 then return math.max(1, math.floor(value + 0.5)) end
	local step = 10 ^ (math.floor(math.log10(value)) - 1)
	return math.floor(value / step + 0.5) * step
end

-- Естественный тир тележки для пещеры (9 тележек на 15 пещер) — для оценок.
function Config.NaturalCartTierForCave(cave)
	return math.clamp(1 + math.floor((cave - 1) * (#Config.CartTiers - 1) / (#Config.MineTiers - 1) + 0.5), 1, #Config.CartTiers)
end
-- Какой тип жеоды «родной» для пещеры: 10 типов растянуты на 15 пещер.
function Config.GeodeTypeIndexForCave(cave)
	cave = math.clamp(math.floor(tonumber(cave) or 1), 1, #Config.MineTiers)
	return math.clamp(1 + math.floor((cave - 1) * (#Config.Geodes.Order - 1) / (#Config.MineTiers - 1) + 0.5), 1, #Config.Geodes.Order)
end

Config.Geodes.MoneyInCarts = { 0.4, 1, 3 } -- малый / средний / джекпот
for index, geodeType in Config.Geodes.Order do
	local info = Config.Geodes.Types[geodeType]
	if info then
		-- Первая пещера, где этот тип жеоды становится «родным».
		local cave = #Config.MineTiers
		for candidate = 1, #Config.MineTiers do
			if Config.GeodeTypeIndexForCave(candidate) >= index then
				cave = candidate
				break
			end
		end
		local base = Config.CartValue(cave, Config.NaturalCartTierForCave(cave))
		info.Money = {}
		for slot, carts in Config.Geodes.MoneyInCarts do
			info.Money[slot] = niceMoney(base * carts)
		end
	end
end

-- 9-тировые шкалы (валуны, гоблины = тир кирки/тележки) → пещера 1..15.
function Config.CaveForNineTier(tier)
	tier = math.clamp(math.floor(tonumber(tier) or 1), 1, 9)
	return math.clamp(1 + math.floor((tier - 1) * (#Config.MineTiers - 1) / 8 + 0.5), 1, #Config.MineTiers)
end
-- Обратное: пещера → 9-тировая шкала (для гоблинов).
function Config.NineTierForCave(cave)
	cave = math.clamp(math.floor(tonumber(cave) or 1), 1, #Config.MineTiers)
	return math.clamp(1 + math.floor((cave - 1) * 8 / (#Config.MineTiers - 1) + 0.5), 1, 9)
end

-- v20: 0.6 → 0.25 — валуны давали за 10–15 сек больше, чем рейс в шахту.
Config.Boulders.MoneyInCarts = 0.25
-- v20: потолок одного ролла денег — доля полной тележки ТЕКУЩЕЙ пещеры
-- игрока. Не даёт фармить валуны намного выше своей пещеры (кирка дешевле
-- шахты). На «своих» тирах потолок почти не срабатывает.
Config.Boulders.MoneyCapInCarts = 0.5
Config.Boulders.RewardMoneyByTier = {}
for tier = 1, 9 do
	-- 9 тиров валунов (= тир кирки) растянуты на 15 пещер.
	local cave = math.clamp(1 + math.floor((tier - 1) * (#Config.MineTiers - 1) / 8 + 0.5), 1, #Config.MineTiers)
	Config.Boulders.RewardMoneyByTier[tier] = niceMoney(Config.CartValue(cave, Config.NaturalCartTierForCave(cave)) * Config.Boulders.MoneyInCarts)
end

--------------------------------------------------------------------------------
-- ЭКОНОМИКА v4: ПАССИВКА P1 — у каждого кристалла СВОЙ фиксированный доход.
--
-- Доход кристалла больше не зависит от тиров игрока. Он считается один раз
-- здесь от «родной» пещеры кристалла (где его жеода/валун становится
-- обычной находкой):
--   $/мин = Share × Config.IncomePerMinute(родная пещера, её тележка)
--           × Config.Economy.RealIncomeFactor
-- Share: руды жеоды 1/2/3 = GeodeShares, руды валунов = BoulderShare.
-- Сверху OreIncome.PerMinute домножает уровень ячейки, мутацию, перк
-- Safe Income и пасс 2x Safe Income. Сейф копит максимум
-- SafeCapTargetHours (3 ч).
--------------------------------------------------------------------------------
Config.Economy.RealIncomeFactor = 0.75 -- реальный игрок ≈ 75% идеального дохода (не каждая тележка на x3)
Config.Geodes.GeodeShares = { 0.16, 0.24, 0.34 }
Config.Geodes.CrystalWorldScale = 0.5 -- v20.121: кристаллы дохода в мире (подиум, в руках, на земле) - 50% модели
Config.Geodes.BoulderShare = 0.40
Config.Geodes.BoulderOreOrder = { "Rubblegem", "Ironflake", "Coalheart", "Duskstone", "VerdantCore", "Emberite", "Frostvein", "Wyrmglass", "UmbralShard", "Titanheart" }

-- v20.121: пассивка была почти незаметна - общий множитель дохода кристаллов
-- (1 = как в v4). Влияет на $/мин всех кристаллов на подиуме и в сейфе.
Config.Economy.PassiveIncomeBoost = 3
local function passiveBase(cave, share)
	local value = share * Config.IncomePerMinute(cave, Config.NaturalCartTierForCave(cave)) * Config.Economy.RealIncomeFactor
		* (Config.Economy.PassiveIncomeBoost or 1)
	return niceMoney(value)
end
for index, geodeType in Config.Geodes.Order do
	local info = Config.Geodes.Types[geodeType]
	if info then
		local cave = #Config.MineTiers
		for candidate = 1, #Config.MineTiers do
			if Config.GeodeTypeIndexForCave(candidate) >= index then
				cave = candidate
				break
			end
		end
		for slot, oreId in info.Ores or {} do
			local ore = Config.Geodes.Ores[oreId]
			if ore then
				ore.HomeCave = cave
				ore.BaseIncomePerMinute = passiveBase(cave, Config.Geodes.GeodeShares[math.clamp(slot, 1, #Config.Geodes.GeodeShares)])
				ore.IncomePerMinute = ore.BaseIncomePerMinute
			end
		end
	end
end
for index, oreId in Config.Geodes.BoulderOreOrder do
	local ore = Config.Geodes.Ores[oreId]
	if ore then
		local cave = math.clamp(1 + math.floor((index - 1) * (#Config.MineTiers - 1) / (#Config.Geodes.BoulderOreOrder - 1) + 0.5), 1, #Config.MineTiers)
		ore.HomeCave = cave
		ore.BaseIncomePerMinute = passiveBase(cave, Config.Geodes.BoulderShare)
		ore.IncomePerMinute = ore.BaseIncomePerMinute
	end
end

-- ВОСКЛИЦАТЕЛЬНЫЙ ЗНАК НАД ЦЕЛЬЮ АКТИВНОГО КВЕСТА (см. QuestMarker.client.lua).
-- Строится из партов через PlaceholderFactory.QuestMarker() — как и всё
-- остальное в проекте, заменяется своей моделью: положи Model с именем
-- "QuestMarker" в ReplicatedStorage/Assets, и код возьмёт её вместо
-- плейсхолдера.
--
-- Знак показывается ТОЛЬКО у квестов, у которых есть конкретный объект в
-- мире (см. таблицу Targets ниже). У счётных квестов вроде "заработай 100K"
-- или "продай пять тележек" никакой одной точки на карте нет, и знак для них
-- намеренно не рисуется — маркер должен что-то значить, а не висеть всегда.
Config.QuestMarker = {
	Enabled = true,
	-- v20.93: у первых N сюжетных квестов после туториала путь к цели
	-- (стрелка, луч, знак) включён сразу; клик по квесту прячет. Дальше -
	-- только по клику.
	AutoNavStoryQuests = 2,
	Height = 5.5,            -- на сколько студов знак висит над целью
	BobAmplitude = 0.35,     -- амплитуда покачивания вверх-вниз, студы
	BobPeriod = 2.6,         -- период покачивания, секунды
	SpinPeriod = 6.0,        -- полный оборот вокруг своей оси, секунды
	Color = Color3.fromRGB(255, 215, 90),
	MaxVisibleDistance = 2000,
	RefreshInterval = 1.0,    -- как часто перепроверяем цель в мире
	-- v16: НАВИГАЦИЯ (client/QuestMarker.client.lua): трейл от ног до цели
	-- (тот же луч, что в обучении — Config.Tutorial.Trail*), знак над
	-- целью, расстояние, шеврон у ног, стрелка на краю экрана, если цель вне
	-- кадра. Ближе ArriveDistance — трейл прячется.
	TrailEnabled = true,
	ArriveDistance = 12,
	-- Цель по метрике — для дейликов и story-квестов без поля Nav.
	MetricTargets = {
		CartSales = "Bank", OreSold = "Bank", Cart70Sales = "Bank", X4Sales = "Bank", FullCartNoLoss = "Bank",
		BouldersBroken = "Boulder", GeodesOpened = "GeodeVault", OresCollected = "Mine", RareOres = "Mine",
		SafeCollected = "GeodeSafe", Upgrades = "UpgradeShopNPC", ChestsOpened = "PlotBase", ItemsPlaced = "PlotBase",
		MerchantBuys = "Merchant", Damage = "NearestPlayer", OreStolen = "NearestPlayer", CombatHits = "NearestPlayer",
		CrystalsGifted = "NearestPlayer", IslandsOwned = "IslandKeeper", PerksBought = "PrestigeCase", Rebirths = "RebirthNPC",
	},
	-- «Зачем» для дейликов по метрике (story-квесты берут своё поле Why).
	MetricWhy = {
		CartSales = "Sell at the bank.", OreSold = "Sell at the bank.", Cart70Sales = "Fill the cart to 70%+, then sell.",
		X4Sales = "A full cart sells at x3.", BouldersBroken = "Boulders glow around the map.", GeodesOpened = "Open geodes at your geode building.",
		OresCollected = "Mine ore in your cave.", RareOres = "Rare ore comes from your cave.", Upgrades = "Talk to the Experienced Miner.",
		ChestsOpened = "Place a chest on your base.", MerchantBuys = "The merchant stands at the bank.", PlayTime = "Just keep playing!",
		Jumps = "Jump anywhere!", DynamiteUsed = "Buy dynamite from the Experienced Miner.",
		Damage = "Hit other players.", OreStolen = "Knock ore out of enemy carts.", CombatHits = "Hit players or carts.",
	},
}

Config.Skins = {
	GrantRandomStarterSkin = false,
	-- Категории, доступные игрокам прямо сейчас. Выключенные скины остаются
	-- в Definitions и сохранениях, но не выпадают, не выдаются и не экипируются.
	EnabledKinds = { Pickaxe = true, Cart = false, Ore = false },
	-- Один ключ на КАЖДЫЙ тип жеоды (см. Config.Geodes.Types) — шанс, что
	-- открытие жеоды этого типа выдаст скин вместо руды/денег/пыли.
	DropChance = {
		Stone = 0.05, Crystal = 0.05, Amber = 0.05, Topaz = 0.05,
		Jade = 0.05, Onyx = 0.05, Aurora = 0.05, Nebula = 0.05,
		-- Раньше стояло 0 (заглушка: своих скинов ещё не было) — теперь
		-- Quasar/Singularity выдают GoldSword/GoldKunai (см. Config.Skins.
		-- Definitions ниже). В комментарии-заготовке фигурировали 0.16/0.18,
		-- но по факту выставлены те же 0.05, что и у всех остальных типов —
		-- единая шкала. Комментарий приведён в соответствие с числами.
		Quasar = 0.05, Singularity = 0.05,
	},
	DeveloperTestGrants = {
		-- Geodes — словарь [geodeType] = сколько жеод выдать; поддерживает
		-- ЛЮБОЙ тип из Config.Geodes.Types, не только Stone/Crystal.
		-- Версия поднята с 1 → 2: между версиями большинство скинов
		-- переименовали (Ember/Frost/Toxic/Amber/Topaz/Jade/Onyx/Aurora/
		-- Nebula Pickaxe → BigWooden/Love/Radioactive/Amethyst/CactusSword/
		-- FishSkin/TungTungStick/BigMole/DevSword). Игрок, уже отметившийся
		-- версией 1 ДО переименования, не получил новые ключи — выдача идёт
		-- по ТЕКУЩЕМУ Config.Skins.Definitions, так что поднятие Version
		-- заново раздаёт ВСЕ актуальные скины (старые owned-записи с
		-- отсутствующими ключами просто безвредно игнорируются).
		raneniya = { Version = 3, Geodes = {} },
	},
	Definitions = {
		-- v10: ТУРБО-КИРКА — скин геймпасса Rocket Pickaxe (Config.RocketPickaxe).
		-- Надел — любой удар по игроку запуляет его в рагдолл, но копает она
		-- плохо. Из жеод не выпадает (нет поля Geodes). Пока нет ассета
		-- Skin_Pickaxe_Turbo, надевается обычная модель (AllowPlaceholder).
		TurboPickaxe = { Kind = "Pickaxe", DisplayName = "Turbo Pickaxe", Rarity = "Legendary", AssetName = "Skin_Pickaxe_Turbo", ImageId = 0, AllowPlaceholder = true, GamePass = "RocketPickaxe" },
		-- Stone / Crystal — базовые кирки, попроще
		BigWoodenPickaxe = { Kind = "Pickaxe", DisplayName = "Big Wooden Pickaxe", Rarity = "Rare", AssetName = "Skin_Pickaxe_BigWooden", ImageId = 121805710908648, Geodes = { Stone = true, Crystal = true } },
		CrystalPickaxe = { Kind = "Pickaxe", DisplayName = "Crystal Pickaxe", Rarity = "Epic", AssetName = "Skin_Pickaxe_Crystal", ImageId = 128296786196999, Geodes = { Crystal = true } },
		LovePickaxe = { Kind = "Pickaxe", DisplayName = "Love Pickaxe", Rarity = "Rare", AssetName = "Skin_Pickaxe_Love", ImageId = 115736148291739, Geodes = { Stone = true, Crystal = true } },
		RadioactivePickaxe = { Kind = "Pickaxe", DisplayName = "Radioactive Pickaxe", Rarity = "Uncommon", AssetName = "Skin_Pickaxe_Radioactive", ImageId = 132744755925965, Geodes = { Stone = true } },
		VoidPickaxe = { Kind = "Pickaxe", DisplayName = "Void Pickaxe", Rarity = "Legendary", AssetName = "Skin_Pickaxe_VoidFixed", ImageId = 109352130871100, Geodes = { Crystal = true } },
		-- Cart-скины НЕ выбиваются из жеод на данный момент (см. пояснение
		-- ниже про EnabledKinds.Cart) — поле Geodes НАРОЧНО убрано у всех
		-- Cart-скинов, а не оставлено "выключенным только флагом": так они
		-- гарантированно не попадут в пул дропа, даже если кто-то потом
		-- включит EnabledKinds.Cart ради магазина/другого источника. Чтобы
		-- вернуть тележку в дроп нужного типа жеоды — верни ей обратно
		-- Geodes = { ... } с нужными типами.
		MinerCart = { Kind = "Cart", DisplayName = "Miner Cart", Rarity = "Rare", AssetName = "Skin_Cart_Miner", ImageId = 0 },
		RoyalCart = { Kind = "Cart", DisplayName = "Royal Cart", Rarity = "Legendary", AssetName = "Skin_Cart_Royal", ImageId = 0 },
		IndustrialCart = { Kind = "Cart", DisplayName = "Industrial Cart", Rarity = "Uncommon", AssetName = "Skin_Cart_Industrial", ImageId = 0 },
		FrostCart = { Kind = "Cart", DisplayName = "Frost Cart", Rarity = "Epic", AssetName = "Skin_Cart_Frost", ImageId = 0 },
		ObsidianCart = { Kind = "Cart", DisplayName = "Obsidian Cart", Rarity = "Epic", AssetName = "Skin_Cart_Obsidian", ImageId = 0 },

		-- Amber geode — последняя из "простых" кирок, выбивается ТОЛЬКО из
		-- Amber (Amber Cart временно не в дропе, см. пояснение выше)
		AmethystPickaxe = { Kind = "Pickaxe", DisplayName = "Amethyst Pickaxe", Rarity = "Uncommon", AssetName = "Skin_Pickaxe_Amethyst", ImageId = 76941906947734, Geodes = { Amber = true } },
		AmberCart = { Kind = "Cart", DisplayName = "Amber Cart", Rarity = "Uncommon", AssetName = "Skin_Cart_Amber", ImageId = 0 },

		-- Topaz geode — отсюда и выше идут 5 особых предметов (Topaz → Nebula
		-- по возрастанию редкости: Rare → Rare → Epic → Epic → Mythic),
		-- т.е. именно "почти самые редкие" находки в игре
		CactusSword = { Kind = "Pickaxe", DisplayName = "Cactus Pickaxe", Rarity = "Rare", AssetName = "Skin_Pickaxe_CactusSword", ImageId = 125983395178047, Geodes = { Topaz = true } },
		TopazCart = { Kind = "Cart", DisplayName = "Topaz Cart", Rarity = "Rare", AssetName = "Skin_Cart_Topaz", ImageId = 0 },

		-- Jade geode
		FishSkin = { Kind = "Pickaxe", DisplayName = "Fish", Rarity = "Rare", AssetName = "Skin_Pickaxe_Fish", ImageId = 138909766473481, Geodes = { Jade = true } },
		JadeCart = { Kind = "Cart", DisplayName = "Jade Cart", Rarity = "Rare", AssetName = "Skin_Cart_Jade", ImageId = 0 },

		-- Onyx geode
		TungTungStick = { Kind = "Pickaxe", DisplayName = "TUNG TUNG STICK", Rarity = "Epic", AssetName = "Skin_Pickaxe_TungTungStick", ImageId = 115880001946513, Geodes = { Onyx = true } },
		OnyxCart = { Kind = "Cart", DisplayName = "Onyx Cart", Rarity = "Epic", AssetName = "Skin_Cart_Onyx", ImageId = 0 },

		-- Aurora geode
		BigMole = { Kind = "Pickaxe", DisplayName = "BIG MOLE", Rarity = "Epic", AssetName = "Skin_Pickaxe_BigMole", ImageId = 96146522945116, Geodes = { Aurora = true } },
		AuroraCart = { Kind = "Cart", DisplayName = "Aurora Cart", Rarity = "Epic", AssetName = "Skin_Cart_Aurora", ImageId = 0 },

		-- Nebula geode — топовый тир, мифическая редкость: самый редкий
		-- скин в игре на данный момент
		DevSword = { Kind = "Pickaxe", DisplayName = "Developer Pickaxe", Rarity = "Mythic", AssetName = "Skin_Pickaxe_DevSword", ImageId = 117000062306052, Geodes = { Nebula = true } },
		Frostmorn = { Kind = "Pickaxe", DisplayName = "Frostmorn", Rarity = "Mythic", AssetName = "Skin_Frostmorn", ImageId = 74383462032767, NpcExclusive = true },
		Gold = { Kind = "Pickaxe", DisplayName = "GOLD", Rarity = "Legendary", AssetName = "Skin_GOLD", ImageId = 79280932428022, NpcExclusive = true },
		-- Награда за Favorite+лайк игры (см. Config.LikeReward/LikeRewardService) —
		-- НЕ выпадает из жеод (нет поля Geodes, как и у Frostmorn/Gold выше),
		-- выдаётся только прямым GrantNpcSkin, поэтому NpcExclusive = true.
		LikePickaxe = { Kind = "Pickaxe", DisplayName = "Supporter Pickaxe", Rarity = "Epic", AssetName = "Skin_Pickaxe_Like", ImageId = 0, NpcExclusive = true },
		-- Заменил LikePickaxe в качестве реальной награды за Favorite+лайк
		-- (см. Config.LikeReward.SkinId ниже) — по прямому запросу. Та же
		-- механика "тир кирки под видом другого оружия", что и у DevSword
		-- выше (сама механика пикания/добычи не меняется — это чисто
		-- скин на инструмент).
		VoidPickaxe = { Kind = "Pickaxe", DisplayName = "Void Pickaxe", Rarity = "Legendary", AssetName = "Skin_Pickaxe_VoidFixed", ImageId = 109352130871100, NpcExclusive = true },
		-- Награда за лайк+вступление в группу (см. Config.GroupReward/
		-- GroupRewardService) — тоже НЕ выпадает из жеод, только прямым
		-- GrantNpcSkin.
		GroupPickaxe = { Kind = "Pickaxe", DisplayName = "Group Member Pickaxe", Rarity = "Epic", AssetName = "Skin_Pickaxe_Group", ImageId = 0, NpcExclusive = true },
		NebulaCart = { Kind = "Cart", DisplayName = "Nebula Cart", Rarity = "Mythic", AssetName = "Skin_Cart_Nebula", ImageId = 0 },

		-- Quasar/Singularity (тиры 9-10) до этого не имели своих скинов —
		-- см. Config.Skins.DropChance выше, там же комментарий про то, что
		-- их DropChance держали на 0 именно ДО того, как появятся эти два
		-- определения.
		GoldSword = { Kind = "Pickaxe", DisplayName = "Gold Pickaxe", Rarity = "Legendary", AssetName = "Skin_Pickaxe_GoldSword", ImageId = 75847632645464, Geodes = { Quasar = true } },
		GoldKunai = { Kind = "Pickaxe", DisplayName = "Gold Shuriken", Rarity = "Legendary", AssetName = "Skin_Pickaxe_GoldKunai", ImageId = 82992142504153, Geodes = { Singularity = true } },
	},
}

--------------------------------------------------------------------------------
-- НАГРАДА ЗА FAVORITE + ЛАЙК ИГРЫ (см. src/server/Services/LikeRewardService.lua +
-- src/client/LikeRewardUI.client.lua) — окно с подарком, который "открывается"
-- на экране и предлагает добавить игру в избранное И лайкнуть её за скин +
-- жеоды. Независимо от Config.GroupReward ниже (своя награда, свой скин,
-- своя жеода, свой флаг "забрано" — DataService.LikeRewardClaimed).
--
-- ВАЖНО: у Roblox нет API, чтобы скрипт проверил, лайкнул ли игрок игру, или
-- программно открыл меню лайка — это ограничение платформы, не баг. Кнопка
-- Favorite настоящая (AvatarEditorService:PromptSetFavorite), а Like —
-- визуальное подтверждение "по доверию" (жмёт 👍 в самом окне, потом жмёт
-- "CLAIM"). Так делает подавляющее большинство игр с такой механикой на
-- Roblox — альтернативы через официальный API нет.
--------------------------------------------------------------------------------
-- v16: ТАБЛО ЦЕЛЕЙ ПО ЛАЙКАМ (server/Services/LikeGoalService.lua).
-- Число лайков игра прочитать не может (у Roblox нет такого API для
-- скриптов) — CurrentLikes обновляешь сам и публикуешь игру. Табло стоит
-- у спавна: Workspace/LikeGoalBoard (Part — на его лицевую сторону Front
-- кладётся SurfaceGui). Нет детали — табло ставится рядом с SpawnLocation.
--   Kind = "Code"  — на табло открывается промокод (Config.PromoCodes);
--   Kind = "Event" — ивент для всех: Money (×Multiplier к продаже) или
--                    Luck (как пасс 2x Luck). EndsAt = "YYYY-MM-DD" (UTC)
--                    или nil — пока не выключишь.
Config.LikeGoals = {
	Enabled = true,
	CurrentLikes = 6, -- v20.122: пример (6 из 100); впиши реальное число и опубликуй
	Title = "👍 LIKE GOALS",
	Subtitle = "Like the game to unlock rewards for EVERYONE!",
	Goals = {
		{ Likes = 100, Kind = "Code",  Code = "LIKES100", Text = "Secret code: free Rare Chest" },
		{ Likes = 250, Kind = "Event", Event = "Money", Multiplier = 2, Text = "x2 MONEY event", EndsAt = nil },
		{ Likes = 500, Kind = "Event", Event = "Luck", Multiplier = 2, Text = "x2 LUCK event", EndsAt = nil },
		{ Likes = 1000, Kind = "Text", Text = "New cave update!" },
	},
}

-- v16: МЯГКИЕ ПРЕДЛОЖЕНИЯ (server/Services/SocialOfferService.lua). Окна
-- группы и избранного больше не всплывают по таймеру — только в удачный
-- момент (продал тележку, нашёл редкое, престиж, открыл сундук), не чаще
-- одного раза за сессию каждое и с паузой между ними.
Config.SocialOffers = {
	Enabled = true,
	MinSessionSeconds = 180,     -- в первые минуты ничего не предлагаем
	GapSeconds = 600,            -- пауза между двумя любыми предложениями
	-- v20.14: окно всплывает НЕ сразу после удачи (иначе перекрывает сам
	-- момент — открытие сундука, продажу, престиж), а через случайные
	-- DelayMin..DelayMax секунд. Новая удача за это время отодвигает показ
	-- ещё на DelayMin; если игрок занят (шахта, волна гоблинов, рагдолл,
	-- обучение) — ждём, пока освободится, но не дольше MaxWaitSeconds.
	DelayMin = 20,
	DelayMax = 30,
	MaxWaitSeconds = 180,
	HappyMetrics = { CartSales = true, Rebirths = true, RareOres = true, ChestsOpened = true },
	Order = { "Group", "Favorite" },
	-- Кнопка 🎁 в HUD (client/SocialHud): видна, пока есть незабранное.
	HudPosition = UDim2.new(0, 12, 0.36, 0),
}

Config.LikeReward = {
	Enabled = true,
	SkinId = "VoidPickaxe",
	GeodeType = "Crystal",
	GeodeCount = 3,
	-- Через сколько секунд после входа в игру ВПЕРВЫЕ показать окно (если
	-- награда ещё не забрана). Было 150 — по фидбеку хотим раньше.
	FirstShowDelay = 60,
	-- Если игрок закрыл окно крестиком (не забрал) — через сколько секунд
	-- напомнить ещё раз, В ТЕЧЕНИЕ ТОЙ ЖЕ сессии (не более
	-- MaxShowsPerSession раз, дальше не докучаем до следующего захода).
	-- Было 600 (10 мин) — по фидбеку хотим чаще.
	RepeatDelay = 240,
	MaxShowsPerSession = 5,
	Title = "FREE FAVORITE REWARD",
	-- v16: награда выдаётся только ПОСЛЕ настоящего добавления в избранное
	-- (AvatarEditorService.PromptSetFavoriteCompleted = Success или
	-- GetFavorite = true). Проверка клиентская — у сервера API нет.
	Body = "Add the game to your favorites to unlock this reward.",

	--------------------------------------------------------------------------
	-- ВНЕШНИЙ ВИД ОКНА. Всё, что раньше было зашито ЛИБО в билдере
	-- (tools/BuildAllUI.lua), ЛИБО прямо в клиентском скрипте,
	-- теперь живёт здесь. Менять можно, не открывая ни один .lua:
	-- поправил значение → перезапустил tools/BuildAllUI.lua в
	-- Command Bar → окно пересобралось.
	--
	-- ПОЧЕМУ ЭТО ВАЖНО. Тексты кнопки и подписи клиент РАНЬШЕ переписывал
	-- у себя при каждом запуске (favoriteButton.Text = "FAVORITE THE GAME"
	-- жёстко в коде) — то есть правка в билдере или в Studio молча
	-- затиралась при первом же заходе в игру, и понять почему было
	-- невозможно. Теперь и билдер, и клиент читают ОДНО И ТО ЖЕ отсюда.
	Ui = {
		ScreenGuiName = "LikeRewardUi", -- имя ScreenGui; менять не надо, клиент ищет по нему
		DisplayOrder = 40,

		-- Имя кнопки действия — ЧАСТЬ КОНТРАКТА: клиентский скрипт ищет её
		-- именно по этому имени и вешает на неё AvatarEditorService.
		-- Переименуешь — кнопка перестанет работать. Текст на ней меняй
		-- строкой ниже.
		ActionButtonName = "FavoriteButton",
		ActionButtonText = "FAVORITE THE GAME",
		NoteText = "LIKE THE GAME TO SUPPORT US",

		-- Цвета. Подарок и его половинки — розовые у этого окна и синие у
		-- группового, чтобы два окна не путались между собой.
		GiftColor = Color3.fromRGB(210, 60, 90),
		GiftHalfColor = Color3.fromRGB(180, 45, 75),
		HeaderColor = Color3.fromRGB(60, 110, 200),
		-- Как растягивать картинку шапки (Images.Header). Работает, только
		-- если картинка задана. Подробности — у Images.Header.
		HeaderScaleType = "Stretch",
		-- Цвет текста заголовка. Отдельно от HeaderColor: если положишь в
		-- шапку светлый нарисованный баннер, белый заголовок на нём
		-- пропадёт.
		TitleColor = Color3.new(1, 1, 1),
		-- Границы 9-slice в пикселях ИСХОДНОЙ картинки: сколько не тянуть
		-- слева/сверху/справа/снизу. Нужно только при HeaderScaleType =
		-- "Slice"; подбирается под конкретный баннер.
		HeaderSliceCenter = Rect.new(24, 24, 24, 24),
		ActionColor = Color3.fromRGB(255, 190, 60),
		ActionTextColor = Color3.fromRGB(40, 30, 10),
		CloseColor = Color3.fromRGB(220, 70, 70),
		PanelColor = Color3.fromRGB(35, 33, 42),
		SurfaceColor = Color3.fromRGB(45, 43, 55),
		TileColor = Color3.fromRGB(55, 52, 68),
		StrokeColor = Color3.fromRGB(20, 20, 25),
		BodyTextColor = Color3.fromRGB(225, 225, 230),
		NoteTextColor = Color3.fromRGB(140, 195, 255),

		-- Размеры карточки в пикселях. Клиент сам ужимает её под экран
		-- телефона (UIScale), эти числа — «идеальный» размер на десктопе.
		CardWidth = 400,
		CardHeight = 370,
		-- Размер закрытого подарка (та коробка, что падает сверху перед
		-- раскрытием). Читают И билдер, И клиент — раньше 170 было зашито
		-- числом в обоих местах по отдельности.
		GiftSize = 170,
		Font = Enum.Font.FredokaOne,
	},
	-- Все картинки — плейсхолдеры (0 = ничего не покажется, просто пусто/
	-- цветной фон вместо картинки). Впиши свои rbxassetid.
	Images = {
		GiftClosed = 83027693105912,
		GiftHalfLeft = 120664802592458,
		GiftHalfRight = 131301559837969,
		CardBackground = 0, -- фон карточки-приза (после раскрытия)
		-- ШАПКА КАРТОЧКИ. Теперь это ImageLabel, а не сплошная заливка —
		-- сюда можно положить нарисованный баннер с рамкой/узором.
		-- 0 = картинки нет, тогда шапка просто закрашивается цветом
		-- Ui.HeaderColor, как раньше.
		--
		-- Как картинка тянется — Ui.HeaderScaleType (см. блок Ui):
		--   "Stretch" (по умолчанию) — растянуть на всю шапку. Подходит
		--       для сплошного градиента или узора без чётких углов.
		--   "Slice" — 9-slice: углы не тянутся, тянется только середина.
		--       Правильный вариант для баннера с рамкой, чтобы уголки не
		--       расплывались. Границы задаются в Ui.HeaderSliceCenter.
		--   "Fit" — вписать целиком, сохранив пропорции (по краям
		--       останется пустое место).
		Header = 0,
	},
}

--------------------------------------------------------------------------------
-- ВТОРОЕ ОКНО-ПОДАРОК (см. src/server/Services/GroupRewardService.lua +
-- src/client/GroupRewardUI.client.lua) — та же анимация подарка, что и у
-- Config.LikeReward, но просит ДВА ДРУГИХ действия: лайкнуть игру И
-- вступить в группу (Config.LikeReward выше — про Favorite + лайк), за
-- отдельную независимую награду (свой скин, своя жеода, свой флаг "забрано"
-- — см. DataService.GroupRewardClaimed, никак не связан с LikeRewardClaimed).
-- У Group Join есть настоящий нативный промпт Roblox
-- (GroupService:PromptJoinAsync, появился в декабре 2025), у "лайка" как
-- обычно нет — см. подробный комментарий у Config.LikeReward выше, та же
-- логика тут (кнопка Like — чисто визуальное подтверждение на доверии).
--------------------------------------------------------------------------------
Config.GroupReward = {
	Enabled = true,
	-- v16 (G1): участник группы получает +IncomeBonus к продаже руды, пока
	-- состоит в группе (проверка при входе — GetGroupsAsync, и по кнопке),
	-- плюс РАЗОВЫЙ подарок — сундук ChestRarity. Окно больше не всплывает по
	-- таймеру: его предлагает Config.SocialOffers в удачный момент, либо
	-- игрок сам жмёт 🎁 в HUD. SkinId/Geode* ниже больше не выдаются.
	IncomeBonus = 0.10,
	ChestRarity = "Common",
	-- ОБЯЗАТЕЛЬНО впиши ID своей группы — без этого кнопка "JOIN GROUP" не
	-- будет знать, какую группу предлагать (Group Join не сработает при 0).
	GroupId = 965694896, -- roblox.com/communities/965694896/laurentevich
	SkinId = "DevSword",
	GeodeType = "Topaz", -- отличается от Config.LikeReward.GeodeType (Crystal) — вступление в группу даёт награду получше
	GeodeCount = 3,
	FirstShowDelay = 240, -- показывается через 4 минуты после первого Like/Favorite окна
	RepeatDelay = 300, -- было 900
	MaxShowsPerSession = 5,
	Title = "JOIN THE GROUP",
	Body = "Group members get +10% ore sell price FOREVER - plus a free chest!",

	-- См. подробный комментарий у Config.LikeReward.Ui выше — здесь ровно
	-- те же поля с тем же смыслом, отдельным набором на это окно.
	Ui = {
		ScreenGuiName = "GroupRewardUi",
		DisplayOrder = 40,
		-- ВНИМАНИЕ: имя — часть контракта, клиент вешает на него
		-- GroupService:PromptJoinAsync. Меняй только текст.
		ActionButtonName = "JoinGroupButton",
		ActionButtonText = "JOIN OUR GROUP",
		NoteText = "LIKE THE GAME TO SUPPORT US",
		GiftColor = Color3.fromRGB(60, 140, 210),
		GiftHalfColor = Color3.fromRGB(45, 105, 165),
		HeaderColor = Color3.fromRGB(60, 110, 200),
		-- Как растягивать картинку шапки (Images.Header). Работает, только
		-- если картинка задана. Подробности — у Images.Header.
		HeaderScaleType = "Stretch",
		-- Цвет текста заголовка. Отдельно от HeaderColor: если положишь в
		-- шапку светлый нарисованный баннер, белый заголовок на нём
		-- пропадёт.
		TitleColor = Color3.new(1, 1, 1),
		-- Границы 9-slice в пикселях ИСХОДНОЙ картинки: сколько не тянуть
		-- слева/сверху/справа/снизу. Нужно только при HeaderScaleType =
		-- "Slice"; подбирается под конкретный баннер.
		HeaderSliceCenter = Rect.new(24, 24, 24, 24),
		ActionColor = Color3.fromRGB(255, 190, 60),
		ActionTextColor = Color3.fromRGB(40, 30, 10),
		CloseColor = Color3.fromRGB(220, 70, 70),
		PanelColor = Color3.fromRGB(35, 33, 42),
		SurfaceColor = Color3.fromRGB(45, 43, 55),
		TileColor = Color3.fromRGB(55, 52, 68),
		StrokeColor = Color3.fromRGB(20, 20, 25),
		BodyTextColor = Color3.fromRGB(225, 225, 230),
		NoteTextColor = Color3.fromRGB(140, 195, 255),
		CardWidth = 400,
		CardHeight = 370,
		-- Размер закрытого подарка (та коробка, что падает сверху перед
		-- раскрытием). Читают И билдер, И клиент — раньше 170 было зашито
		-- числом в обоих местах по отдельности.
		GiftSize = 170,
		Font = Enum.Font.FredokaOne,
	},
	Images = {
		GiftClosed = 83027693105912,
		GiftHalfLeft = 120664802592458,
		GiftHalfRight = 131301559837969,
		CardBackground = 0,
		-- См. подробный комментарий у Config.LikeReward.Images.Header выше.
		Header = 0,
	},
}

--------------------------------------------------------------------------------
-- АНИМАЦИИ (плейсхолдеры — замени rbxassetid://0 на свои айдишники)
--------------------------------------------------------------------------------
-- Иконки для кастомного UI (не 3D-модели). Указывай ЧИСЛОМ — просто
-- скопируй ID картинки из Asset Manager/каталога (без "rbxassetid://",
-- код сам соберёт нужную строку). 0 — реального ассета ещё нет, клиент
-- рисует emoji-плейсхолдер вместо него.
Config.Icons = {
	Pickaxe = 0,
	Money = 0,
	Rebirth = 0,
	Protection = 0,
	Settings = 0,
	Shop = 0,
	Robux = 0,
	Hint = 0,
	Owned = 0,
	SliderThumb = 0,
	FlyingCoin = 93607959812195,
}

-- v17: ПРУЖИНКА КАМЕРЫ ПРИ ПРИЗЕМЛЕНИИ (client/LandingCameraBob). После
-- прыжка/падения камера коротко проседает вниз и мягко пружинит обратно
-- (одно небольшое «вверх»). Сила зависит от скорости падения.
Config.CameraLandBob = {
	Enabled = true,
	Stiffness = 200,      -- жёсткость пружины: больше — быстрее
	Damping = 10,         -- v20.105: меньше затухание - заметный отскок обратно
	MinFallSpeed = 12,    -- медленнее этого (ступенька) — не качаем
	FullFallSpeed = 45,   -- скорость, при которой толчок = KickVelocity
	KickVelocity = 20,    -- v20.105: ещё сильнее (было 14, изначально 6.5)
	MaxScale = 2.5,       -- потолок для высоких падений
	-- v20.113: без кивка - камера только отскакивает по вертикали и
	-- возвращается ровно в своё положение, вперёд не наклоняется.
	PitchDegrees = 0,     -- кивок вниз вместе с проседанием (0 = без наклона)
	-- v20.113: ОТСКОК В МОМЕНТ ПРЫЖКА - камера чуть отстаёт вниз и пружиной
	-- догоняет игрока. 0 - только при приземлении.
	JumpKickVelocity = 9,
	MaxOffset = 1.6,      -- потолок проседания/подскока камеры, студы
}

-- v20.96: ПОСТОЯННАЯ СТОЙКА НПС (см. src/shared/NpcIdle.lua). ID кладётся в
-- модель как Animation "IdleAnimation"; играет, если в модели есть Humanoid
-- или AnimationController (твой риг вместо плейсхолдера). 0 - без стойки.
Config.NpcIdleAnimations = {
	MinerNPC = "rbxassetid://135179224993807",        -- шахтёр у шахты
	BankMerchant = "rbxassetid://99114631993170",     -- продавец потайной лавки (Ore Merchant)
	IslandKeeperNPC = "rbxassetid://87008744413457",  -- продавец островов
}

-- v20.96: ТЕКСТУРА СТАДОВ на всех плейсхолдер-предметах (зелья, амулеты,
-- мусор, тотемы, декор, реликвии, сундуки) - src/shared/StudTexture.lua.
-- Вставь ID картинки стада (один стад на тайл). Пока 0 - Texture висят
-- пустые (видны поверхности Studs). Enabled = false - не вешать совсем.
Config.StudTexture = {
	Enabled = true,
	Id = "rbxassetid://0",
	StudsPerTile = 1,      -- размер одного тайла текстуры в стадах
	Transparency = 0,
	Color = Color3.new(1, 1, 1),
	Faces = { "Top", "Front", "Back", "Left", "Right" },
}

Config.Animations = {
	-- Играются один раз за удар (track.Looped = false выставляется в
	-- CombatService:_loadSwingAnimations принудительно — код изнутри
	-- анимации на зацикленность не полагается, даже если в редакторе
	-- анимаций она сохранена как looped).
	PickaxeSwingLeft = "rbxassetid://71858763976123",  -- первый замах
	PickaxeSwingRight = "rbxassetid://121496781019019", -- второй замах (чередуются)
	-- v20.95: удар ПО ВАЛУНУ — каждый раз случайная из этих двух (только они).
	-- Замах по воздуху/игрокам остаётся PickaxeSwingLeft/Right. Вставь свои ID;
	-- пока rbxassetid://0 — по валуну играет обычный замах.
	BoulderSwingA = "rbxassetid://79410872721575",
	BoulderSwingB = "rbxassetid://78842383305802",
	-- Зацикленная поза только для стоящего на месте игрока с киркой в руке.
	-- Вставь сюда свой опубликованный Animation ID.
	PickaxeIdle = "rbxassetid://77072500207426",

	-- Пока тележка в руках — подменяют штатные Idle/Walk (Priority.Action,
	-- перебивают дефолтную анимацию персонажа). Любой ID можно оставить
	-- rbxassetid://0 — просто не будет проигрываться, без ошибок.
	CartIdle = "rbxassetid://82576608657296", -- стоит с тележкой на месте
	CartWalk = "rbxassetid://79439566826611", -- идёт с тележкой

	-- v17: ПЛАВНЫЕ ПЕРЕХОДЫ между анимациями персонажа (секунды смешивания).
	ToolBlend = 0.28,     -- поза с киркой: взял / убрал / пошёл / остановился
	CartBlend = 0.32,     -- тележка: взял / отпустил / стоит ↔ идёт
	PoseBlendIn = 0.22,   -- руки тянутся к руде над головой / к тележке
	PoseBlendOut = 0.25,  -- руки возвращаются в обычную анимацию
}

--------------------------------------------------------------------------------
-- ЗВУКИ (плейсхолдеры — замени rbxassetid://0 на свои айдишники)
--------------------------------------------------------------------------------
Config.Sounds = {
	-- UI: замени rbxassetid://0 на свои звуки. Позиция/громкость UI-кликов
	-- управляются через UiSfx, остальные события используют Sfx.
	UiMenuOpen = { Id = "rbxassetid://113414336923621", Volume = 0.4 },
	UiMenuClose = { Id = "rbxassetid://113414336923621", Volume = 0.5 },
	UiTabSwitch = { Id = "rbxassetid://77904255581959", Volume = 0.45 },   -- клик по вкладке — тот же звук клика
	UiHover = { Id = "rbxassetid://86256838181683", Volume = 0.25 },
	UiConfirm = { Id = "rbxassetid://77904255581959", Volume = 0.6 },      -- клик по кнопке подтверждения
	UiCancel = { Id = "rbxassetid://77904255581959", Volume = 0.45 },      -- клик по кнопке отмены
	UiError = { Id = "rbxassetid://138395954502036", Volume = 0.6 },
	UiSuccess = { Id = "rbxassetid://121730389428662", Volume = 0.7 },
	LikePrompt = { Id = "rbxassetid://113414336923621", Variants = { "rbxassetid://86256838181683" }, Volume = 0.7 },
	GroupPrompt = { Id = "rbxassetid://113414336923621", Variants = { "rbxassetid://86256838181683" }, Volume = 0.7 },

	-- Бой и гоблины.
	GoblinWaveWarning = { Id = "rbxassetid://90282353309968", Volume = 0.8 },
	GoblinSpawn = { Id = "rbxassetid://74123659982422", Volume = 0.65 },
	GoblinAttack = { Id = "rbxassetid://98557786254668", Volume = 0.7 },       -- замах гоблина
	-- Попадание в обе стороны — один и тот же звук: гоблин попал по игроку
	-- (GoblinAttackHit) и игрок попал по гоблину (GoblinHit). Громкости
	-- разные и оставлены как были — удар по игроку слышен заметнее.
	GoblinAttackHit = { Id = "rbxassetid://73452564762296", Volume = 0.75 },
	GoblinHit = { Id = "rbxassetid://73452564762296", Volume = 0.55 },
	GoblinDeath = { Id = "rbxassetid://138395954502036", Volume = 0.75 },
	EliteGoblinSpawn = { Id = "rbxassetid://121730389428662", Volume = 0.9 },
	TutorialGoblinDefeated = { Id = "rbxassetid://121730389428662", Volume = 0.8 },

	-- Сундуки и получение наград.
	ChestSpawn = { Id = "rbxassetid://74123659982422", Volume = 0.7 },
	ChestShake = { Id = "rbxassetid://134325190113114", Volume = 0.55 },
	ChestOpen = { Id = "rbxassetid://134325190113114", Volume = 0.85 },
	-- v16: динамит и сундуки. Пустой Id = звук пропускается (для взрыва тогда
	-- играет встроенный звук Explosion Roblox). Впиши свои rbxassetid://.
	DynamiteThrow = { Id = "", Volume = 0.6 },
	DynamiteFuse = { Id = "", Volume = 0.5 },
	DynamiteTick = { Id = "", Volume = 0.6 },
	DynamiteBoom = { Id = "", Volume = 0.9 },
	DynamiteBigBoom = { Id = "", Volume = 1 },
	RagdollLand = { Id = "", Volume = 0.7 },
	ChestCreak = { Id = "", Volume = 0.6 },
	ChestBurst = { Id = "", Volume = 0.9 },
	LootPop = { Id = "", Volume = 0.5 },
	LootPickup = { Id = "rbxassetid://85783678067324", Volume = 0.6 },
	RewardMoney = { Id = "rbxassetid://129867367137419", Variants = { "rbxassetid://99359825575585", "rbxassetid://91926972747239", "rbxassetid://127362954621863" }, Volume = 0.55 },
	RewardGeode = { Id = "rbxassetid://121730389428662", Volume = 0.65 },
	RewardCrystal = { Id = "rbxassetid://77105663599809", Volume = 0.65 },
	RewardSkin = { Id = "rbxassetid://121730389428662", Volume = 0.8 },
	TutorialComplete = { Id = "rbxassetid://121730389428662", Volume = 0.85 },
	BadgeEarned = { Id = "rbxassetid://113027571064402", Volume = 0.75 },

	-- Тележка.
	CartBlocked = { Id = "rbxassetid://125451614749522", Volume = 0.45 },
	CartDamaged = { Id = "rbxassetid://83234417221359", Volume = 0.6 },
	CartDestroyed = { Id = "rbxassetid://138395954502036", Volume = 0.8 },
	CartBanked = { Id = "rbxassetid://129867367137419", Variants = { "rbxassetid://99359825575585", "rbxassetid://91926972747239", "rbxassetid://127362954621863" }, Volume = 0.55 },

	-- Два звука замаха, старый (89203670652305) убран полностью. Т.к.
	-- SoundVariation.Select исключает предыдущий выбор, при РОВНО двух
	-- вариантах они строго чередуются 1-2-1-2, а не выпадают случайно
	-- (два одинаковых замаха подряд не прозвучат).
	PickaxeSwing = { Id = "rbxassetid://109513133322689", Volume = 0.35 },
	PickaxeHit = { Id = "rbxassetid://83234417221359", Volume = 0.2125 },      -- ещё на 50% тише
	PickaxeHitCart = { Id = "rbxassetid://83234417221359", Volume = 0.2125 },  -- ещё на 50% тише
	BoulderBreak = { Id = "rbxassetid://138395954502036", Volume = 0.85 },
	CrystalSpawn = { Id = "rbxassetid://74123659982422", Volume = 0.7 },      -- руда появилась в шахте (см. MineService)
	-- Руда упала в тележку. Добавлены два НОВЫХ варианта к двум прежним —
	-- итого 4. Звук срабатывает на каждый кристалл, то есть чаще всех
	-- прочих в игре, поэтому вариативность тут важнее всего: чем больше
	-- вариантов, тем позже ухо начинает слышать повтор.
	CrystalDrop = { Id = "rbxassetid://71295475477145", Variants = { "rbxassetid://95224844195651", "rbxassetid://136235506917810", "rbxassetid://82857145273165" }, Volume = 1.35 },
	CrystalKnockout = { Id = "rbxassetid://138395954502036", Volume = 0.8 },    -- кристаллы выбиты из тележки
	CrystalPickup = { Id = "rbxassetid://85783678067324", Volume = 0.5 },      -- подбор кристалла с земли (в тележку ИЛИ в руки)
	CrystalStolenPickup = { Id = "rbxassetid://116727937041471", Volume = 0.55 }, -- подбор чужой руды
	CartSoldOut = { Id = "rbxassetid://129867367137419", Variants = { "rbxassetid://99359825575585", "rbxassetid://91926972747239", "rbxassetid://127362954621863" }, Volume = 0.55 },        -- ВСЯ тележка распродана целиком (см. BankService)
	CartTake = { Id = "rbxassetid://82810688987124", Volume = 0.5 },           -- взял тележку
	CartDrop = { Id = "rbxassetid://82810688987124", Volume = 0.5 },           -- оставил тележку
	CartRoll = { Id = "rbxassetid://97801918937383", Volume = 1.4, RollOffMinDistance = 28, RollOffMaxDistance = 120 }, -- единственный loop, без вариантов
	Upgrade = { Id = "rbxassetid://138395954502036", Volume = 0.8 },            -- апгрейд куплен
	MiningRhythmHit = { Id = 0, Volume = 0.75 },
	-- Мини-игра "рудная жила": свой звук на каждый результат удара и на
	-- появление модификатора. ID — временные (взяты из уже используемых в
	-- игре), замените на свои.
	MineHitPerfect = { Id = "rbxassetid://121730389428662", Volume = 0.7 },
	MineHitGood = { Id = "rbxassetid://83234417221359", Volume = 0.6 },
	MineHitMiss = { Id = "rbxassetid://138395954502036", Volume = 0.35 },
	MineModifierReveal = { Id = "rbxassetid://121730389428662", Volume = 0.5 },                                -- успешный клик по ритм-кнопке во время добычи (см. MineService/Config.MiningRhythm)
	UpgradeFail = { Id = "rbxassetid://85783678067324", Volume = 0.7 },        -- недостаточно денег / угнана
	Rebirth = { Id = "rbxassetid://121730389428662", Volume = 0.6 },            -- ребёрт
	ComboActivate = { Id = "rbxassetid://121730389428662", Volume = 0.8 },      -- комбо-множитель включился (5+ кристаллов)
	-- Клик по любому элементу интерфейса. Variants убраны намеренно: клик
	-- должен звучать ОДИНАКОВО везде, иначе интерфейс воспринимается как
	-- несколько разных. Это же значение используется по умолчанию, когда
	-- UiSfx.play/playUiClick вызывают вообще без имени звука.
	--
	-- На этот же звук переведены UiTabSwitch/UiConfirm/UiCancel/
	-- DialogueChoice: раньше resolveUiSound в CustomCartUI раскидывал клики
	-- по ним ПО ИМЕНИ кнопки (в имени есть "buy" — один звук, "tab" —
	-- другой, "close" — третий), так что клики звучали пятью разными
	-- сэмплами. Маршрутизация убрана, но сами ключи оставлены рабочими на
	-- случай, если их позовут явно.
	UiButtonClick = { Id = "rbxassetid://77904255581959", Volume = 0.5 },
	TutorialStepComplete = { Id = "rbxassetid://86256838181683", Volume = 0.55 }, -- короткий "дзынь" при переходе к следующему шагу гайда (см. showInteractiveTutorial)
	DialogueChoice = { Id = "rbxassetid://77904255581959", Volume = 0.7 },  -- выбор варианта в диалоге NPC — это тоже клик
	DialogueTypewriter = { Id = "rbxassetid://92275904187457", Volume = 0.6 }, -- "голос" NPC — играет ОДИН РАЗ на всю реплику (в начале печати), не на каждую букву
	CoinCollect = { Id = "rbxassetid://129867367137419", Variants = { "rbxassetid://99359825575585", "rbxassetid://91926972747239", "rbxassetid://127362954621863" }, Volume = 0.55 },
	GeodeSpawn = { Id = "rbxassetid://121730389428662", Volume = 0.8 },
	GeodeTap = { Id = "rbxassetid://83851198345146", Variants = { "rbxassetid://85546265323346" }, Volume = 0.55 },
	GeodeDrop = { Id = "rbxassetid://121730389428662", Volume = 0.7 },
	CrystalInstall = { Id = "rbxassetid://77105663599809", Volume = 0.65 },
	CrystalRemove = { Id = "rbxassetid://82810688987124", Volume = 0.55 },
	SafeCollect = { Id = "rbxassetid://129867367137419", Variants = { "rbxassetid://99359825575585", "rbxassetid://91926972747239", "rbxassetid://127362954621863" }, Volume = 0.55 },
	QuestProgress = { Id = "rbxassetid://77105663599809", Volume = 0.35 },
	QuestComplete = { Id = "rbxassetid://121730389428662", Volume = 0.7 },
	DailyRewardReady = { Id = "rbxassetid://77105663599809", Volume = 0.55 },
	DailyRewardClaim = { Id = "rbxassetid://129867367137419", Variants = { "rbxassetid://99359825575585", "rbxassetid://91926972747239", "rbxassetid://127362954621863" }, Volume = 0.55 },
	GeodeReveal = { Id = "rbxassetid://85546265323346", Variants = { "rbxassetid://83851198345146" }, Volume = 0.9 },
	-- ЗВУК ВСПЛЫВАЮЩИХ ОПОВЕЩЕНИЙ (NotifyService:Show -> тост в углу).
	-- Запись НОВАЯ: до этого у оповещений не было звука вообще — тост
	-- просто выезжал молча, и его легко было не заметить. Проигрывается
	-- в CustomCartUI.showToast.
	Notification = { Id = "rbxassetid://115667378545343", Volume = 0.5 },
	Sell = { Id = "rbxassetid://129867367137419", Variants = { "rbxassetid://99359825575585", "rbxassetid://91926972747239", "rbxassetid://127362954621863" }, Volume = 0.55 },              -- продажа одного кристалла
}

--------------------------------------------------------------------------------
-- ПРОДАЖА ТЕЛЕЖКИ ЦЕЛИКОМ — визуал (см. BankService): когда тележка
-- ПОЛНОСТЬЮ распродана (последний кристалл ушёл банку), НАД тележкой
-- появляется вспышка VFX-плейсхолдера ("BankSellVFX" из Assets, заменяется
-- своим без изменения кода).
--------------------------------------------------------------------------------
Config.BankSellVfx = {
	Duration = 2.5,     -- сколько живёт VFX над местом продажи, сек
	HeightOffset = 10,  -- на сколько студ VFX-вспышка приподнята над тележкой
}

--------------------------------------------------------------------------------
-- МОНЕТКИ ПРИ ПРОДАЖЕ (см. BankService:spawnCoinBurst) — настоящие 3D-монетки
-- в мире (а не плоская 2D-анимация по экрану), в стиле Fortnite: выскакивают
-- рядом с игроком в момент оплаты, с лёгким зелёным трейлом, и тут же
-- залетают в игрока.
--------------------------------------------------------------------------------
Config.CoinFx = {
	-- МОНЕТКИ v3 — считаются на КЛИЕНТЕ (client/SellFx.client.lua), сервер
	-- шлёт только "откуда и сколько" (BankService:SpawnCoinBurst).
	-- КВАДРАТНЫЕ золотые плитки: вылетают фонтаном, кувыркаются, отскакивают
	-- от земли, короткая пауза — и магнитом к игроку, со звоном по нарастающей.
	--
	-- ПРОИЗВОДИТЕЛЬНОСТЬ: одна деталь на монету, все монеты двигаются одним
	-- workspace:BulkMoveTo за кадр, пул деталей, потолок MaxActive на экране
	-- и слияние частых россыпей (MergeWindow) — продажа целой тележки больше
	-- не заваливает кадр сотнями деталей.
	CoinColor = Color3.fromRGB(255, 196, 40),  -- читают и другие эффекты (гоблины, валуны)
	CoinSize = Vector3.new(0.7, 0.7, 0.7),     -- v20.104: квадратный кубик со стадами
	MinCoins = 4,
	MaxCoins = 12,
	CoinsPerWeight = 1,       -- +монет за каждое начисление в окне дебаунса (Weight)
	MaxActive = 40,           -- потолок монет на экране одновременно
	MergeWindow = 0.35,       -- россыпи чаще этого сливаются в одну
	LaunchSpeed = { 16, 26 }, -- студ/с вверх
	SideSpeed = { 4, 10 },    -- студ/с вбок
	Gravity = 80,
	Bounce = 0.38,            -- доля вертикальной скорости после удара о землю
	RestTime = { 0.1, 0.3 },
	MagnetAccel = 220,        -- студ/с²
	MagnetMaxSpeed = 95,
	CollectDistance = 2.2,
	SpinSpeed = { 7, 14 },    -- рад/с (кувырок в полёте)
	MaxLifetime = 3.5,
	PoolSize = 48,
	-- Звон подбора: каждая следующая монетка в серии чуть выше по тону.
	PitchStart = 0.95,
	PitchStep = 0.035,
	PitchMax = 1.6,
	ChainResetSeconds = 0.7,
	ChimeMinGap = 0.045,      -- не чаще одного звона за столько секунд
}

-- v14.3: ПОДБОР РУДЫ С ЗЕМЛИ — как у монеток (client/OrePickupFx.client.lua).
-- Сервер засчитывает кусок сразу, клиент рисует: подскок → зависание →
-- магнит в игрока → искры + «дзынь» по нарастающей.
Config.OrePickupFx = {
	LaunchSpeed = { 18, 26 },   -- студ/с вверх (подскок)
	SideSpeed = { 2, 6 },       -- студ/с вбок
	Gravity = 90,
	HangTime = { 0.05, 0.12 },  -- зависание в верхней точке
	MagnetAccel = 240,          -- студ/с²
	MagnetMaxSpeed = 110,
	CollectDistance = 1.8,
	ShrinkDistance = 5,         -- с какого расстояния начинает сжиматься
	MinScale = 0.3,
	SpinSpeed = { 6, 11 },      -- рад/с
	MaxLifetime = 2.5,
	PitchStart = 0.95,
	PitchStep = 0.05,
	PitchMax = 1.6,
	ChainResetSeconds = 0.8,
	ChimeMinGap = 0.05,
}

-- ПОЛЁТ ПРОДАННОЙ РУДЫ В БАНК (client/SellFx.client.lua).
Config.SellFx = {
	PopTime = 0.1,        -- короткий подскок перед полётом
	PopScale = 1.2,
	FlightTime = 0.5,
	ArcHeight = 6,        -- базовая высота дуги
	ArcPerStud = 0.12,    -- + высоты за каждый студ дистанции
	SideJitter = 2.5,     -- боковой разброс дуг, чтобы поток не шёл одной линией
	SpinTurns = 1.25,
	EndScale = 0.3,
	FlashSize = 3.2,      -- вспышка в точке входа в банк
	FlashTime = 0.22,
	-- Счётчик над банком: "+$12.4K" с курсом биржи, копится за продажу.
	CounterHideDelay = 1.6,
	CounterHeight = 3,
}

--------------------------------------------------------------------------------
-- UI / КАСТОМНЫЙ ПРОМПТ
-- Единственное место в проекте, где есть LocalScript (src/client) — только
-- ради кастомного вида промпта "взять тележку" и статичной подсказки
-- "отпустить тележку", чтобы не мигал стандартный ProximityPrompt при ходьбе.
--------------------------------------------------------------------------------
Config.UI = {
	AccentColor = Color3.fromRGB(255, 200, 90),
	BackgroundColor = Color3.fromRGB(25, 25, 32),
	TextColor = Color3.new(1, 1, 1),
	CloseButtonImageId = 0, -- общая картинка для всех кнопок закрытия; 0 = текстовый X
	TutorialMoleImageId = 81174978418012, -- крот-маскот в карточке гайда (тот же, что и на самом экране загрузки)
	PromptKeyImageId = 126258714999257,   -- иконка клавиши E над клавиатурными промптами
	-- НАСТРОЙКИ УБРАНЫ С ЭКРАНА (по прямому запросу): ни шестерёнки
	-- GearButton, ни окна SettingsMenu, ни пункта SETTINGS в книге-меню.
	-- true вернёт всё как было (см. CustomCartUI/CollectionMenu).
	SettingsMenuEnabled = false,
	-- ПРОМПТЫ НА ОБЪЕКТАХ (client/WorldPrompts.client.lua): кружок с
	-- клавишей и подписью действия висит прямо на том, с чем
	-- взаимодействуешь (NPC, тележка, сейф…), а не плашкой на экране.
	-- false — вернуть старую экранную плашку из CustomCartUI.
	WorldPrompts = true,
	-- Единая кнопка-книга (см. CollectionMenu.client.lua), заменившая три
	-- отдельные (магазин/скины/настройки), + иконки её пунктов подменю.
	-- Все 0 — плейсхолдеры, впиши свои rbxassetid.
	CollectionBookImageId = 0,
	InventoryMenuIconId = 0,
	ShopMenuIconId = 0,
	SkinsMenuIconId = 0,
	SettingsMenuIconId = 0,
	MutationsMenuIconId = 0,
}

--------------------------------------------------------------------------------
-- v20.112: HUD СЛЕВА СНИЗУ ОДНОЙ КАРТИНКОЙ (рамка + окно портрета + 2 полоски
-- с монеткой и звездой). Загружаешь ОДНУ картинку → вписываешь ImageId.
-- Поверх неё игра кладёт только живой портрет и два числа. Положение окон
-- задаётся ДОЛЯМИ КАРТИНКИ { X, Y, Ширина, Высота } (0..1 от левого верхнего
-- угла), поэтому при любом размере HUD всё остаётся на месте.
-- Как подогнать: открой картинку в редакторе, посмотри пиксели окна
-- (например, портрет с x=12 до x=104 при ширине 360) и подели на размер
-- картинки (12/360 = 0.033, 92/360 = 0.256).
-- ImageId = 0 - рисуется похожая заглушка из рамок (чтобы было видно, где что).
--------------------------------------------------------------------------------
Config.UI.CinematicHideCoreGui = true -- v20.114: в катсценах (жеода, шахта) прятать и чат/список игроков Roblox

Config.UI.HudImage = {
	Enabled = true,          -- false - старый HUD из пилюль
	ImageId = 0,             -- ← сюда Id картинки HUD целиком
	Size = Vector2.new(330, 110), -- размер HUD на ПК в пикселях (держи пропорции картинки)
	Portrait = { 0.03, 0.09, 0.255, 0.82 }, -- окно портрета (квадратное)
	Money = { 0.445, 0.14, 0.51, 0.3 },     -- куда пишется $ (правее монетки)
	Prestige = { 0.445, 0.56, 0.51, 0.3 },  -- куда пишется престиж (правее звезды)
	-- Невидимые точки иконок (по ним подпрыгивание при получении денег/престижа).
	MoneyIcon = { 0.31, 0.08, 0.13, 0.42 },
	PrestigeIcon = { 0.31, 0.5, 0.13, 0.42 },
	MoneyColor = Color3.fromRGB(255, 226, 90),
	PrestigeColor = Color3.fromRGB(255, 150, 215),
	TextStrokeColor = Color3.fromRGB(40, 20, 10),
	PrestigePrefix = "",     -- например "PRESTIGE " - иначе только число
}

--------------------------------------------------------------------------------
-- МОБИЛЬНАЯ РАСКЛАДКА (см. src/shared/MobileLayoutOverride.lua +
-- tools/BuildMobileLayoutEditor.lua + tools/HarvestMobileLayout.lua) —
-- НЕ редактируй руками. Заполняется автоматически: подвигал плейсхолдеры в
-- Studio → запустил HarvestMobileLayout.lua → скопировал результат из
-- Output сюда. Пусто = все элементы работают как раньше, без изменений.
--------------------------------------------------------------------------------
Config.MobileLayout = {}

--------------------------------------------------------------------------------
-- v20.16: ДВЕ ВЕРСИИ UI — ПК И ТЕЛЕФОН (shared/UiLayout + client/ResponsiveUi).
--
-- Профиль: "Phone" (сенсор без клавиатуры, короткая сторона ≤ PhoneMaxShortSide),
-- "Tablet" (сенсор, экран больше), "Desktop" (всё остальное).
-- ForceProfile = "Phone" — проверить телефонную версию на ПК/в Studio.
--
-- Масштаб: любое окно и любая плашка ВСЕГДА целиком влезают в безопасную зону
-- экрана (с отступом Margin). HUD на телефоне дополнительно мельче —
-- HudScale[профиль] = clamp(короткая сторона / Ref, Min, Max).
-- Своя база для одного элемента: атрибут UiScale_Phone = 0.8 прямо в Studio.
-- Не трогать элемент вообще: атрибут NoAutoFit = true (или Skip ниже).
--
-- Раскладка: Overrides[профиль]["Экран/Элемент/…"] = { свойства } — любые
-- свойства (Position, AnchorPoint, Size, Visible, FillDirection у
-- UIListLayout…). Это и есть «телефонная версия»: правь здесь, код не нужен.
--------------------------------------------------------------------------------
Config.UiLayout = {
	ForceProfile = nil, -- nil = автоопределение; "Phone" / "Tablet" / "Desktop" — принудительно
	PhoneMaxShortSide = 600,
	MinScale = 0.3,
	Margin = { Phone = 6, Tablet = 10, Desktop = 12 },
	HudScale = {
		Phone = { Ref = 540, Min = 0.62, Max = 0.85 },
		Tablet = { Ref = 900, Min = 0.8, Max = 1 },
		Desktop = { Ref = 720, Min = 0.75, Max = 1 },
	},
	WindowMaxScale = { Phone = 1, Tablet = 1, Desktop = 1 },
	-- Экраны/элементы, которые подгоняются сами (своя логика размера).
	Skip = {
		["RevealCards/Holder"] = true,
		-- Ряд кнопок в топбаре Roblox: размер задаёт сам топбар (TopbarInset).
		TopbarDock = true,
	},
	Overrides = {
		Phone = {
			-- Джойстик — левый низ, прыжок — правый низ: там ничего не ставим.
			-- Деньги/престиж (Hud/HudGui) и подсказки тележки/NPC на телефоне
			-- расставляет CustomCartUI — здесь их нет.
			-- v20.87: статусы (баффы, дебаффы, погода, сейв-зона) — ТОЧНО левый
			-- нижний угол; иконки растут от угла вправо и вверх. Тап по иконке —
			-- подсказка над ней (второй тап или через 4 с — скрыть).
			["BuffBar/Bar"] = { AnchorPoint = Vector2.new(0, 1), Position = UDim2.new(0, 6, 1, -6) },
			["BuffBar/Bar/UIGridLayout"] = { StartCorner = Enum.StartCorner.BottomLeft, HorizontalAlignment = Enum.HorizontalAlignment.Left },
			-- Лента добычи — под деньгами, покороче.
			["LootFeedUi/Feed"] = { AnchorPoint = Vector2.new(1, 0), Position = UDim2.new(1, -8, 0, 96), Size = UDim2.fromOffset(300, 300) },
			-- Предложения — над кнопкой прыжка, левее неё.
			["OfferUi/Stack"] = { AnchorPoint = Vector2.new(1, 1), Position = UDim2.new(1, -120, 1, -70) },
			-- Квест — левый верх под кнопками топбара (не в зоне джойстика).
			["QuestUi/QuestTracker"] = { AnchorPoint = Vector2.new(0, 0), Position = UDim2.new(0, 10, 0, 50) },
			["QuestUi/QuestTracker/UIListLayout"] = { VerticalAlignment = Enum.VerticalAlignment.Top },
			-- Снаряжение — ряд над хотбаром вместо колонки слева.
			["GearUi/GearBar"] = { AnchorPoint = Vector2.new(0.5, 1), Position = UDim2.new(0.5, 0, 1, -62), Size = UDim2.fromOffset(330, 64) },
			["GearUi/GearBar/UIListLayout"] = {
				FillDirection = Enum.FillDirection.Horizontal,
				HorizontalAlignment = Enum.HorizontalAlignment.Center,
				VerticalAlignment = Enum.VerticalAlignment.Center,
			},
			-- Подсказка предмета в руке — над рядом снаряжения, полного размера
			-- («@Атрибут» — атрибут: своя база масштаба на телефоне).
			["GearUi/AimHint"] = { Position = UDim2.new(0.5, 0, 1, -118), ["@UiScale_Phone"] = 0.62 },
		},
		Tablet = {},
		Desktop = {},
	},
}

--------------------------------------------------------------------------------
-- ФОНОВАЯ МУЗЫКА — плейлист треков, играются ПО ОЧЕРЕДИ (не вперемешку),
-- один за другим: трек закончился → сразу следующий → дошли до конца
-- списка → снова первый, по кругу до бесконечности, всю игру. Чисто
-- клиентское (см. CustomCartUI.client.lua) — у каждого игрока играет
-- независимо, ничего не реплицируется на сервер и не мешает остальным.
-- Плейсхолдеры ("rbxassetid://0") пропускаются молча — впиши свои ID.
-- Список пустой или все треки — плейсхолдеры → музыка просто не играет,
-- ничего не падает.
--------------------------------------------------------------------------------
Config.Music = {
	Volume = 0.175, -- на 30% тише прежних 0.25
	Tracks = {
		"rbxassetid://100677589656320",
		"rbxassetid://79112966258857",
		"rbxassetid://130124118845579",
		"rbxassetid://107280876785828",
		"rbxassetid://134688009218944",
		"rbxassetid://102165501918668",
		"rbxassetid://89569950994563",
	},
}

--------------------------------------------------------------------------------
-- БИЛЛБОРД НАД ГОЛОВОЙ NPC — высота/размер надписи (name/arrow/dialog у
-- UpgradeShopNPC/ShopNPC, один текст у RebirthNPC). Применяется ТОЛЬКО когда
-- билборд строит САМ КОД — то есть либо используется блочный
-- плейсхолдер целиком, либо твоя своя модель NPC не содержит готового
-- билборда (см. PLACEHOLDERS_GUIDE.md, разделы про UpgradeShopNPC/ShopNPC/
-- RebirthNPC). Как только положишь в свою модель ГОТОВЫЙ билборд ("gui" —
-- BillboardGui с TextLabel "name"/"arrow"/"dialog" у UpgradeShopNPC/ShopNPC,
-- или диалоговый "gui" у RebirthNPC) —
-- эти настройки не участвуют вообще, используется твой билборд один в один
-- (высота/размер задаёшь сам прямо в Studio, мышкой, у своего BillboardGui).
--
-- Height — высота подписи над головой NPC, в studs (BillboardGui.StudsOffset.Y).
-- SizeWidth/SizeHeight — размер самого билборда. У UpgradeShopNPC/ShopNPC
-- это ПИКСЕЛИ (BillboardGui.Size — Offset), у RebirthNPC — STUDS (Scale),
-- так исторически сложилось у каждого из двух билборд-контрактов в игре.
--------------------------------------------------------------------------------
Config.NpcBillboard = {
	UpgradeShopNPC = { Height = 1.55, SizeWidth = 240, SizeHeight = 90 },
	ShopNPC = { Height = 1.55, SizeWidth = 240, SizeHeight = 90 },
	RebirthNPC = { Height = 3, SizeWidth = 4.2, SizeHeight = 1.0 },
	MinerNPC = { Height = 1.55, SizeWidth = 240, SizeHeight = 90 },
}

--------------------------------------------------------------------------------
-- МАГАЗИН ПРОКАЧКИ (NPC) — заменил три отдельных пьедестала: теперь все
-- 3 ветки (Шахта/Тележка/Кирка) покупаются в одном диалоге у одного NPC.
--------------------------------------------------------------------------------
Config.UpgradeShop = {
	TypewriterCharDelay = 0.02, -- сек на символ приветствия (эффект печатной машинки)
	DialogRange = 14,           -- отойдёшь дальше — диалог закроется сам (клиент проверяет сам)

	-- ОТКАТ МЕЖДУ ПОКУПКАМИ ПРОКАЧКИ (по прямому запросу — "добавить мб
	-- какой-то откат по времени секунд 5").
	--
	-- ЗАЧЕМ. Катсцена показа улучшения идёт примерно 2.9-4.4 секунды
	-- (см. playUpgradeRevealCamera в CustomCartUI.client.lua: пролёт
	-- камеры + тряска + схлопывание старой модели + рост новой + возврат
	-- камеры), а старая защита UpgradeInProgress в UpgradeService
	-- отпускала уже через 2 секунды. То есть вторую покупку можно было
	-- всунуть ПРЯМО В СЕРЕДИНУ первой сцены: она прерывалась на полпути,
	-- настоящая модель оставалась локально спрятанной, а временные клоны —
	-- висеть в мире. Именно это выглядело как "при быстрой прокачке модели
	-- багаются" (шахта/тележка пропадает или двоится).
	--
	-- 5 секунд с запасом перекрывают самую длинную сцену. Значение читают
	-- И сервер (UpgradeService — авторитетная проверка), И клиент
	-- (блокировка кнопок с обратным отсчётом), поэтому менять его нужно
	-- только здесь.
	PurchaseCooldownSeconds = 5,

	-- Иконка слева на каждой строке диалога (Mine/Cart/Pickaxe) — плейсхолдер,
	-- 0 = ничего не показываем (просто пустое место слева от текста). Поставь
	-- сюда свои rbxassetid, например картинку кирки для Pickaxe — правишь
	-- только эти три числа, ничего в самом UI искать не нужно.
	Icons = {
		Mine = 0,
		Cart = 0,
		Pickaxe = 0,
	},

	-- НОВЫЙ вид того же диалога — 3 горизонтальные карточки вместо списка
	-- строк (см. tools/BuildAllUI.lua — отдельный билдер, не
	-- трогает старый DialogResponses из tools/BuildAllUI.lua). Пока
	-- ScreenGui "UpgradeShopCards" не собран в StarterGui, клиент тихо
	-- продолжает использовать старый список — ничего переключать вручную
	-- не нужно, сборка нового ассета сама включает карточки.
	Cards = {
		-- Большая картинка-обложка СВЕРХУ каждой карточки — 0 = просто
		-- цветной плейсхолдер с названием ветки поверх (как и остальной UI).
		CoverIcons = {
			Mine = 0,
			Cart = 0,
			Pickaxe = 0,
		},
		-- Короткое статичное описание "что именно даёт" ветка — под
		-- обложкой, НАД строкой тира/цены (ту клиент дорисовывает сам по
		-- статусу с сервера, как и раньше).
		-- RichText-разметка (<font color="#..">) + КАПС на ключевом слове —
		-- см. tools/BuildAllUI.lua (description.RichText = true).
		-- Та же цветовая схема, что и в подсветке квестов (QuestUI.client.
		-- lua/highlightQuestText): голубой — игровой предмет/ресурс,
		-- золотой — сам эффект прокачки, красный — боевая характеристика,
		-- зелёный — денежная ценность.
		-- v9: коротко — детали видны в строках «было → станет».
		Descriptions = {
			Mine = "More <font color=\"#8CFFA0\">LUCK</font>, more ore per dig.", -- v20.109: руду покупают у торговца
			Cart = "Bigger <font color=\"#6FE3FF\">BACKPACK</font>, no slowdown.", -- v20.108: ветка Cart = рюкзак
			Pickaxe = "More <font color=\"#FF7A7A\">DAMAGE</font>, more ore knocked.",
		},
	},
}

--------------------------------------------------------------------------------
-- НПС МАГАЗИНА (Robux-донат) — ОТДЕЛЬНЫЙ NPC от продавца прокачки (тот
-- покупается на игровые деньги за тиры, этот — за Robux, гейпассы/девпродукты).
-- Тот же билборд-контракт "gui" (name/arrow/dialog), что и у UpgradeShopNPC
-- (см. ShopNpcService:SetupPlot/PlaceholderFactory.ShopNPC) — просто своя
-- отдельная приветственная реплика и НЕТ списка из нескольких пунктов
-- ответа: одна кнопка "Open Shop" сразу открывает ScreenGui "ShopUi"
-- (см. CustomCartUI.client.lua).
--------------------------------------------------------------------------------
Config.ShopNpc = {
	TypewriterCharDelay = 0.02,
	DialogRange = 14,
	GreetingText = "Welcome! Take a look at today's deals.",
}

--------------------------------------------------------------------------------
-- МАГАЗИН (ScreenGui "ShopUi", см. tools/BuildAllUI.lua) — окно с
-- вкладками (Config.Shop.Tabs, по умолчанию "Passes"/"Deals") и ПАГИНАЦИЕЙ:
-- на каждой вкладке ScreenGui-строитель заранее строит ровно
-- CardsPerPage (6) карточек-"слотов" — контент каждого слота (картинка/
-- заголовок/цена/бэйдж "NEW") целиком заполняет и меняет КЛИЕНТ на лету
-- (см. renderPage в CustomCartUI.client.lua) при переключении вкладки или
-- странице (Prev/Next) — так пагинация работает при ЛЮБОМ количестве
-- товаров в Items, без пересборки UI.
--
-- Items — карточки магазина. Passes = геймпассы (покупаются один раз,
-- эффект навсегда — см. Config.GamePasses), Deals = разовые покупки
-- (деньги/расходники — см. Config.DevProducts/Config.Protection). ProductId
-- у каждой карточки НЕ дублирует число руками — берётся прямо из
-- Config.GamePasses/Config.DevProducts/Config.Protection ниже по тексту, то
-- есть Id прописываешь ОДИН раз (там, где заведён сам геймпасс/девпродукт),
-- а карточка сама подтягивает актуальное значение. Поля карточки:
--   Title       — надпись на карточке
--   PriceRobux  — цифра на кнопке цены — ЧИСТО ДЕКОРАТИВНЫЙ текст (реальную
--                 цену Roblox покажет сам в системном окне покупки после
--                 клика) — правь на то число Robux, которое реально
--                 поставишь в Creator Dashboard, просто чтобы карточка не
--                 врала игроку до клика.
--   ImageId     — числовой ID картинки (0 = картинки нет, обычный цветной
--                 прямоугольник со знаком "?" вместо неё)
--   ProductType — "GamePass" или "DevProduct" (откуда брать реальный Id)
--   ProductId   — 0, пока сам геймпасс/девпродукт ещё не создан в Creator
--                 Dashboard (см. Config.GamePasses/Config.DevProducts/
--                 Config.Protection выше по файлу — впиши Id ТУДА, сюда
--                 ничего вписывать не нужно, подтянется само). Пока 0 —
--                 клик по карточке просто предупредит в консоли и НИЧЕГО
--                 не купит (безопасно).
--   Badge       — необязательная плашка в углу карточки ("NEW" и т.п.),
--                 nil/"" — плашка скрыта.
--   GrantMoney  — ТОЛЬКО для СВОИХ НОВЫХ карточек с ProductType =
--                 "DevProduct", которых ещё нет ни в Config.DevProducts, ни
--                 в Config.Protection (готовые Money Pack'и/щит ниже в этом
--                 ProductId уже сами знают, что выдавать — см.
--                 MonetizationService:ProcessReceipt, GrantMoney им не
--                 нужен). Добавишь СВОЮ карточку сверх этих десяти — тогда
--                 GrantMoney и пригодится.
--------------------------------------------------------------------------------
-- Подпись денежной карточки магазина СЧИТАЕТСЯ ИЗ САМОЙ СУММЫ, а не пишется
-- руками. Раньше Title был константной строкой ("$250K Cash") рядом с
-- Amount = 250000 в Config.DevProducts — две независимые копии одного числа,
-- которые при любой правке баланса разъезжались, и магазин начинал обещать
-- одну сумму, а выдавать другую. Для платного товара это уже не косметика.
--
-- Отдельная локальная функция, а не NumberFormat.abbreviate: Config не
-- должен ничего требовать (require) — его самого требуют почти все модули
-- проекта, и любая зависимость отсюда рискует замкнуть цикл загрузки.
local function cashLabel(amount)
	amount = tonumber(amount) or 0
	local function trim(value, suffix)
		-- 6.5 → "6.5", 300.0 → "300" (без болтающегося ".0")
		local text = ("%.1f"):format(value)
		text = text:gsub("%.0$", "")
		return "$" .. text .. suffix .. " Cash"
	end
	if amount >= 1e12 then return trim(amount / 1e12, "T") end
	if amount >= 1e9 then return trim(amount / 1e9, "B") end
	if amount >= 1e6 then return trim(amount / 1e6, "M") end
	if amount >= 1e3 then return trim(amount / 1e3, "K") end
	return "$" .. ("%d"):format(amount) .. " Cash"
end

Config.Shop = {
	-- КАТЕГОРИИ МАГАЗИНА (по прямому запросу — "все геймпассы раздели по
	-- категориям, условно продукты, геймпассы"). Порядок здесь = порядок
	-- секций сверху вниз в окне магазина (вкладок нет, всё одной
	-- прокруткой, см. tools/BuildAllUI.lua).
	-- "Deals" СОХРАНЁН как категория: на него ссылаются PreferredTab в
	-- RebirthService/UpgradeService/NotifyService — под ним теперь
	-- остаются разовые предложения (стартовый пак, продление щита).
	-- v20.4: порядок — самые покупаемые сверху (над ними ещё Forever Pack).
	-- Категория без товаров показывается карточками «?» (скоро).
	Tabs = { "Cash", "Boosts", "Support", "Passes", "Weather", "Geodes", "Dynamite", "Deals", "Skins" },

	-- Подпись секции на экране (ключ категории не трогаем — он завязан на
	-- PreferredTab по всей кодовой базе).
	TabDisplayNames = {
		Cash = "Cash",
		Boosts = "Boosts",
		Passes = "Game Passes",
		Weather = "Weather",
		Geodes = "Geodes",
		Dynamite = "Dynamite",
		Deals = "Special Offers",
		Skins = "Skins",
		Support = "SUPPORT US",
	},

	-- ГРАДИЕНТ ФОНА НА КАЖДУЮ СЕКЦИЮ (по прямому запросу — "раскрась
	-- бэкграунд градиентом, у каждой панели разное"). From — верх, To —
	-- низ. Секция рисует полупрозрачную подложку этим градиентом, чтобы
	-- категории читались с первого взгляда, не сливаясь в одну простыню.
	TabGradients = {
		Boosts = { From = Color3.fromRGB(120, 80, 20), To = Color3.fromRGB(40, 28, 14) },   -- золотой: усиления
		Passes = { From = Color3.fromRGB(80, 45, 120), To = Color3.fromRGB(28, 20, 44) },   -- фиолетовый: постоянные геймпассы
		Cash   = { From = Color3.fromRGB(30, 95, 55), To = Color3.fromRGB(16, 34, 24) },    -- зелёный: деньги
		Events = { From = Color3.fromRGB(110, 40, 40), To = Color3.fromRGB(38, 18, 18) },   -- красный: ивенты погоды
		Deals  = { From = Color3.fromRGB(30, 70, 110), To = Color3.fromRGB(16, 28, 42) },   -- синий: разовые предложения
	},

	-- Сколько карточек-слотов строится на КАЖДОЙ вкладке (и, соответственно,
	-- сколько товаров показывается за один "лист"/страницу). Поменял число —
	-- перезапусти tools/BuildAllUI.lua, чтобы пересобрать нужное
	-- количество слотов.
	CardsPerPage = 6,

	Items = {
		-- v20.82: SUPPORT US - донаты (Config.Donations).
		{ Id = "Donate10Deal", Tab = "Support", Title = Config.Donations.Items[1].Title, PriceRobux = 10, ImageId = 0, ProductType = "DevProduct", ProductId = Config.Donations.Items[1].Id, DonationKey = "Donate10", Description = Config.Donations.Items[1].Description },
		{ Id = "Donate50Deal", Tab = "Support", Title = Config.Donations.Items[2].Title, PriceRobux = 50, ImageId = 0, ProductType = "DevProduct", ProductId = Config.Donations.Items[2].Id, DonationKey = "Donate50", Description = Config.Donations.Items[2].Description },
		{ Id = "Donate100Deal", Tab = "Support", Title = Config.Donations.Items[3].Title, PriceRobux = 100, ImageId = 0, ProductType = "DevProduct", ProductId = Config.Donations.Items[3].Id, DonationKey = "Donate100", Description = Config.Donations.Items[3].Description },
		{ Id = "Donate500Deal", Tab = "Support", Title = Config.Donations.Items[4].Title, PriceRobux = 500, ImageId = 0, ProductType = "DevProduct", ProductId = Config.Donations.Items[4].Id, DonationKey = "Donate500", Description = Config.Donations.Items[4].Description },
		{ Id = "Donate1000Deal", Tab = "Support", Title = Config.Donations.Items[5].Title, PriceRobux = 1000, ImageId = 0, ProductType = "DevProduct", ProductId = Config.Donations.Items[5].Id, DonationKey = "Donate1000", Description = Config.Donations.Items[5].Description },
		{ Id = "Donate5000Deal", Tab = "Support", Title = Config.Donations.Items[6].Title, PriceRobux = 5000, ImageId = 0, ProductType = "DevProduct", ProductId = Config.Donations.Items[6].Id, DonationKey = "Donate5000", Description = Config.Donations.Items[6].Description },
		-- ГЕЙМПАССЫ — покупаются один раз, эффект навсегда (см. Config.GamePasses).
		-- v10: ГЕЙМПАССЫ — покупаются один раз (Config.GamePasses).
		{ Id = "DoubleCashPass", Tab = "Passes", Title = "💰 2x Money", PriceRobux = Config.GamePasses.DoubleCash.PriceRobux, ImageId = 0, ProductType = "GamePass", ProductId = Config.GamePasses.DoubleCash.Id, PassKey = "DoubleCash" },
		{ Id = "DoubleLuckPass", Tab = "Passes", Title = "🍀 2x Luck", PriceRobux = Config.GamePasses.DoubleLuck.PriceRobux, ImageId = 0, ProductType = "GamePass", ProductId = Config.GamePasses.DoubleLuck.Id, PassKey = "DoubleLuck" },
		{ Id = "OreMagnetPass", Tab = "Passes", Title = "🧲 Ore Magnet", PriceRobux = Config.GamePasses.OreMagnet.PriceRobux, ImageId = 0, ProductType = "GamePass", ProductId = Config.GamePasses.OreMagnet.Id, PassKey = "OreMagnet" },
		{ Id = "ExtraPouchPass", Tab = "Passes", Title = "🎒 Mega Backpack", PriceRobux = Config.GamePasses.ExtraPouch.PriceRobux, ImageId = 0, ProductType = "GamePass", ProductId = Config.GamePasses.ExtraPouch.Id, PassKey = "ExtraPouch" },
		{ Id = "GeodeMasterPass", Tab = "Passes", Title = "🪨 Geode Master", PriceRobux = Config.GamePasses.GeodeMaster.PriceRobux, ImageId = 0, ProductType = "GamePass", ProductId = Config.GamePasses.GeodeMaster.Id, PassKey = "GeodeMaster" },
		{ Id = "DemolitionExpertPass", Tab = "Passes", Title = "🧨 Demolition Expert", PriceRobux = Config.GamePasses.DemolitionExpert.PriceRobux, ImageId = 0, ProductType = "GamePass", ProductId = Config.GamePasses.DemolitionExpert.Id, PassKey = "DemolitionExpert" },
		{ Id = "CartGuardPass", Tab = "Passes", Title = "🛡 Cart Guard", PriceRobux = Config.GamePasses.CartGuard.PriceRobux, ImageId = 0, ProductType = "GamePass", ProductId = Config.GamePasses.CartGuard.Id, PassKey = "CartGuard" },
		{ Id = "FastSmelterPass", Tab = "Passes", Title = "⚡ Fast Smelter", PriceRobux = Config.GamePasses.FastSmelter.PriceRobux, ImageId = 0, ProductType = "GamePass", ProductId = Config.GamePasses.FastSmelter.Id, PassKey = "FastSmelter" },
		{ Id = "RocketPickaxePass", Tab = "Passes", Title = "🚀 Rocket Pickaxe", PriceRobux = Config.GamePasses.RocketPickaxe.PriceRobux, ImageId = 0, ProductType = "GamePass", ProductId = Config.GamePasses.RocketPickaxe.Id, PassKey = "RocketPickaxe" },
		{ Id = "AutoHammerPass", Tab = "Passes", Title = "🔨 Auto Hammer", PriceRobux = Config.GamePasses.AutoHammer.PriceRobux, ImageId = 0, ProductType = "GamePass", ProductId = Config.GamePasses.AutoHammer.Id, PassKey = "AutoHammer" },
		{ Id = "DoubleSafePass", Tab = "Passes", Title = "🏦 2x Safe Income", PriceRobux = Config.GamePasses.DoubleSafe.PriceRobux, ImageId = 0, ProductType = "GamePass", ProductId = Config.GamePasses.DoubleSafe.Id, PassKey = "DoubleSafe" },
		{ Id = "FillSafeDeal", Tab = "Boosts", Title = Config.DevProducts.Micro.FillSafe.Icon .. " " .. Config.DevProducts.Micro.FillSafe.Title, PriceRobux = Config.DevProducts.Micro.FillSafe.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.Micro.FillSafe.Id, MicroKey = "FillSafe" },
		{ Id = "DoubleDropsPass", Tab = "Passes", Title = "2x Geode Rewards", PriceRobux = Config.GamePasses.DoubleDrops.PriceRobux, ImageId = 0, ProductType = "GamePass", ProductId = Config.GamePasses.DoubleDrops.Id, PassKey = "DoubleDrops" },

		-- v10: МИКРОТРАНЗАКЦИИ (Config.DevProducts.Micro).
		{ Id = "LuckPotionDeal", Tab = "Boosts", Title = Config.DevProducts.Micro.LuckPotion.Icon .. " " .. Config.DevProducts.Micro.LuckPotion.Title, PriceRobux = Config.DevProducts.Micro.LuckPotion.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.Micro.LuckPotion.Id, MicroKey = "LuckPotion" },
		{ Id = "ServerLuck2Deal", Tab = "Boosts", Title = Config.DevProducts.Micro.ServerLuck2.Icon .. " " .. Config.DevProducts.Micro.ServerLuck2.Title, PriceRobux = Config.DevProducts.Micro.ServerLuck2.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.Micro.ServerLuck2.Id, MicroKey = "ServerLuck2" },
		{ Id = "ServerLuck3Deal", Tab = "Boosts", Title = Config.DevProducts.Micro.ServerLuck3.Icon .. " " .. Config.DevProducts.Micro.ServerLuck3.Title, PriceRobux = Config.DevProducts.Micro.ServerLuck3.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.Micro.ServerLuck3.Id, MicroKey = "ServerLuck3" },
		{ Id = "MoneyRushDeal", Tab = "Boosts", Title = Config.DevProducts.Micro.MoneyRush.Icon .. " " .. Config.DevProducts.Micro.MoneyRush.Title, PriceRobux = Config.DevProducts.Micro.MoneyRush.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.Micro.MoneyRush.Id, MicroKey = "MoneyRush" },
		{ Id = "MineRushDeal", Tab = "Boosts", Title = Config.DevProducts.Micro.MineRush.Icon .. " " .. Config.DevProducts.Micro.MineRush.Title, PriceRobux = Config.DevProducts.Micro.MineRush.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.Micro.MineRush.Id, MicroKey = "MineRush" },
		{ Id = "PerfectStrikeDeal", Tab = "Boosts", Title = Config.DevProducts.Micro.PerfectStrike.Icon .. " " .. Config.DevProducts.Micro.PerfectStrike.Title, PriceRobux = Config.DevProducts.Micro.PerfectStrike.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.Micro.PerfectStrike.Id, MicroKey = "PerfectStrike" },
		{ Id = "DynamiteSmallDeal", Tab = "Dynamite", Title = Config.DevProducts.Micro.DynamiteSmall.Icon .. " " .. Config.DevProducts.Micro.DynamiteSmall.Title, PriceRobux = Config.DevProducts.Micro.DynamiteSmall.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.Micro.DynamiteSmall.Id, MicroKey = "DynamiteSmall" },
		{ Id = "DynamiteMediumDeal", Tab = "Dynamite", Title = Config.DevProducts.Micro.DynamiteMedium.Icon .. " " .. Config.DevProducts.Micro.DynamiteMedium.Title, PriceRobux = Config.DevProducts.Micro.DynamiteMedium.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.Micro.DynamiteMedium.Id, MicroKey = "DynamiteMedium" },
		{ Id = "DynamiteMegaDeal", Tab = "Dynamite", Title = Config.DevProducts.Micro.DynamiteMega.Icon .. " " .. Config.DevProducts.Micro.DynamiteMega.Title, PriceRobux = Config.DevProducts.Micro.DynamiteMega.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.Micro.DynamiteMega.Id, MicroKey = "DynamiteMega" },
		{ Id = "SmeltNowDeal", Tab = "Boosts", Title = Config.DevProducts.Micro.SmeltNow.Icon .. " " .. Config.DevProducts.Micro.SmeltNow.Title, PriceRobux = Config.DevProducts.Micro.SmeltNow.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.Micro.SmeltNow.Id, MicroKey = "SmeltNow" },

		-- РАЗОВЫЕ ПОКУПКИ — деньги/расходники (см. Config.DevProducts/Config.Protection).
		-- ПОГОДНЫЕ ИВЕНТЫ — по прямому запросу поставлены самыми первыми
		-- среди Deals (см. Config.DevProducts.Weather* выше).
		{ Id = "WeatherNightDeal", Tab = "Weather", Title = "🌙 Nightfall", PriceRobux = Config.DevProducts.WeatherNight.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.WeatherNight.Id },
		{ Id = "WeatherRainDeal", Tab = "Weather", Title = "🌧 Rainstorm", PriceRobux = Config.DevProducts.WeatherRain.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.WeatherRain.Id },
		{ Id = "WeatherThunderstormDeal", Tab = "Weather", Title = "⛈ Thunderstorm", PriceRobux = Config.DevProducts.WeatherThunderstorm.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.WeatherThunderstorm.Id },
		{ Id = "WeatherBloodMoonDeal", Tab = "Weather", Title = "🩸 Blood Moon", PriceRobux = Config.DevProducts.WeatherBloodMoon.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.WeatherBloodMoon.Id },
		{ Id = "WeatherSolarEclipseDeal", Tab = "Weather", Title = "🌑 Solar Eclipse", PriceRobux = Config.DevProducts.WeatherSolarEclipse.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.WeatherSolarEclipse.Id },
		{ Id = "MoneyPackSmallDeal", Tab = "Cash", Title = ("💵 %d Min Cash"):format(Config.DevProducts.MoneyPackSmall.Minutes), PriceRobux = Config.DevProducts.MoneyPackSmall.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.MoneyPackSmall.Id },
		{ Id = "MoneyPackMediumDeal", Tab = "Cash", Title = ("💰 %d Min Cash"):format(Config.DevProducts.MoneyPackMedium.Minutes), PriceRobux = Config.DevProducts.MoneyPackMedium.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.MoneyPackMedium.Id },
		{ Id = "MoneyPackLargeDeal", Tab = "Cash", Title = ("🏦 %d Min Cash"):format(Config.DevProducts.MoneyPackLarge.Minutes), PriceRobux = Config.DevProducts.MoneyPackLarge.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.MoneyPackLarge.Id },
		{ Id = "ShieldExtensionDeal", Tab = "Deals", Title = ("🛡 Shield +%ds"):format(Config.Protection.PaidDuration), PriceRobux = Config.Protection.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.Protection.PaidProductId },
		{ Id = "StarterPackDeal", Tab = "Deals", Title = "🎁 Starter Pack", PriceRobux = Config.DevProducts.StarterPack.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.StarterPack.Id },
		-- Geodes are also available from the normal donation shop. The same
		-- ProductIds are handled by MonetizationService's durable geode branch.
		{ Id = "StoneGeodeDeal", Tab = "Geodes", Title = "🪨 Stone Geode", PriceRobux = Config.DevProducts.GeodePacks.Stone.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.GeodePacks.Stone.Id },
		{ Id = "CrystalGeodeDeal", Tab = "Geodes", Title = "🪨 Crystal Geode", PriceRobux = Config.DevProducts.GeodePacks.Crystal.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.GeodePacks.Crystal.Id },
		{ Id = "AmberGeodeDeal", Tab = "Geodes", Title = "🪨 Amber Geode", PriceRobux = Config.DevProducts.GeodePacks.Amber.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.GeodePacks.Amber.Id },
		{ Id = "TopazGeodeDeal", Tab = "Geodes", Title = "🪨 Topaz Geode", PriceRobux = Config.DevProducts.GeodePacks.Topaz.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.GeodePacks.Topaz.Id },
		{ Id = "JadeGeodeDeal", Tab = "Geodes", Title = "🪨 Jade Geode", PriceRobux = Config.DevProducts.GeodePacks.Jade.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.GeodePacks.Jade.Id },
		{ Id = "OnyxGeodeDeal", Tab = "Geodes", Title = "🪨 Onyx Geode", PriceRobux = Config.DevProducts.GeodePacks.Onyx.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.GeodePacks.Onyx.Id },
		{ Id = "AuroraGeodeDeal", Tab = "Geodes", Title = "🪨 Aurora Geode", PriceRobux = Config.DevProducts.GeodePacks.Aurora.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.GeodePacks.Aurora.Id },
		{ Id = "NebulaGeodeDeal", Tab = "Geodes", Title = "🪨 Nebula Geode", PriceRobux = Config.DevProducts.GeodePacks.Nebula.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.GeodePacks.Nebula.Id },
		{ Id = "QuasarGeodeDeal", Tab = "Geodes", Title = "🪨 Quasar Geode", PriceRobux = Config.DevProducts.GeodePacks.Quasar.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.GeodePacks.Quasar.Id },
		{ Id = "SingularityGeodeDeal", Tab = "Geodes", Title = "🪨 Singularity Geode", PriceRobux = Config.DevProducts.GeodePacks.Singularity.PriceRobux, ImageId = 0, ProductType = "DevProduct", ProductId = Config.DevProducts.GeodePacks.Singularity.Id },
	},

	-- Знак "?" рядом с кнопкой магазина (ShopEntry) — ПОЯВЛЯЕТСЯ
	-- ВРЕМЕНАМИ сам по себе, ненавязчиво напоминая про магазин, а не
	-- висит там постоянно (см. CustomCartUI.client.lua). Пока магазин
	-- открыт — подсказка не показывается.
	HintShowDuration = 8,   -- сколько секунд подряд виден "?"
	HintHideDuration = 55,  -- пауза между показами
	HintImageId = 0, -- изображение вместо знака вопроса у кнопки магазина
}

-- v20.4: «FOREVER PACK» — верхняя полоса магазина (референс Prospecting).
-- Цепочка наград обновляется каждые RefreshHours: первая — бесплатная
-- (FreeMinutes минут дохода игрока), следующие — паки за Robux строго по
-- очереди (следующий открывается, когда куплен предыдущий). Справа — самый
-- дорогой пак (Big) большой карточкой с анимацией, доступен всегда.
Config.Shop.ForeverPack = {
	Title = "Forever Pack",
	RefreshHours = 4,
	FreeMinutes = 3,
	Steps = { "Free", "MoneyPackSmall", "MoneyPackMedium" },
	Big = "MoneyPackLarge",
	BigTitle = "Mega Cash",
}

-- v20: заголовок окна, акценты секций и короткие описания карточек магазина
-- (строка под названием товара, как «+200 Meteor Shards!» на референсе).
Config.Shop.WindowTitle = "Prospector's Shop"
Config.Shop.TabAccents = { Cash = "Green", Boosts = "Gold", Passes = "Purple", Weather = "Blue", Geodes = "Orange", Dynamite = "Red", Deals = "Pink", Skins = "Teal", Forever = "Orange", Support = "Pink" }
Config.Shop.TabEmoji = { Cash = "💵", Boosts = "⚡", Passes = "🎫", Weather = "⛅", Geodes = "🪨", Dynamite = "🧨", Deals = "🎁", Skins = "⛏", Support = "❤" }
Config.Shop.Descriptions = {
	DoubleCashPass = "x2 money from every sale!",
	DoubleLuckPass = "x2 mutation luck, rarer ore!",
	OreMagnetPass = "Ore flies to you on its own!",
	ExtraPouchPass = "+20 backpack space!",
	GeodeMasterPass = "Open 3/5 geodes at once!",
	DemolitionExpertPass = "Faster dynamite + 1 free daily!",
	CartGuardPass = "Longer cart shield!",
	FastSmelterPass = "x2 faster furnace, +1 slot!",
	RocketPickaxePass = "The fastest pickaxe!",
	DoubleSafePass = "x2 safe income!",
	AutoHammerPass = "Geodes crack themselves - auto hammer!",
	DoubleDropsPass = "x2 geode rewards!",
	FillSafeDeal = "Fill your safe instantly!",
	LuckPotionDeal = "x2 luck for 15 minutes!",
	ServerLuck2Deal = "x2 luck for the whole server!",
	ServerLuck3Deal = "x3 luck for the whole server!",
	MoneyRushDeal = "x2 money for 5 minutes!",
	MineRushDeal = "Next 3 digs give x2!",
	PerfectStrikeDeal = "Guaranteed perfect boulder!",
	DynamiteSmallDeal = "+5 small dynamite!",
	DynamiteMediumDeal = "+5 dynamite bundles!",
	DynamiteMegaDeal = "+3 mega TNT!",
	SmeltNowDeal = "Finish smelting right now!",
	WeatherNightDeal = "Start Nightfall for everyone!",
	WeatherRainDeal = "Start a Rainstorm for everyone!",
	WeatherThunderstormDeal = "Start a Thunderstorm for everyone!",
	WeatherBloodMoonDeal = "Start a Blood Moon for everyone!",
	WeatherSolarEclipseDeal = "Start a Solar Eclipse for everyone!",
	MoneyPackSmallDeal = "Instant cash!",
	MoneyPackMediumDeal = "Instant cash! Popular!",
	MoneyPackLargeDeal = "Instant cash! Best value!",
	ShieldExtensionDeal = "Extend your shield!",
	StarterPackDeal = "One-time bundle!",
	StoneGeodeDeal = "+1 Stone Geode!",
	CrystalGeodeDeal = "+1 Crystal Geode!",
	AmberGeodeDeal = "+1 Amber Geode!",
	TopazGeodeDeal = "+1 Topaz Geode!",
	JadeGeodeDeal = "+1 Jade Geode!",
	OnyxGeodeDeal = "+1 Onyx Geode!",
	AuroraGeodeDeal = "+1 Aurora Geode!",
	NebulaGeodeDeal = "+1 Nebula Geode!",
	QuasarGeodeDeal = "+1 Quasar Geode!",
	SingularityGeodeDeal = "+1 Singularity Geode!",
}

--------------------------------------------------------------------------------
-- КНОПКИ БЫСТРОГО ДОСТУПА К ГЕЙМПАССАМ (ScreenGui "GamepassQuickBar", см.
-- tools/BuildAllUI.lua) — маленький ряд иконок рядом с хотбаром/
-- кнопкой щита. Клик по кнопке сразу открывает системное окно покупки
-- этого геймпасса (Config.GamePasses[Key].Id) — БЕЗ похода в общий
-- магазин. Если пасс уже куплен — кнопка подсвечивается золотым и клик
-- по ней ничего не открывает (см. CustomCartUI.client.lua, читает
-- атрибут игрока "Owns_"..Key, см. MonetizationService).
--
-- ПОКАЗЫВАЕТСЯ ПО ОДНОЙ КНОПКЕ ЗА РАЗ, ВРЕМЕНАМИ — не постоянный ряд из
-- 5+1 кнопок (мешал бы обзору/бою), а редкая "реклама" одного случайного
-- ещё не купленного пасса (или разового девпродукта из DevProductAd ниже,
-- он не "куплен раз навсегда" — участвует в ротации всегда): появилась
-- (с лёгкой тряской — ShakeDuration — чтобы привлечь взгляд) на
-- ShowDuration секунд → если за это время НЕ купили, укатывается вниз
-- (RollDownOffset, крутится при этом) и исчезает → пауза HideDuration
-- секунд → снова появляется (другая, случайно). Если все геймпассы уже
-- куплены — ничего не показывается (девпродукт всё равно продолжает
-- участвовать в ротации, ему "куплен" не бывает).
--------------------------------------------------------------------------------
Config.QuickBar = {
	StaticPassIcons = false,
	Passes = {
		{ Key = "DoubleCash", Emoji = "💰", ImageId = 0 },
		{ Key = "DoubleLuck", Emoji = "🍀", ImageId = 0 },
		{ Key = "OreMagnet", Emoji = "🧲", ImageId = 0 },
		{ Key = "ExtraPouch", Emoji = "🎒", ImageId = 0 },
		{ Key = "GeodeMaster", Emoji = "🪨", ImageId = 0 },
		{ Key = "DemolitionExpert", Emoji = "🧨", ImageId = 0 },
		{ Key = "CartGuard", Emoji = "🛡️", ImageId = 0 },
		{ Key = "FastSmelter", Emoji = "⚡", ImageId = 0 },
		{ Key = "RocketPickaxe", Emoji = "🚀", ImageId = 0 },
		{ Key = "DoubleSafe", Emoji = "🏦", ImageId = 0 },
		{ Key = "AutoHammer", Emoji = "🔨", ImageId = 0 },
	},

	-- Отдельная реклама РАЗОВОГО товара (девпродукт, не геймпасс) — тот же
	-- ProductId, что и у карточки "ShieldExtensionDeal" в Config.Shop.Items
	-- (Config.Protection.PaidProductId), просто ещё и всплывает в этой
	-- быстрой ротации, а не только лежит в магазине.
	DevProductAd = {
		Key = "ShieldExtension",
		Emoji = "🛡️+",
		ImageId = 0,
		Title = ("Shield +%ds"):format(Config.Protection.PaidDuration),
	},

	-- "СКИП РЕБЁРТА" (см. Config.DevProducts.RebirthSkip) — В ОТЛИЧИЕ от
	-- остальных кнопок здесь, продукт не один фиксированный: цена растёт
	-- по номеру ребёрта игрока (GetRebirths+1), клиент сам выбирает нужный
	-- индекс RebirthSkip в момент клика (см. CustomCartUI.client.lua).
	-- ПОКАЗЫВАЕТСЯ ТОЛЬКО КОНТЕКСТНО (принудительно, как GoldenShield/
	-- FastMining) — когда у игрока прокачаны все 3 ветки до тир-капа, но не
	-- хватает денег на сам ребёрт (см. RebirthService — атрибут
	-- "NeedsRebirthSkip"). В обычную случайную ротацию НЕ участвует: показ
	-- ради показа не имеет смысла, если ребёрт всё равно не готов.
	RebirthSkipAd = {
		Key = "RebirthSkip",
		Emoji = "♻️",
		ImageId = 0,
		Title = "Prestige Skip",
	},

	ShowDuration = 30,     -- сколько секунд подряд видна ОДНА кнопка, прежде чем укатится вниз, если её не купили
	HideDuration = 45,     -- пауза (кнопок нет вообще) между показами
	ShakeDuration = 0.5,   -- сколько длится лёгкая тряска при появлении кнопки
	RollDownOffset = 140,  -- на сколько пикселей вниз укатывается кнопка, если её не купили за ShowDuration
	HintImageId = 0, -- изображение вместо "?" над quick-bar кнопкой
	OwnedImageId = 0, -- изображение вместо галочки купленного пасса
}

--------------------------------------------------------------------------------
-- РЕФЕРАЛЬНАЯ СИСТЕМА — бонус к деньгам за друзей (настоящих Roblox-друзей,
-- не отдельных инвайт-кодов), которые находятся на ТОМ ЖЕ сервере прямо
-- сейчас. Считается сервером через Player:IsFriendsWith при каждом входе/
-- выходе игрока (см. MonetizationService:RecomputeReferralGraph) — приходить
-- заново не нужно, эффект живой весь сеанс, пока друг в сервере.
--
-- Множитель НЕЗАВИСИМ от платных x2/x4/x6/x8 геймпассов
-- (MonetizationService:GetCashMultiplier) и умножается на него, а не
-- складывается — так покупка кэш-пасса не "съедает" честно заработанный
-- реферальный бонус и наоборот.
--
-- MoneyMultiplierPerFriend — на сколько вырастает множитель за КАЖДОГО
-- друга (аддитивно между собой, чтобы не улетать в космос при большой
-- пачке друзей): 1 друг → x2, 2 друга → x3, при MoneyMultiplierPerFriend=1.
-- MaxFriends — потолок учитываемых друзей одновременно.
--
-- PromptInterval — раз во сколько секунд каждому игроку показывается
-- Toast-напоминание "пригласи друзей" (см. MonetizationService — обычный
-- Services.NotifyService:Show, тот же тост, что и у "не хватает денег" и
-- т.п., с кнопкой-действием "Invite", открывающей системное окно
-- приглашения). Не показывается, пока игрок уже играет с максимумом
-- учитываемых друзей (MaxFriends) — рекламировать уже нечего.
--------------------------------------------------------------------------------
Config.Referral = {
	MoneyMultiplierPerFriend = 1.0,
	MaxFriends = 3,
	PromptInterval = 360, -- 6 минут
}

--------------------------------------------------------------------------------
-- STARTER QUESTS, DAILY QUESTS, AND DAILY LOGIN REWARDS
--------------------------------------------------------------------------------
Config.Quests = {
	-- Картинка в Icon у каждой строки квеста
	-- (см. QuestUI.client.lua/tools/BuildAllUI.lua) — 0 = пустая картинка
	-- на цветной подложке. Один общий значок для
	-- всех квестов, не по одному на каждый.
	IconId = 0,
	-- v16: КВЕСТЫ ПЕРЕДЕЛАНЫ под экономику v4 (15 пещер, тележка/кирка до 9,
	-- комбо до x3, престиж с пещеры 8, торговец, тотемы, сундуки, острова).
	-- STORY — цепочка по порядку (активен первый несданный; квесты с
	-- RequiresPlayers пропускаются, пока на сервере мало людей).
	--   Why    — «зачем» (строка в трекере и у цели);
	--   Nav    — куда ведёт навигация (см. client/QuestMarker.client.lua);
	--   Reward — { TripValue = доля полной тележки, MinMoney, Items = {...} }
	--   Items: { Kind = "Gear", Key, Count } (динамит/зелья),
	--          { Kind = "Chest", Rarity }, { Kind = "Geode", Offset },
	--          { Kind = "Placeable", Id }, { Kind = "PrestigePoints", Count }.
	Starter = {
		-- v20.53: цепочка по прогрессии — каждый квест учит одной механике.
		{ Id = "FirstSale", Metric = "CartSales", Title = "FIRST DELIVERY", Description = "Sell your backpack to the mole", Short = "Sell to the mole", Target = 1, Nav = "Bank",
			Why = "Ore only turns into money at the bank.", Reward = { TripValue = 1, MinMoney = 60, Items = { { Kind = "Gear", Key = "Dynamite", Count = 2 } } } },
		{ Id = "GrabOre", Metric = "OrePickedUp", Title = "GRAB THE ORE", Description = "Walk over ore from the mine to pick it up (10 pieces)", Short = "Pick up 10 ore", Target = 10, Nav = "Miner", SkipWhenMaxTierAtLeast = 3,
			Why = "Ore in your bag goes to the cart or straight to the bank.", Reward = { TripValue = 0.5, MinMoney = 40 } },
		{ Id = "UpgradeMine", Metric = "MineTier", Title = "DIG DEEPER", Description = "Upgrade the Cave to 3", Short = "Cave to 3", Target = 3, Nav = "UpgradeShopNPC",
			Why = "Deeper caves have pricier ore.", Reward = { TripValue = 1.5, MinMoney = 100 } },
		{ Id = "UpgradeCart", Metric = "CartTier", Title = "BIGGER BACKPACK", Description = "Upgrade the Backpack to 2", Short = "Backpack to 2", Target = 2, Nav = "UpgradeShopNPC",
			Why = "A bigger cart carries more ore per trip.", Reward = { TripValue = 1.5, MinMoney = 100, Items = { { Kind = "Gear", Key = "Potion_Speed", Count = 1 } } } },
		{ Id = "FirstBoulder", Metric = "BouldersBroken", Title = "CRACK A BOULDER", Description = "Break a glowing boulder with your pickaxe", Short = "Break a boulder", Target = 1, Nav = "Boulder",
			Why = "Boulders drop ore, geodes and chests.", Reward = { TripValue = 1, MinMoney = 80, Items = { { Kind = "Chest", Rarity = "Common" } } } },
		{ Id = "Kaboom", Metric = "DynamiteUsed", Title = "KABOOM!", Description = "Hold dynamite from your hotbar and throw it at a boulder", Short = "Use dynamite", Target = 1, Nav = "Boulder", SkipWhenMaxTierAtLeast = 5,
			Why = "Dynamite cracks boulders fast and knocks players away!", Reward = { TripValue = 1, MinMoney = 80, Items = { { Kind = "Gear", Key = "Dynamite", Count = 2 } } } },
		{ Id = "UpgradePickaxe", Metric = "PickaxeTier", Title = "SHARPER PICK", Description = "Upgrade the Pickaxe to 2", Short = "Pickaxe to 2", Target = 2, Nav = "UpgradeShopNPC",
			Why = "A stronger pickaxe breaks tougher boulders.", Reward = { TripValue = 1.5, MinMoney = 120 } },
		{ Id = "OpenChest", Metric = "ChestsOpened", Title = "TREASURE TIME", Description = "Place a chest on your base, wait and open it", Short = "Open a chest", Target = 1, Nav = "PlotBase",
			Why = "Chests hold money, geodes, dynamite and even relics.", Reward = { TripValue = 1.5, MinMoney = 120 } },
		{ Id = "GeodeCollector", Metric = "GeodesOpened", Title = "CRACK A GEODE", Description = "Open a geode at your geode building", Short = "Open a geode", Target = 1, Nav = "GeodeVault",
			Why = "Geodes hold crystals that earn money even offline.", Reward = { TripValue = 1.5, MinMoney = 120, Items = { { Kind = "Geode", Offset = 0 } } } },
		{ Id = "GoblinHunter", Metric = "GoblinsKilled", Title = "GOBLIN HUNTER", Description = "Defeat 3 goblins at the Goblin Camp", Short = "Defeat 3 goblins", Target = 3, Nav = "GoblinCamp",
			Why = "Goblin raids come every 5 min and drop cash, dynamite and chests.", Reward = { TripValue = 1.5, MinMoney = 150, Items = { { Kind = "Chest", Rarity = "Common" } } } },
		{ Id = "MerchantBuy", Metric = "MerchantBuys", Title = "MEET THE MERCHANT", Description = "Buy anything from the Ore Merchant at the bank", Short = "Buy from the merchant", Target = 1, Nav = "Merchant",
			Why = "The merchant restocks totems, potions and rare picks every 5 min.", Reward = { TripValue = 2, Items = { { Kind = "Placeable", Id = "Totem_Fortune_T1" } } } },
		{ Id = "PlaceTotem", Metric = "ItemsPlaced", Title = "DECORATE THE BASE", Description = "Place a totem or decoration on your base", Short = "Place a totem", Target = 1, Nav = "PlotBase",
			Why = "Totems on your base boost luck, income and more.", Reward = { TripValue = 2 } },
		{ Id = "FirstIsland", Metric = "IslandsOwned", Title = "UNLOCK AN ISLAND", Description = "Buy an island from the Island Keeper in town", Short = "Buy an island", Target = 1, Nav = "IslandKeeper",
			Why = "Islands unlock the anvil, the income podium and the smelter.", Reward = { TripValue = 2, MinMoney = 200 } },
		{ Id = "HeavyCargo", Metric = "Cart70Sales", Title = "HEAVY CARGO", Description = "Sell 3 backpacks filled to 70%+", Short = "Sell 3 full bags", Target = 3, Nav = "Bank",
			Why = "Fuller carts sell with a combo - up to x3!", Reward = { TripValue = 2, MinMoney = 200, Items = { { Kind = "Gear", Key = "Potion_Money", Count = 1 } } } },
		{ Id = "GiftCrystal", Metric = "CrystalsGifted", Title = "SHARE THE WEALTH", Description = "Gift a crystal to another player", Short = "Gift a crystal", Target = 1, Nav = "NearestPlayer", RequiresPlayers = 2,
			Why = "Friends on the server boost everyone's income.", Reward = { TripValue = 1.5, MinMoney = 150 } },
		{ Id = "MineTier5", Metric = "MineTier", Title = "CAVE FIVE", Description = "Upgrade the Cave to 5", Short = "Cave to 5", Target = 5, Nav = "UpgradeShopNPC",
			Why = "Cave 5 unlocks the Dynamite Bundle.", Reward = { TripValue = 2, Items = { { Kind = "Gear", Key = "Dynamite_Medium", Count = 1 } } } },
		{ Id = "PassiveStart", Metric = "SafeCollected", Title = "PASSIVE INCOME", Description = "Put a crystal on the podium and collect $500 from the safe", Short = "Collect $500 from safe", Target = 500, Nav = "GeodeSafe",
			Why = "The crystal on the podium fills the safe - even offline.", Reward = { TripValue = 2 } },
		{ Id = "HotMetal", Metric = "OresSmelted", Title = "HOT METAL", Description = "Hold an ore and put it into the Smelter on your island", Short = "Smelt an ore", Target = 1, Nav = "Smelter",
			Why = "Smelted ingots sell for much more than raw ore.", Reward = { TripValue = 2 } },
		{ Id = "CartTier4", Metric = "CartTier", Title = "HEAVY HAULER", Description = "Upgrade the Backpack to 4", Short = "Backpack to 4", Target = 4, Nav = "UpgradeShopNPC",
			Why = "Every cart tier fits more ore.", Reward = { TripValue = 2.5 } },
		{ Id = "RareFind", Metric = "RareOres", Title = "RARE FIND", Description = "Collect 3 Rare+ crystals", Short = "Find 3 Rare crystals", Target = 3, Nav = "Mine",
			Why = "Rare ore sells for much more - luck helps!", Reward = { TripValue = 2.5, Items = { { Kind = "Gear", Key = "Potion_Luck", Count = 1 } } } },
		{ Id = "CampCrusher", Metric = "GoblinsKilled", Title = "CAMP CRUSHER", Description = "Defeat 25 goblins at the Goblin Camp", Short = "Defeat 25 goblins", Target = 25, Nav = "GoblinCamp",
			Why = "Deal the most damage in a raid for the best chest.", Reward = { TripValue = 2.5, Items = { { Kind = "Chest", Rarity = "Rare" } } } },
		{ Id = "ComboMaster", Metric = "X4Sales", Title = "COMBO MASTER", Description = "Sell 2 full backpacks at x3 combo", Short = "2 sales at x3", Target = 2, Nav = "Bank",
			Why = "A full cart triples its price.", Reward = { TripValue = 3 } },
		{ Id = "MineTier8", Metric = "MineTier", Title = "THE DEEP", Description = "Upgrade the Cave to 8", Short = "Cave to 8", Target = 8, Nav = "UpgradeShopNPC",
			Why = "Cave 8 unlocks PRESTIGE.", Reward = { TripValue = 3, Items = { { Kind = "Chest", Rarity = "Rare" } } } },
		{ Id = "BigGoal", Metric = "Rebirths", Title = "THE BIG GOAL", Description = "Prestige at the Prestige Mayor", Short = "Prestige once", Target = 1, Nav = "RebirthNPC",
			Why = "Prestige points buy permanent perks and shrines.", Reward = { TripValue = 3, MinMoney = 2000, Items = { { Kind = "PrestigePoints", Count = 1 } } } },
		{ Id = "FirstPerk", Metric = "PerksBought", Title = "PERMANENT POWER", Description = "Spend prestige points in the Prestige Case", Short = "Buy a perk or shrine", Target = 1, Nav = "PrestigeCase",
			Why = "Perks and shrines never reset.", Reward = { TripValue = 2 } },
		{ Id = "BoulderBreaker", Metric = "BouldersBroken", Title = "BOULDER BREAKER", Description = "Break 25 boulders", Short = "Break 25 boulders", Target = 25, Nav = "Boulder",
			Why = "Boulders are the best source of chests.", Reward = { TripValue = 3, Items = { { Kind = "Chest", Rarity = "Epic" } } } },
		{ Id = "GeodeProspector", Metric = "GeodesOpened", Title = "GEODE PROSPECTOR", Description = "Open 10 geodes", Short = "Open 10 geodes", Target = 10, Nav = "GeodeVault",
			Why = "Better crystals mean a richer safe.", Reward = { TripValue = 3, Items = { { Kind = "Geode", Offset = 1 } } } },
		{ Id = "MineTier12", Metric = "MineTier", Title = "ABYSS WALKER", Description = "Upgrade the Cave to 12", Short = "Cave to 12", Target = 12, Nav = "UpgradeShopNPC",
			Why = "Legendary ores wait at the bottom.", Reward = { TripValue = 4, Items = { { Kind = "Gear", Key = "Potion_MoneyX3", Count = 1 } } } },
		{ Id = "CargoKing", Metric = "CartSales", Title = "CARGO KING", Description = "Sell 50 backpacks to the mole", Short = "Sell 50 bags", Target = 50, Nav = "Bank",
			Why = "Every trip counts.", Reward = { TripValue = 4, Items = { { Kind = "Chest", Rarity = "Epic" } } } },
		{ Id = "TierMaster", Metric = "MineTier", Title = "BOTTOM OF THE WORLD", Description = "Reach the deepest cave (15)", Short = "Cave to 15", Target = 15, Nav = "UpgradeShopNPC",
			Why = "The final cave has the richest ore weights.", Reward = { TripValue = 6, Items = { { Kind = "Chest", Rarity = "Legendary" } } } },
		{ Id = "FullUpgrade", Metric = "FullUpgrade", Title = "FULLY UPGRADED", Description = "Max out the Cave, Backpack and Pickaxe", Short = "Max all three", Target = 1, Nav = "UpgradeShopNPC",
			Why = "Then prestige for even more points!", Reward = { TripValue = 8, Items = { { Kind = "PrestigePoints", Count = 2 } } } },
		{ Id = "MasterMiner", Metric = "OreSold", Title = "MASTER MINER", Description = "Sell 2,000 ore at the bank", Short = "Sell 2,000 ore", Target = 2000, Nav = "Bank",
			Why = "A true miner never stops.", Reward = { TripValue = 8, Items = { { Kind = "Chest", Rarity = "Legendary" } } } },
		{ Id = "GeodeExpert", Metric = "GeodesOpened", Title = "GEODE EXPERT", Description = "Open 50 geodes", Short = "Open 50 geodes", Target = 50, Nav = "GeodeVault",
			Why = "Mythic crystals are out there.", Reward = { TripValue = 8, Items = { { Kind = "Chest", Rarity = "Legendary" } } } },
	},
	-- DAILY: каждый день 3 квеста (по одному из Simple/Medium/PvP). Награда
	-- выдаётся сразу; WeeklyPoints копятся в недельные сундуки (WeeklyChests).
	Daily = {
		Simple = {
			{ Id = "Play5MinutesDaily", Metric = "PlayTime", Title = "PLAY FOR 5 MINUTES", Description = "Play for 5 minutes", Short = "Play 5 minutes", Target = 300, Reward = { TripValue = 1.5, MinMoney = 150 }, WeeklyPoints = 1 },
			{ Id = "Sell3Carts", Metric = "CartSales", Title = "SELL 3 BACKPACKS", Description = "Sell 3 backpacks to the mole", Short = "Sell 3 bags", Target = 3, Reward = { TripValue = 1.2, MinMoney = 100, Items = { { Kind = "Gear", Key = "Dynamite", Count = 1 } } }, WeeklyPoints = 1 },
			{ Id = "Sell20Ore", Metric = "OreSold", Title = "SELL 20 ORE", Description = "Sell 20 ore at the bank", Short = "Sell 20 ore", Target = 20, Reward = { TripValue = 1, MinMoney = 80 }, WeeklyPoints = 1 },
			{ Id = "Break3Boulders", Metric = "BouldersBroken", Title = "BREAK 3 BOULDERS", Description = "Break 3 boulders", Short = "Break 3 boulders", Target = 3, Reward = { TripValue = 1.2, MinMoney = 100 }, WeeklyPoints = 1 },
			{ Id = "Open2Geodes", Metric = "GeodesOpened", Title = "OPEN 2 GEODES", Description = "Open 2 geodes", Short = "Open 2 geodes", Target = 2, Reward = { TripValue = 1.2, MinMoney = 100 }, WeeklyPoints = 1 },
			{ Id = "Collect10Crystals", Metric = "OresCollected", Title = "COLLECT 10 CRYSTALS", Description = "Collect 10 crystals", Short = "Collect 10 crystals", Target = 10, Reward = { TripValue = 1.2, MinMoney = 100 }, WeeklyPoints = 1 },
			{ Id = "LoadedCart", Metric = "Cart70Sales", Title = "SELL A FULL BAG", Description = "Sell a backpack 70%+ full", Short = "Sell a full bag", Target = 1, Reward = { TripValue = 1.2, MinMoney = 100, Items = { { Kind = "Gear", Key = "Potion_Speed", Count = 1 } } }, WeeklyPoints = 1 },
			{ Id = "Jump100", Metric = "Jumps", Title = "JUMP 100 TIMES", Description = "Jump 100 times", Short = "Jump 100 times", Target = 100, Reward = { TripValue = 1, MinMoney = 100 }, WeeklyPoints = 1 },
		},
		Medium = {
			{ Id = "Play15MinutesDaily", Metric = "PlayTime", Title = "PLAY FOR 15 MINUTES", Description = "Play for 15 minutes", Short = "Play 15 minutes", Target = 900, Reward = { TripValue = 3, MinMoney = 350, Items = { { Kind = "Gear", Key = "Potion_Money", Count = 1 } } }, WeeklyPoints = 2 },
			{ Id = "Sell60Ore", Metric = "OreSold", Title = "SELL 60 ORE", Description = "Sell 60 ore at the bank", Short = "Sell 60 ore", Target = 60, Reward = { TripValue = 2.5, MinMoney = 250 }, WeeklyPoints = 2 },
			{ Id = "TwoX3Sales", Metric = "X4Sales", Title = "SELL AT X3 TWICE", Description = "Sell 2 full backpacks at x3 combo", Short = "2 sales at x3", Target = 2, Reward = { TripValue = 3, MinMoney = 300 }, WeeklyPoints = 2 },
			{ Id = "Buy2Upgrades", Metric = "Upgrades", Title = "BUY 2 UPGRADES", Description = "Buy 2 upgrades from the Experienced Miner", Short = "Buy 2 upgrades", Target = 2, Reward = { TripValue = 2.5, MinMoney = 250 }, WeeklyPoints = 2 },
			{ Id = "OpenChestDaily", Metric = "ChestsOpened", Title = "OPEN A CHEST", Description = "Open a chest on your base", Short = "Open a chest", Target = 1, Reward = { TripValue = 2, MinMoney = 250, Items = { { Kind = "Gear", Key = "Dynamite", Count = 2 } } }, WeeklyPoints = 2 },
			{ Id = "Break8Boulders", Metric = "BouldersBroken", Title = "BREAK 8 BOULDERS", Description = "Break 8 boulders", Short = "Break 8 boulders", Target = 8, Reward = { TripValue = 2.5, MinMoney = 250 }, WeeklyPoints = 2 },
			{ Id = "Open5Geodes", Metric = "GeodesOpened", Title = "OPEN 5 GEODES", Description = "Open 5 geodes", Short = "Open 5 geodes", Target = 5, Reward = { TripValue = 2.5, MinMoney = 250, Items = { { Kind = "Geode", Offset = 0 } } }, WeeklyPoints = 2 },
			{ Id = "Find2Rare", Metric = "RareOres", Title = "FIND 2 RARE CRYSTALS", Description = "Collect 2 Rare+ crystals", Short = "Find 2 Rare crystals", Target = 2, Reward = { TripValue = 3, MinMoney = 300, Items = { { Kind = "Gear", Key = "Potion_Luck", Count = 1 } } }, WeeklyPoints = 2 },
			{ Id = "MerchantDaily", Metric = "MerchantBuys", Title = "SHOP AT THE MERCHANT", Description = "Buy something from the Ore Merchant", Short = "Buy from the merchant", Target = 1, Reward = { TripValue = 2, MinMoney = 200 }, WeeklyPoints = 2 },
		},
		PvP = {
			{ Id = "Knock5Ore", Metric = "OreStolen", Title = "STEAL 5 ORE", Description = "Knock 5 ore from enemies", Short = "Steal 5 ore", Target = 5, Reward = { TripValue = 2.5, MinMoney = 200 }, WeeklyPoints = 2, RequiresPlayers = 2 },
			{ Id = "Deal100Damage", Metric = "Damage", Title = "DEAL 100 DAMAGE", Description = "Deal 100 damage to players", Short = "Deal 100 damage", Target = 100, Reward = { TripValue = 2.5, MinMoney = 200 }, WeeklyPoints = 2, RequiresPlayers = 2 },
			{ Id = "Deal250Damage", Metric = "Damage", Title = "DEAL 250 DAMAGE", Description = "Deal 250 damage to players", Short = "Deal 250 damage", Target = 250, Reward = { TripValue = 3.5, MinMoney = 350, Items = { { Kind = "Gear", Key = "Dynamite_Medium", Count = 1 } } }, WeeklyPoints = 3, RequiresPlayers = 2 },
			{ Id = "Land15Hits", Metric = "CombatHits", Title = "HIT PLAYERS 15 TIMES", Description = "Hit players 15 times", Short = "Land 15 hits", Target = 15, Reward = { TripValue = 3, MinMoney = 250 }, WeeklyPoints = 2, RequiresPlayers = 2 },
			{ Id = "Steal12Ore", Metric = "OreStolen", Title = "STEAL 12 ORE", Description = "Knock 12 ore from enemies", Short = "Steal 12 ore", Target = 12, Reward = { TripValue = 3.5, MinMoney = 350 }, WeeklyPoints = 3, RequiresPlayers = 2 },
			{ Id = "Dynamite3", Metric = "DynamiteUsed", Title = "DEMOLITION DAY", Description = "Throw or place 3 dynamite", Short = "Use 3 dynamite", Target = 3, Reward = { TripValue = 2.5, MinMoney = 250, Items = { { Kind = "Gear", Key = "Dynamite", Count = 3 } } }, WeeklyPoints = 2 },
		},
	},
	-- v16: НЕДЕЛЬНЫЕ СУНДУКИ за очки дейликов (WeeklyPoints, сброс в понедельник UTC).
	WeeklyChests = {
		{ Points = 8,  Rarity = "Common" },
		{ Points = 18, Rarity = "Rare" },
		{ Points = 30, Rarity = "Epic" },
	},
	RewardIcons = { Money = "💰", Gear = "🧨", Chest = "🎁", Geode = "🪨", Placeable = "🗿", PrestigePoints = "⭐" },
	-- 7-ДНЕВНЫЙ ЦИКЛ НАГРАД. Числа растут КАЖДЫЙ день (а не скачут туда-
	-- сюда), два РАЗНЫХ буста добычи (не один и тот же дважды — см. фикс
	-- DailyMiningBoostMultiplier в QuestService, который как раз и сделал
	-- безопасным иметь больше одного разного MiningBoost в этом списке),
	-- финал — эксклюзивный скин. Text — то, что показывается КРУПНО и
	-- цветно на карточке (см. цветовую логику по Kind в DailyRewardUI.
	-- client.lua); Amount/Multiplier/Duration — то, что реально начисляет
	-- ClaimDailyReward, значения независимы от Text и не обязаны совпадать
	-- дословно (Text — маркетинг, оформленный покрасивее).
	DailyRewards = {
		-- Суммы пересчитаны вместе со сменой масштаба экономики (÷100, см.
		-- Config.Crystal_BaseValue) — та же доля прогресса на каждый день,
		-- что и раньше, просто в новых числах. MiningBoost — множитель,
		-- не абсолютная сумма, пересчёта не требует.
		{ Kind = "Money", Amount = 150, Text = "$150" },
		{ Kind = "Money", Amount = 600, Text = "$600" },
		{ Kind = "Buff", Buff = "Luck", Duration = 45 * 60, Text = "LUCK\n45 MIN" },
		{ Kind = "Money", Amount = 3000, Text = "$3K" },
		{ Kind = "Buff", Buff = "MutationPotion", Duration = 30 * 60, Text = "MUTATION\nPOTION" },
		{ Kind = "Money", Amount = 25000, Text = "$25K" },
		{ Kind = "Skin", SkinId = "Gold", Text = "GOLD\nSKIN" },
	},

	-- НАГРАДЫ ЗА ВРЕМЯ В ИГРЕ (заменили ежедневные — по прямому запросу).
	--
	-- Отсчёт идёт от ВХОДА НА СЕРВЕР и сбрасывается при выходе: это награда
	-- за сессию, а не за календарь. Поэтому ничего не хранится в профиле —
	-- отметки о выданных ступенях живут в памяти сервера, и обмануть их
	-- перезаходом бессмысленно (перезаход обнуляет и таймер).
	--
	-- Seconds — сколько надо наиграть; порядок строго по возрастанию.
	-- Kind/Amount/Multiplier/Duration — то же, что у DailyRewards, поэтому
	-- выдача переиспользует ровно тот же код начисления.
	PlaytimeRewards = {
		{ Seconds = 60,      Kind = "Money",  Amount = 100,    Text = "$100" },
		{ Seconds = 5 * 60,  Kind = "Buff",   Buff = "Luck",           Duration = 10 * 60, Text = "LUCK\n10 MIN" },
		{ Seconds = 10 * 60, Kind = "Money",  Amount = 600,    Text = "$600" },
		{ Seconds = 20 * 60, Kind = "Buff",   Buff = "MutationPotion", Duration = 10 * 60, Text = "MUTATION\nPOTION" },
		{ Seconds = 30 * 60, Kind = "Money",  Amount = 3000,   Text = "$3K" },
		{ Seconds = 45 * 60, Kind = "Buff",   Buff = "Luck",           Duration = 20 * 60, Text = "LUCK\n20 MIN" },
		{ Seconds = 60 * 60, Kind = "Money",  Amount = 15000,  Text = "$15K" },
	},
}

--------------------------------------------------------------------------------
-- СООБЩЕНИЕ В ЧАТ О ЗАХОДЕ ИГРОКА
--
-- Зачем это не косметика: часть квестов (Config.Quests, поле RequiresPlayers)
-- физически не проходится в одиночку и на пустом сервере скрыта — см.
-- QuestService. Строка «X joined the server» — это одновременно и сигнал
-- «сервер ожил», и объяснение, откуда вдруг взялись новые квесты, которых
-- минуту назад не было.
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
-- ЗАГРУЗКА ПЕРЕД КАТСЦЕНОЙ
--
-- ЧТО БЫЛО. LoadingScreen ждал ContentProvider:PreloadAsync по ВСЕМУ
-- game:GetDescendants() — до 15 секунд — и только потом разрешал катсцене
-- стартовать. Плюс до этого ждал участок (5 сек) и стабилизацию билбордов
-- (2 сек). В худшем случае игрок смотрел в ЧЁРНЫЙ ЭКРАН 22 секунды, потом
-- ещё ~10 секунд катсцену, и только затем получал управление.
--
-- ПОЧЕМУ ЭТО ДОРОГО. По измерениям индустрии каждая секунда не-геймплея в
-- первые минуты стоит примерно 2-3% новой когорты, а обязательная
-- 15-секундная катсцена — около 5% всех новых игроков ещё до первого
-- нажатия. Чёрный экран стоит столько же, но не даёт вообще ничего взамен.
--
-- ЧТО СТАЛО. Предзагрузка больше НЕ БЛОКИРУЕТ: она уходит в фон и
-- продолжается уже во время катсцены. Ждём только короткое окно
-- CriticalWaitSeconds, чтобы успели прилететь ближайшие ассеты сцены.
-- Roblox и так дорисовывает недогруженные текстуры по мере готовности —
-- ради этого держать игрока в черноте лишние 15 секунд смысла нет.
--------------------------------------------------------------------------------
Config.Loading = {
	-- v20.121: КОРОТКАЯ загрузка перед катсценой - только её риг/сцена/логотип
	-- (не дольше CutsceneWaitSeconds), SKIP появляется через SkipAfterSeconds;
	-- всё остальное грузится параллельно с катсценой.
	CutsceneWaitSeconds = 8,
	SkipAfterSeconds = 2,
	LogoImageId = 113042882863397, -- логотип на загрузке (0 - без логотипа)
	-- Сколько ждать перед стартом катсцены. Не «сколько грузить» — грузиться
	-- продолжает в фоне, — а именно сколько игрок смотрит в черноту.
	CriticalWaitSeconds = 1.5,

	-- Аварийный потолок на фоновую предзагрузку: поток не должен жить вечно,
	-- если PreloadAsync где-то залип на битом ассете.
	BackgroundTimeout = 30,
}

Config.JoinAnnounce = {
	Enabled = true,
	-- Первого игрока на сервере объявлять некому — сообщение увидел бы он
	-- сам, про самого себя, в пустом мире. Начинаем со второго.
	MinPlayers = 2,
	NameColor = Color3.fromRGB(120, 220, 255),
	TextColor = Color3.fromRGB(215, 220, 230),
	JoinSuffix = " joined the server",
}

--------------------------------------------------------------------------------
-- ЭКРАН ВОЗВРАЩЕНИЯ («ПОКА ТЕБЯ НЕ БЫЛО»)
--
-- Один экран вместо четырёх разрозненных всплывашек. Раньше офлайн-доход
-- сейфа приходил отдельным тостом через 6 секунд после захода
-- (PassiveIncomeService:SetupPlot), стрик жил в своём меню, а офлайн-руды не
-- было вовсе — игрок не собирал эти события в одно «меня тут ждали».
--------------------------------------------------------------------------------
Config.ReturnScreen = {
	Enabled = true,
	-- Не показывать, если игрока не было меньше этого времени: перезаход
	-- из-за краша/телепорта не должен открывать торжественный экран.
	MinOfflineSeconds = 300, -- 5 минут
	-- Задержка перед показом: у клиента ~6000 строк UI, и слушатель
	-- появляется не мгновенно (та же причина, по которой старый тост сейфа
	-- ждал 6 секунд). Плюс экран не должен налезать на конец катсцены.
	ShowDelay = 2.0,
	-- Сколько секунд экран висит сам, если игрок не нажал кнопку.
	AutoCloseAfter = 20,
	Title = "WHILE YOU WERE AWAY",
	ButtonText = "COLLECT ALL",
}

Config.Debug = {
	-- Показывает полупрозрачный ПАРАЛЛЕЛЕПИПЕД перед атакующим при каждом
	-- взмахе киркой — теперь это ТОЧНАЯ визуализация реальной геометрии
	-- попадания (см. Config.Combat.HitboxSize/HitboxForwardOffset и
	-- findVictim в CombatService), не просто прикидка для VFX. ОТКЛЮЧЕНО
	-- по умолчанию — это чисто отладочный визуал для проверки хитбоксов
	-- при разработке, в релизе игроки его видеть не должны. Включай сам
	-- обратно (true), только если нужно снова что-то проверить руками.
	ShowCombatHitbox = false,
	CombatHitboxLifetime = 0.6,

	-- ПРИНУДИТЕЛЬНО показывать баннер стартового пака справа посередине
	-- экрана, игнорируя все три обычных условия (новый ли игрок, не истекло
	-- ли окно OfferWindowSeconds, не куплен ли пак уже).
	--
	-- Нужен именно для ПРОВЕРКИ: на своём аккаунте, который уже играл, все
	-- три условия ложны (FirstJoinedAt в далёком прошлом, окно давно
	-- закрыто), поэтому баннера не видно — и это легко спутать с тем, что
	-- он "сломан". Включи на время проверки, перед релизом верни false.
	-- ВЫКЛЮЧЕНО. Стояло true — а это значит, что баннер платного пака
	-- показывался В ПРОДЕ вообще всем подряд: и тем, кто играет полгода
	-- (окно OfferWindowSeconds давно истекло), и после того, как окно
	-- закрылось. Куплённым игрокам он и раньше не показывался (проверка
	-- StarterPackClaimed стоит первой и forceOffer её не обходит), но
	-- «вечное срочное предложение» у старых игроков — это ровно тот вид
	-- давления, который убивает доверие к магазину.
	--
	-- Вдобавок флаг теперь физически не может утечь в релиз: см.
	-- StarterPackUI.client.lua — forceOffer учитывается ТОЛЬКО в Studio
	-- (RunService:IsStudio()). Даже если оставить здесь true и опубликовать,
	-- живые игроки этого не увидят.
	ForceStarterPackOffer = false,
}

--------------------------------------------------------------------------------
-- ВСПЛЫВАЮЩИЕ УВЕДОМЛЕНИЯ (ScreenGui "Toast", см. tools/BuildAllUI.lua) —
-- ЕДИНАЯ система коротких сообщений на экране игрока (не 3D-биллборд у
-- конкретного объекта, а прямо в UI, видно всегда, независимо от камеры).
-- Дёргается с сервера через NotifyService:Show(player, text, opts) —
-- например "кнопка тележки ещё не готова" или "не хватает денег" (с
-- кнопкой-действием "Open Shop", см. opts.ActionLabel/opts.PreferredTab).
--------------------------------------------------------------------------------
Config.Notify = {
	Duration = 3.5, -- сколько секунд подряд видно сообщение, прежде чем спрячется само
	-- v14.3: стопка в стиле Grow a Garden (вид — Shared/ToastUiBuilder,
	-- логика — CustomCartUI.client.lua, setupToast).
	MaxVisible = 2,      -- сколько карточек на экране одновременно
	StackGap = 6,        -- зазор между карточками, px
	FastQueueAt = 2,     -- столько ЖДУЩИХ в очереди → показ сокращается до FastSeconds
	FastSeconds = 1.3,
	SkipQueueAt = 5,     -- столько ждущих → промежуточные «пролетают» за SkipSeconds
	SkipSeconds = 0.45,
	MobileScale = 0.82,  -- размер стопки на телефонах
	-- Цвет полоски слева по смысловому ключу Icon (нет в списке → Default).
	AccentColors = {
		Default = Color3.fromRGB(120, 230, 90),
		Error = Color3.fromRGB(255, 90, 80),
		Alert = Color3.fromRGB(255, 90, 80),
		Stolen = Color3.fromRGB(255, 90, 80),
		Slow = Color3.fromRGB(255, 150, 60),
		Pending = Color3.fromRGB(255, 200, 70),
		Money = Color3.fromRGB(255, 205, 60),
		Safe = Color3.fromRGB(255, 205, 60),
		Refund = Color3.fromRGB(255, 205, 60),
		Reward = Color3.fromRGB(255, 205, 60),
		Ore = Color3.fromRGB(90, 190, 255),
		Crystal = Color3.fromRGB(150, 120, 255),
		Geode = Color3.fromRGB(150, 120, 255),
		Quest = Color3.fromRGB(120, 230, 90),
		Gift = Color3.fromRGB(255, 120, 200),
	},
	Icons = {
		Default = 110683384344203,
		Pending = 120240659165097,
		Shop = 136134431441322,
		Refund = 136134431441322,
		Rebirth = 136134431441322,
		Geode = 111678193128921,
		Error = 120240659165097,
		Alert = 120240659165097,
		Safe = 111678193128921,
		Money = 111678193128921,
		Quest = 107935543416033,
		Shield = 110683384344203,
		Ore = 110683384344203,
		Cart = 110683384344203,
		Boulder = 83667348714891,
		Pickaxe = 83667348714891,
		Crystal = 111678193128921,
		Gift = 107935543416033,
		Goblin = 85181849716719,
		Slow = 85181849716719,
		Stolen = 85181849716719,
		Reward = 107935543416033,
		Social = 110683384344203,
		Badge = 107935543416033,
		Skin = 107935543416033,
	},
}

--------------------------------------------------------------------------------
-- ХВАТ ЗА ТЕЛЕЖКУ (R6 IK) — пока держит тележку, руки визуально "прилипают"
-- к маркерам LeftHandGrip/RightHandGrip в её модели (см. PlaceholderFactory.
-- Cart — там же дефолтные позиции для плейсхолдера, и рандомный фолбэк на
-- клиенте, если маркеров нет вообще — см. CustomCartUI.client.lua). Вся
-- математика — там же (единственный клиентский скрипт в проекте). Поворот
-- и растяжение руки считаются ТОЧНО, без сглаживания и без верхнего предела
-- растяжения — рука должна быть прицеплена к тележке идеально всегда, без
-- зазоров, поэтому тут нет числовых настроек на подкрутку.
--------------------------------------------------------------------------------

--------------------------------------------------------------------------------
-- ОСТРОВА ПРОГРЕССИИ (см. server/Services/IslandService.lua,
-- client/IslandUI.client.lua, ISLANDS_GUIDE.md).
--
-- Наковальня жеод, подиум кристалла с сейфом, плавильня и ребёрт — ПОКУПКИ
-- у НПС в центре мира (Island Keeper). Покупка поднимает из-под земли
-- рядом с участком игрока свой остров.
--   Anvil   — наковальня: открытие жеод.
--   Income  — подиум кристалла + сейф (пассивный доход).
--   Smelter — плавильня: ОДНА руда → слиток той же руды с теми же
--             мутациями, цена × ValueMultiplier.
-- Ребёрт открывается только когда куплены ВСЕ острова из RebirthRequires.
--
-- ГДЕ СТОИТ ОСТРОВ. В PlotTemplate кладёшь деталь-маркер (имя — PlotMarker
-- ниже). PrimaryPart твоего макета острова встанет РОВНО в этот маркер —
-- позицией и поворотом. Поворот можно задать без Rotate: рядом деталь
-- "<ИмяМаркера>Look" — маркер "смотрит" на неё. Нет маркера — остров
-- встаёт в ряд позади участка (BehindDistance/Spacing).
--
-- КАК ВЫГЛЯДИТ ОСТРОВ. Макет — Model в ReplicatedStorage.Assets (имя —
-- Model ниже) с НАЗНАЧЕННЫМ PrimaryPart. Всё внутри (земля, декор, мосты
-- к участку) — твоё, код ничего не добавляет. Внутри макета —
-- маркеры построек (детали, лежащие НА поверхности; постройка встаёт на
-- нижнюю грань маркера, "<Имя>Look" — куда постройка смотрит лицом):
--   Anvil:   AnvilMarker  (+ AnvilMarkerLook)   — наковальня (Assets/GeodeBuilding)
--   Income:  PodiumMarker (+ PodiumMarkerLook)  — подиум (Assets/GeodePodium)
--            SafeMarker   (+ SafeMarkerLook)    — сейф (Assets/GeodeSafe)
--   Smelter: SmelterMarker (+ SmelterMarkerLook) — плавильня (Assets/Smelter, промпт на детали "Mouth")
--   (старое имя StationMarker у наковальни и плавильни тоже работает)
-- Нет макета — строится простой остров-плейсхолдер (без мостов).
--
-- Прочие ассеты: Ingot_<КлючРуды> или общий "Ingot" — модель слитка
-- (общий перекрашивается в цвет руды); IslandKeeperNPC — модель НПС.
-- Место НПС: workspace.IslandKeeperMarker (+ IslandKeeperMarkerLook),
-- иначе рядом с банком (KeeperOffset).
--------------------------------------------------------------------------------
--------------------------------------------------------------------------------
-- v20.25: МОСТЫ, ВЫЕЗЖАЮЩИЕ ИЗ-ПОД ЗЕМЛИ (client/BridgeRiseFX).
-- Любая модель в Workspace, чьё имя подходит под NamePattern ("Bridge",
-- "Bridge2", "BridgeToSmelter"…), по умолчанию спрятана под землёй. Игрок
-- подошёл ближе ShowDistance (стадов до края моста) — мост плавно
-- поднимается с пружинкой; отошёл дальше HideDistance — «подпрыгивает» и
-- уезжает обратно. Всё это ЛОКАЛЬНО у каждого игрока: каждый видит мост у
-- себя, по спрятанному мосту пройти нельзя. Со всем содержимым модели:
-- детали, декали, свет, частицы, надписи.
--------------------------------------------------------------------------------
Config.Bridges = {
	Enabled = true,
	NamePattern = "^Bridge",  -- Lua-шаблон имени модели
	ShowDistance = 38,        -- ближе — поднимается
	HideDistance = 52,        -- дальше — уходит (больше ShowDistance, чтобы не дёргался на границе)
	Depth = nil,              -- на сколько уходит вниз; nil = высота моста + 3
	RiseSeconds = 0.9,        -- подъём (с перелётом вверх и пружинкой)
	SinkSeconds = 0.75,       -- спуск (с подскоком перед уходом вниз)
	Overshoot = 1.6,          -- сила пружинки (EasingStyle.Back, 1.70 — стандарт)
	Stagger = 0.035,          -- задержка между частями моста (волна по доскам), сек; 0 — все разом
}

Config.Islands = {
	Enabled = true,
	Order = { "Anvil", "Income", "Smelter" },
	RebirthRequires = { "Anvil", "Income", "Smelter" },

	-- Старые игроки не должны терять то, чем уже пользовались: кто открывал
	-- жеоды / ставил кристалл — получает Anvil+Income бесплатно, у кого уже
	-- есть ребёрты — получает все острова. Выполняется один раз на профиль.
	GrandfatherExistingPlayers = true,

	Definitions = {
		Anvil = {
			DisplayName = "Anvil Island",
			Description = "Unlocks geode opening. Crack geodes to find crystals.",
			Tagline = "OPEN GEODES HERE",
			-- Что даёт — строки на экране выбранного улучшения у НПС.
			Perks = { "Open geodes from your vault", "Find crystals for your Income Island", "Needed for Prestige" },
			Cost = 250, -- v3: доступна сразу после первых рейсов
			Color = Color3.fromRGB(120, 170, 255),
			Icon = "⚒",
			Model = "Island_Anvil",          -- макет в ReplicatedStorage.Assets
			PlotMarker = "IslandAnvilMarker", -- маркер в PlotTemplate
			-- v20.25: ГДЕ СТОИТ ПОСТРОЙКА И КУДА СМОТРИТ. Offset — сдвиг от центра
			-- верха острова (X — вправо, Z — назад, стадов), Yaw — поворот в
			-- градусах вокруг вертикали (0 — «лицом» вперёд, как маркер острова
			-- на участке; 90 — влево; 180 — назад). Действует, если в модели
			-- острова НЕТ маркера с тем же именем (маркер главнее — его можно
			-- таскать и крутить мышкой в Studio, см. tools/AddIslandMarkers.lua).
			Stations = {
				AnvilMarker = { Offset = Vector3.new(0, 0, 0), Yaw = 0 }, -- наковальня жеод (+ AnvilMarkerLook - куда смотрит)
			},
		},
		Income = {
			DisplayName = "Income Island",
			Description = "Crystal podium + money safe. Your crystal earns money even while you're offline.",
			Tagline = "CRYSTAL INCOME + MONEY SAFE",
			Perks = { "Put a crystal on the podium", "It earns money - even offline", "Collect the cash from the safe", "Needed for Prestige" },
			Cost = 1500, -- v3
			Requires = "Anvil",
			Color = Color3.fromRGB(95, 230, 130),
			Icon = "$",
			Model = "Island_Income",
			PlotMarker = "IslandIncomeMarker",
			Stations = {
				PodiumMarker = { Offset = Vector3.new(-3.8, 0, 0), Yaw = 0 }, -- подиум кристалла (+ PodiumMarkerLook)
				SafeMarker = { Offset = Vector3.new(4.2, 0, 0), Yaw = 0 },    -- сейф (+ SafeMarkerLook)
			},
		},
		Smelter = {
			DisplayName = "Smelter Island",
			Description = "Smelt ore into ingots worth x10. Rarer ore takes longer - up to 10 minutes.",
			Tagline = "SMELT ORE INTO x10 INGOTS",
			Perks = { "Ore → ingot worth x10", "Keeps the ore and its mutations", "Upgrade to smelt up to 5 ores at once", "Needed for Prestige" },
			Cost = 5000, -- v3: к пещере 3-4, до первого ребёрта
			Color = Color3.fromRGB(255, 140, 60),
			Icon = "🔥",
			Model = "Island_Smelter",
			PlotMarker = "IslandSmelterMarker",
			Stations = {
				SmelterMarker = { Offset = Vector3.new(0, 0, 0), Yaw = 0 }, -- плавильня (+ SmelterMarkerLook)
			},
		},
	},

	-- Подписи над островами. Их видит ТОЛЬКО владелец (рисует его клиент,
	-- см. IslandUI). LabelHeight — на сколько студов ВЫШЕ верхней точки
	-- острова висит подпись: высоко, чтобы читалась, когда смотришь в небо.
	LabelHeight = 45,
	LabelMaxDistance = 1500,

	-- Раскладка по умолчанию, если маркеров в PlotTemplate нет (в системе
	-- координат участка: -Z смотрит на банк, "позади участка" — это +Z).
	BehindDistance = 16,
	Spacing = 24,
	Radius = 10,           -- радиус площадки у острова-плейсхолдера
	RiseSeconds = 3.2,     -- сколько остров выезжает из-под земли
	RiseDepth = 16,        -- минимум; остров всегда уходит под землю целиком

	-- НПС в центре мира.
	KeeperName = "Island Keeper",
	KeeperOffset = Vector3.new(-30, 0, 0), -- от банка, если нет IslandKeeperMarker
	KeeperPromptDistance = 12,

	Smelter = {
		-- Уровни печи: [1] — сразу после покупки острова, дальше — улучшения
		-- в карточке плавильни у Island Keeper. Slots — сколько руды плавится
		-- ОДНОВРЕМЕННО, SpeedMultiplier — множитель времени (меньше = быстрее).
		-- Каждый уровень — СВОЙ вид печи (Assets/Smelter_Level<N>, иначе
		-- плейсхолдер уровня) и катсцена "старая сжимается → новая вырастает".
		-- Слиток всё так же переплавляется только ОДИН раз.
		Levels = {
			{ Name = "Clay Furnace", Slots = 1, SpeedMultiplier = 1.0 },
			{ Name = "Brick Furnace", Slots = 2, SpeedMultiplier = 0.95, Cost = 25000 },
			{ Name = "Iron Forge", Slots = 3, SpeedMultiplier = 0.9, Cost = 150000 },
			{ Name = "Magma Foundry", Slots = 5, SpeedMultiplier = 0.85, Cost = 800000 },
		},
		-- Время плавки растёт с редкостью: от MinSeconds у самой простой руды
		-- до MaxSeconds у самой редкой (позиция в Config.OreChain). TimeCurve
		-- > 1 — простая руда плавится заметно быстрее, долго ждать приходится
		-- именно за редкую (за которую x20 и стоит ждать).
		MinSeconds = 60,
		MaxSeconds = 600,
		TimeCurve = 1.4,
		ValueMultiplier = 10, -- v3: было x20 — слиток ещё и идёт через комбо тележки, x20 обесценивал рейсы
		ReadyText = "SMELT SUCCESSFUL!",
		PromptDistance = 10,
	},
}


--------------------------------------------------------------------------------
-- ═══════════════════════ ФИЧИ v8 ═══════════════════════
-- 1) Престиж на очках (Config.Prestige, PrestigeService, PerkUI)
-- 2) Сундуки (Config.Chests, GearService)
-- 3) Динамит (Config.Dynamite, GearService)
-- 4) Мини-игра валунов (Config.BoulderGame, RockService, BoulderGameUI)
-- 5) Гоблинский рейд (Config.GoblinRaid, GoblinService)
-- 6) Баффы/дебаффы скинов (Config.SkinStats, Config.SkinBuffs, SkinUI)
--------------------------------------------------------------------------------

-- 4) МИНИ-ИГРА ВАЛУНОВ ---------------------------------------------------------
-- Первый удар киркой по валуну открывает панель справа от него: бегунок
-- ходит вверх-вниз, клик = удар с оценкой (Промах/Хорошо/Идеально).
-- Сколько ударов нужно — по разнице «тир валуна − тир кирки».
Config.BoulderGame = {
	Enabled = true,
	-- v14: ТЯЖЁЛЫЕ УДАРЫ. Кликов меньше (2/3/5 вместо 3/5/10), но каждый
	-- удар — событие: замах → хитстоп → FOV-панч → тряска → трещины.
	-- Сила удара зависит от попадания (GradePower): PERFECT бьёт вдвое
	-- сильнее обычного, поэтому идеальная серия ломает валун быстрее.
	HitsByDiff = { [-1] = 2, [0] = 3, [1] = 5 }, -- ≤ -2 → 1 удар без мини-игры
	InstantBelowDiff = -2,   -- валун на 2+ тира слабее — ломается с одного удара
	MaxDiffWithPickaxe = 1,  -- на 2+ тира сильнее — только динамитом
	StrikeCooldown = 0.95,   -- сек между ударами: замах+удар+откат должны доиграть
	GradePower = { Miss = 0.55, Good = 1, Perfect = 2 }, -- множитель прогресса удара
	-- Задержка от клика до «контакта» кирки с камнем. Сервер применяет урон
	-- ровно через это время, клиент в этот момент даёт хитстоп/FOV/тряску.
	ImpactDelay = 0.32,
	WindupFovDelta = -4,     -- FOV на замахе (отрицательное — наезд)
	HitStop = { Miss = 0.03, Good = 0.07, Perfect = 0.12 }, -- стоп-кадр на контакте, сек
	-- Замедление анимации персонажа во время удара (множитель скорости):
	-- замах → стоп-кадр (HitStop) → разгон → финальный удар почти замирает.
	AnimSlow = { Windup = 0.45, Recover = 0.55, RecoverSeconds = 0.2, Final = 0.15 },
	-- v20: после замедления анимация НЕ обрывается и не «щёлкает» обратно:
	-- плавно разгоняется до CatchUp (догоняет потерянное время), держит его
	-- CatchUpSeconds и мягко возвращается к обычной скорости за SettleSeconds.
	AnimRamp = { RampSeconds = 0.12, CatchUp = 1.3, CatchUpSeconds = 0.25, SettleSeconds = 0.2 },
	FovKick = { Miss = 2, Good = 7, Perfect = 12 },
	CameraShake = { Miss = 0.15, Good = 0.45, Perfect = 0.8 }, -- студы
	-- Финальный удар: слоу-мо (камера «замирает» и наезжает) перед разлётом.
	FinalPause = 0.55,
	FinalFovDelta = -14,
	-- Стадии трещин (подсветка изнутри): порог прогресса → яркость.
	CrackStages = { 0.25, 0.5, 0.75 },
	-- Анимация тяжёлого замаха (необязательно, 0 = обычный взмах кирки).
	StrikeAnimationId = 0,
	-- Серия PERFECT подряд: с Streak.Min — доп. ролл лута и бонус к шансу
	-- реликвии (RelicBonusPerStreak за каждый PERFECT сверх Min).
	Streak = { Min = 2, ExtraRolls = 1, RelicBonusPerStreak = 0.25 },
	RunnerCyclesPerSecond = 0.5, -- полных проходов бегунка вверх-вниз в секунду (v9: медленнее)
	RunnerSpeedPerTier = 0.03,   -- валун тяжелее → бегунок быстрее
	GoodWidth = 0.36,        -- доли высоты полосы (v9: шире — проще попасть)
	PerfectWidth = 0.12,
	Grades = { Miss = 0, Good = 0.6, Perfect = 1 },
	-- Итог = средняя оценка всех своих ударов по этому валуну.
	Results = {
		{ Min = 0.85, Label = "PERFECT BREAK!", MoneyMult = 1.3, ExtraRolls = 1, ChestMult = 2.5, Color = Color3.fromRGB(255, 215, 80) }, -- v20: MoneyMult было 1.6
		{ Min = 0.5,  Label = "GOOD BREAK",     MoneyMult = 1.0, ExtraRolls = 0, ChestMult = 1.0, Color = Color3.fromRGB(120, 255, 150) },
		{ Min = 0,    Label = "ROUGH BREAK",    MoneyMult = 0.6, ExtraRolls = 0, ChestMult = 0.5, Color = Color3.fromRGB(200, 200, 210) },
	},
	SessionRange = 24,       -- дальше отошёл — мини-игра закрывается
	SessionIdleTimeout = 10,
	LatencyWindow = 0.6,     -- сервер сверяет позицию бегунка за это окно (пинг)
	Tolerance = 0.05,
	UiVersion = 2, -- v9: карточка дропа в билдере
}

-- 3) ДИНАМИТ -------------------------------------------------------------------
Config.Dynamite = {
	Enabled = true,
	BuyAmounts = { 1, 5 },
	MaxStack = 50,           -- на каждый вид отдельно
	PlaceRange = 16,         -- дальность установки на валун
	PlaceFuse = 3.5,         -- сек до взрыва на валуне (v20.5: +1.5)
	ThrowRange = 45,
	ThrowFuse = 2.9,         -- v20.5: +1.5
	-- Взрыв на валуне: доля «прогресса разрушения» (1 = валун сломан).
	BoulderProgressByDiff = { [-9] = 1, [0] = 0.6, [1] = 0.45, [2] = 0.34, [3] = 0.2 }, -- ключ = максимальная разница тиров для строки
	MaxBoulderDiff = 3,
	ThrowBoulderRadius = 7,  -- брошенная шашка тоже цепляет валун рядом
	-- Значения по умолчанию (виды ниже переопределяют).
	Radius = 11,
	KnockSpeed = 55,
	KnockUp = 34,
	-- v20.43: игрока под щитом/в безопасной зоне взрыв всё равно слегка
	-- подкидывает (без рагдолла и без потери руды).
	SafeHop = { Speed = 16, Up = 26 },
	RagdollSeconds = 2.5,    -- v9: было 1 — рагдолл дольше
	DropCount = 1,

	-- v9: ВИДЫ ДИНАМИТА — маленький (старт), средний (мид), большой (лейт).
	-- Ключ = ключ снаряжения (data.Gear[key]). UnlockCave — с какой пещеры
	-- (апгрейд CAVE) вид продаётся в магазине. v4: цена фиксированная (Price) —
	-- ≈ 2.5–3 минуты дохода в пещере, где вид открывается. Cooldown — откат между ЛЮБЫМИ использованиями этого вида
	-- (бросок и установка на валун), виден на слоте хотбара.
	Order = { "Dynamite", "Dynamite_Medium", "Dynamite_Mega" },
	Types = {
		Dynamite = {
			DisplayName = "Small Dynamite", ShortName = "SMALL", Icon = "🧨", Color = Color3.fromRGB(215, 45, 45),
			UnlockCave = 1,
			Price = 120,
			Cooldown = 4,
			Fuse = 2.9,            -- сек от приземления до взрыва (v20.5: было 1.4, +1.5 по запросу)
			Visual = "Stick",      -- v16: Stick / Bundle (3 шашки, взрыв цепочкой) / Barrel (отсчёт 3-2-1)
			Radius = 10, BoulderPower = 1, ThrowBoulderPower = 0.5,
			KnockSpeed = 50, KnockUp = 32, RagdollSeconds = 2.5, DropCount = 1,
			ModelScale = 1,
		},
		Dynamite_Medium = {
			DisplayName = "Dynamite Bundle", ShortName = "MEDIUM", Icon = "🧨", Color = Color3.fromRGB(255, 120, 40),
			UnlockCave = 5,
			Price = 1500,
			Cooldown = 6,
			Fuse = 3.3,            -- v20.5: было 1.8
			Visual = "Bundle",
			Radius = 14, BoulderPower = 1.6, ThrowBoulderPower = 0.9,
			KnockSpeed = 68, KnockUp = 42, RagdollSeconds = 3.2, DropCount = 2,
			ModelScale = 1.4,
		},
		Dynamite_Mega = {
			DisplayName = "Mega TNT", ShortName = "LARGE", Icon = "💣", Color = Color3.fromRGB(255, 200, 40),
			UnlockCave = 10,
			Price = 20000,
			Cooldown = 10,
			Fuse = 4.7,            -- v20.5: было 3.2
			Visual = "Barrel",
			Radius = 19, BoulderPower = 2.5, ThrowBoulderPower = 1.4,
			KnockSpeed = 88, KnockUp = 52, RagdollSeconds = 4, DropCount = 3,
			ModelScale = 1.9,
		},
	},
}

for key, info in Config.Dynamite.Types do info.Key = key end

-- v16: ВИЗУАЛ ДИНАМИТА (client/DynamiteFX.client.lua). Полёт, пульсация и
-- взрыв рисуют клиенты — у всех плавно; сервер решает только «когда и где».
Config.Dynamite.Fx = {
	PulseFrom = 1.0,          -- размер в начале фитиля
	PulseTo = 1.25,           -- амплитуда «дыхания» к концу фитиля
	PulseStartHz = 2,         -- частота пульса в начале
	PulseEndHz = 9,           -- …и перед взрывом
	FinalInflate = 1.6,       -- раздувание прямо перед взрывом
	FinalHold = 0.08,         -- «замирает» на столько секунд
	FlashColor = Color3.fromRGB(255, 60, 60),
	BoomWords = { "BOOM!", "KABOOM!", "BLAM!" },
	ChainDelay = 0.1,         -- Bundle: пауза между тремя взрывами
	ShakeRadiusMult = 3,      -- тряска камеры у тех, кто ближе Radius × этого
	HitStop = 0.15,           -- K2: «замирание» пострадавшего перед отлётом
	-- K2: сила отброса растёт к эпицентру: × (1 + EpicenterBonus × близость).
	EpicenterBonus = 0.5,
	TumbleSpin = 10,          -- вращение в полёте
}

-- Вид динамита по ключу снаряжения (nil — не динамит).
function Config.DynamiteType(key)
	return Config.Dynamite.Types[key]
end

-- 2) СУНДУКИ -------------------------------------------------------------------
-- Выпадают из валунов (шанс × качество мини-игры × удача сундуков) и из
-- гоблинского рейда. Лежат в «снаряжении» (панель слева). Взял в руку →
-- клик по земле своего участка → сундук встал и идёт таймер. Таймер идёт
-- и оффлайн (os.time). Пропуск таймера — за Robux (SkipProductId).
-- Модели: ReplicatedStorage/Assets/Chests/<ModelName>. Нет модели —
-- цветной ящик-заглушка.
Config.Chests = {
	Enabled = true,
	Order = { "Common", "Rare", "Epic", "Legendary" },
	AssetFolderPath = { "Assets", "Chests" },
	MaxPlaced = 3,
	DropFromBoulder = { Common = 0.10, Rare = 0.03, Epic = 0.008, Legendary = 0.002 },
	-- v16: открытие = ПОЛНОЕ зажатие промпта (сек). Пока держишь — сундук
	-- трясётся, крышка приоткрывается, щели светятся; отпустил — всё
	-- откатывается назад. Лут вылетает в мир + лента справа (без окна).
	HoldSeconds = { Common = 1.5, Rare = 2.0, Epic = 2.5, Legendary = 3.0 },
	-- v20.58: ОТКРЫТЬ ДОСРОЧНО за деньги: SkipCartsPerMinute полной тележки
	-- пещеры игрока за каждую оставшуюся минуту, не меньше SkipMinCarts.
	-- false — только за Robux: Developer Product SkipProductId у типа
	-- сундука (цена на кнопке — SkipRobux). Пока SkipProductId = 0, кнопка
	-- видна, но покупка не открывается (в Output предупреждение).
	SkipWithMoney = false,
	SkipCartsPerMinute = 0.12,
	SkipMinCarts = 0.15,
	LootIcons = { Money = "💰", Geode = "🪨", Dynamite = "🧨", Buff = "✨", Skin = "⛏", PrestigePoint = "⭐", Relic = "🏆" },
	Types = {
		Common = {
			DisplayName = "Common Chest", ModelName = "Chest_Common", Color = Color3.fromRGB(190, 190, 200),
			OpenSeconds = 30, SkipProductId = 0, SkipRobux = 9, Rolls = 2,
			Loot = {
				{ Kind = "Money", Weight = 62, Carts = { 0.4, 1.2 } },
				{ Kind = "Geode", Weight = 22, Offset = 0 },
				{ Kind = "Dynamite", Weight = 13, Count = { 1, 2 } },
				{ Kind = "Buff", Weight = 2.7, Buff = "Luck", Amount = 0.25, Seconds = 180 },
				{ Kind = "Skin", Weight = 0.3 },
			},
		},
		Rare = {
			DisplayName = "Rare Chest", ModelName = "Chest_Rare", Color = Color3.fromRGB(70, 150, 255),
			OpenSeconds = 120, SkipProductId = 0, SkipRobux = 15, Rolls = 3,
			Loot = {
				{ Kind = "Money", Weight = 55, Carts = { 1, 2.5 } },
				{ Kind = "Geode", Weight = 22, Offset = 1 },
				{ Kind = "Dynamite", Weight = 15, Count = { 2, 3 } },
				{ Kind = "Buff", Weight = 7, Buff = "Luck", Amount = 0.4, Seconds = 300 },
				{ Kind = "Skin", Weight = 1 },
			},
		},
		Epic = {
			DisplayName = "Epic Chest", ModelName = "Chest_Epic", Color = Color3.fromRGB(175, 90, 255),
			OpenSeconds = 300, SkipProductId = 0, SkipRobux = 25, Rolls = 3,
			Loot = {
				{ Kind = "Money", Weight = 48, Carts = { 2, 5 } },
				{ Kind = "Geode", Weight = 24, Offset = 1 },
				{ Kind = "Dynamite", Weight = 14, Count = { 3, 5 } },
				{ Kind = "Buff", Weight = 11.5, Buff = "MutationPotion", Amount = 0.5, Seconds = 300 },
				{ Kind = "Skin", Weight = 2.5 },
			},
		},
		Legendary = {
			DisplayName = "Legendary Chest", ModelName = "Chest_Legendary", Color = Color3.fromRGB(255, 190, 50),
			OpenSeconds = 600, SkipProductId = 0, SkipRobux = 39, Rolls = 4,
			Loot = {
				{ Kind = "Money", Weight = 42, Carts = { 4, 10 } },
				{ Kind = "Geode", Weight = 22, Offset = 2 },
				{ Kind = "Dynamite", Weight = 12, Count = { 5, 8 } },
				{ Kind = "Buff", Weight = 12, Buff = "MutationPotion", Amount = 0.8, Seconds = 600 },
				{ Kind = "Skin", Weight = 6 },
				{ Kind = "PrestigePoint", Weight = 6 },
			},
		},
	},
	GearUiVersion = 1,
}

-- 1) ПРЕСТИЖ НА ОЧКАХ ----------------------------------------------------------
-- Лимитов на пещеру нет. Престиж доступен с пещеры MinCave, даёт очки
-- (тем больше, чем глубже зашёл). Очки тратятся в чемоданчике у NPC
-- ребёрта на перки — они НЕ сбрасываются никогда. Цена уровня перка
-- растёт: Cost(level) = floor(CostBase + level × CostGrowth).
-- v9: НАГРАДЫ КОЛЛЕКЦИИ — за каждую новую руду и каждую новую мутацию на
-- ней (книга ORE & MUTATIONS). Доли полной тележки текущей пещеры.
Config.Collection = {
	RewardOreCarts = 0.03,
	RewardMutationCarts = 0.05,
	MinReward = 25,
}

Config.Prestige = {
	Enabled = true,
	MinCave = 8,
	PointsByCave = { [8] = 1, [9] = 1, [10] = 2, [11] = 2, [12] = 3, [13] = 3, [14] = 4, [15] = 5 },
	-- v4: цена престижа ФИКСИРОВАННАЯ и растёт с числом престижей:
	-- CostBase × CostGrowth^(престижей сделано), не выше CostMax.
	-- 25K ≈ 10 минут дохода на пещере 8; 2.5M ≈ 35 минут на пещере 15.
	CostBase = 25000,
	CostGrowth = 1.45,
	CostMax = 2500000,
	CaseModelName = "PrestigeCase", -- ReplicatedStorage/Assets/<имя>; нет — заглушка-чемодан
	CaseOffset = CFrame.new(6, 0, 1),   -- относительно NPC ребёрта
	PerkUiVersion = 4, -- v4: вкладки PERKS / SHRINES
	-- v9: ДЕРЕВО. Перки идут ветками сверху вниз; следующий узел ветки
	-- открывается, когда у предыдущего UnlockLevel+ уровней. Первый узел
	-- каждой ветки открыт сразу.
	UnlockLevel = 1,
	Branches = {
		{ Id = "Economy", Title = "ECONOMY", Color = Color3.fromRGB(255, 190, 60),  Perks = { "Money", "Passive", "CartSpace" } },
		{ Id = "Fortune", Title = "FORTUNE", Color = Color3.fromRGB(90, 215, 110),  Perks = { "Luck", "Mutation", "GeodeLuck", "ChestLuck" } },
		{ Id = "Utility", Title = "UTILITY", Color = Color3.fromRGB(80, 160, 255),  Perks = { "Speed", "Dynamite", "HeadStart" } },
	},
	-- v20.107: ДЕРЕВО КАК НА РЕФЕРЕНСЕ. Позиции узлов в долях окна дерева
	-- (0..1, центр узла). Start - стартовый узел, от него линии к первому
	-- перку каждой ветки, дальше по порядку ветки. Нет TreeLayout - старые
	-- колонки. Закрытые узлы показывают «?».
	-- NodeImageId - картинка узла (например пятиугольник); 0 - круг.
	NodeImageId = 0,
	-- v20.118: дерево на весь экран поверх размытого мира, можно таскать
	-- мышью/пальцем (колесо - масштаб); TreeCanvas - размер полотна в
	-- пикселях (позиции TreeLayout - доли этого полотна); FullNodeSize - узлы.
	FullScreen = true,
	TreeCanvas = Vector2.new(1500, 1000),
	FullNodeSize = 96,
	DetailScale = 0.72,      -- v20.122: размер карточки перка (доля)
	DetailHideSeconds = 3,   -- v20.120: карточка перка (по клику/наведению) прячется через N с
	HideDeepLocked = true,   -- v20.120: за первым закрытым узлом ветки остальные не показываются
	PointIconId = 0, -- иконка очков престижа у чисел; 0 - нарисованный ромб
	StartText = "Your journey begins here.",
	TreeLayout = {
		Start     = { 0.50, 0.52 },
		Money     = { 0.36, 0.40 }, Passive  = { 0.22, 0.28 }, CartSpace = { 0.08, 0.16 },
		Luck      = { 0.64, 0.40 }, Mutation = { 0.76, 0.26 }, GeodeLuck = { 0.90, 0.14 }, ChestLuck = { 0.92, 0.42 },
		Speed     = { 0.50, 0.76 }, Dynamite = { 0.36, 0.88 }, HeadStart = { 0.20, 0.80 },
	},
	Perks = {
		{ Id = "Money",     Icon = "💰", Title = "Money",        Text = "+{v}% ore sell price",       PerLevel = 0.04, MaxLevel = 25, CostBase = 1, CostGrowth = 0.5, Percent = true },
		{ Id = "Luck",      Icon = "🍀", Title = "Luck",         Text = "+{v}% rare ore luck",        PerLevel = 0.03, MaxLevel = 20, CostBase = 1, CostGrowth = 0.5, Percent = true },
		{ Id = "Mutation",  Icon = "🧬", Title = "Mutations",    Text = "+{v}% mutation chance",      PerLevel = 0.05, MaxLevel = 20, CostBase = 1, CostGrowth = 0.5, Percent = true },
		{ Id = "CartSpace", Icon = "🎒", Title = "Backpack Space", Text = "+{v} backpack space",            PerLevel = 1,    MaxLevel = 15, CostBase = 1, CostGrowth = 0.6 },
		{ Id = "Speed",     Icon = "👟", Title = "Swift Feet",   Text = "+{v}% walk speed",           PerLevel = 0.02, MaxLevel = 10, CostBase = 1, CostGrowth = 0.7, Percent = true },
		{ Id = "Passive",   Icon = "🏦", Title = "Safe Income",  Text = "+{v}% passive income",       PerLevel = 0.06, MaxLevel = 20, CostBase = 1, CostGrowth = 0.5, Percent = true },
		{ Id = "GeodeLuck", Icon = "🪨", Title = "Geode Finder", Text = "+{v}% geode find chance",    PerLevel = 0.05, MaxLevel = 15, CostBase = 1, CostGrowth = 0.6, Percent = true },
		{ Id = "ChestLuck", Icon = "🎁", Title = "Treasure Nose",Text = "+{v}% chest drop chance",    PerLevel = 0.08, MaxLevel = 15, CostBase = 1, CostGrowth = 0.6, Percent = true },
		{ Id = "Dynamite",  Icon = "🧨", Title = "Demolition",   Text = "+{v}% dynamite power",       PerLevel = 0.08, MaxLevel = 10, CostBase = 1, CostGrowth = 0.7, Percent = true },
		{ Id = "HeadStart", Icon = "🚀", Title = "Head Start",   Text = "Start prestige at Cave {c}", PerLevel = 1,    MaxLevel = 4,  CostBase = 3, CostGrowth = 2 },
	},
}

-- v4: СВЯТИЛИЩА — особые тотемы за ОЧКИ ПРЕСТИЖА (вкладка SHRINES в
-- чемоданчике престижа). Покупаются один раз, лежат в инвентаре (вкладка
-- TOTEMS), ставятся на базу как обычные тотемы и НЕ сбрасываются при
-- престиже. Работают, пока стоят на базе:
--   Mutation — v17: РОВНО ОДНА из каждых Every (=3) руд, добытых в шахте,
--              ГАРАНТИРОВАННО получает мутацию Mutation. Какая именно из
--              трёх — случайно, но в каждой тройке ровно одна (счётчик и
--              выбранный слот сохраняются в профиле);
--   Luck / Income — постоянный бонус к удаче / цене продажи (сверх
--              потолков обычных тотемов Config.Placeables.Caps).
-- ID предмета: "Totem_Shrine_<Id>". Своя модель: ReplicatedStorage.Assets.<Asset>.
Config.Prestige.Shrines = {
	Order = { "Frost", "Toxic", "Molten", "Storm", "Void", "Golden", "Prismatic", "Celestial", "Fortune", "Midas" },
	Types = {
		Frost     = { DisplayName = "Frost Shrine",     Icon = "❄️", Kind = "Mutation", Mutation = "Frozen",    Every = 3,  Cost = 3,  Asset = "Shrine_Frost" },
		Toxic     = { DisplayName = "Toxic Shrine",     Icon = "☣️", Kind = "Mutation", Mutation = "Toxic",     Every = 3,  Cost = 4,  Asset = "Shrine_Toxic" },
		Molten    = { DisplayName = "Molten Shrine",    Icon = "🌋", Kind = "Mutation", Mutation = "Molten",    Every = 3,  Cost = 6,  Asset = "Shrine_Molten" },
		Storm     = { DisplayName = "Storm Shrine",     Icon = "⚡", Kind = "Mutation", Mutation = "Electric",  Every = 3,  Cost = 6,  Asset = "Shrine_Storm" },
		Void      = { DisplayName = "Void Shrine",      Icon = "🕳", Kind = "Mutation", Mutation = "Void",      Every = 3,  Cost = 8,  Asset = "Shrine_Void" },
		Golden    = { DisplayName = "Golden Shrine",    Icon = "👑", Kind = "Mutation", Mutation = "Golden",    Every = 3,  Cost = 10, Asset = "Shrine_Golden" },
		Prismatic = { DisplayName = "Prismatic Shrine", Icon = "🌈", Kind = "Mutation", Mutation = "Prismatic", Every = 3, Cost = 15, Asset = "Shrine_Prismatic" },
		Celestial = { DisplayName = "Celestial Shrine", Icon = "🌠", Kind = "Mutation", Mutation = "Celestial", Every = 3, Cost = 25, Asset = "Shrine_Celestial" },
		Fortune   = { DisplayName = "Fortune Idol",     Icon = "🍀", Kind = "Luck",   Value = 0.06, Cost = 5, Color = Color3.fromRGB(110, 235, 120), Asset = "Shrine_FortuneIdol" },
		Midas     = { DisplayName = "Midas Idol",       Icon = "💰", Kind = "Income", Value = 0.08, Cost = 8, Color = Color3.fromRGB(255, 205, 60),  Asset = "Shrine_MidasIdol" },
	},
}

-- 6) БАФФЫ И ДЕБАФФЫ СКИНОВ ----------------------------------------------------
-- Stat → как показывать. Значения в Config.SkinBuffs — ДОЛИ (0.1 = +10%).
Config.SkinStats = {
	Money     = { Label = "Ore sell price" },
	Luck      = { Label = "Rare ore luck" },
	Mutation  = { Label = "Mutation chance" },
	Speed     = { Label = "Walk speed" },
	Perfect   = { Label = "Boulder PERFECT zone" },
	Boulder   = { Label = "Boulder strike power" },
	Stagger   = { Label = "PvP knockdown power" },
	Toughness = { Label = "PvP toughness" },
	ChestLuck = { Label = "Chest drop chance" },
	Dynamite  = { Label = "Dynamite power" },
	Damage    = { Label = "Goblin damage" },
}
-- У каждого скина 2 плюса и 1 минус — чтобы был выбор, а не «лестница».
Config.SkinBuffs = {
	BigWoodenPickaxe   = { Boulder = 0.20, Damage = 0.10, Speed = -0.08 },
	CrystalPickaxe     = { Luck = 0.10, Perfect = 0.20, Toughness = -0.15 },
	LovePickaxe        = { Mutation = 0.15, Toughness = 0.10, Stagger = -0.15 },
	RadioactivePickaxe = { Stagger = 0.20, Mutation = 0.08, Speed = -0.06 },
	VoidPickaxe        = { Luck = 0.15, ChestLuck = 0.20, Money = -0.05 },
	AmethystPickaxe    = { Money = 0.05, Luck = 0.04, Perfect = -0.10 },
	CactusSword        = { Stagger = 0.15, Damage = 0.12, Luck = -0.06 },
	FishSkin           = { Money = 0.10, Speed = 0.05, Damage = -0.15 },
	TungTungStick      = { Stagger = 0.30, Boulder = 0.10, Perfect = -0.15 },
	BigMole            = { Boulder = 0.25, ChestLuck = 0.15, Speed = -0.10 },
	DevSword           = { Luck = 0.20, Money = 0.10, Toughness = -0.20 },
	Frostmorn          = { Perfect = 0.30, Toughness = 0.20, Money = -0.08 },
	Gold               = { Money = 0.15, ChestLuck = 0.10, Stagger = -0.20 },
	LikePickaxe        = { Money = 0.06, Speed = 0.06, Damage = -0.08 },
	GroupPickaxe       = { Luck = 0.06, Speed = 0.06, Boulder = -0.10 },
	GoldSword          = { Damage = 0.25, Stagger = 0.15, Luck = -0.08 },
	GoldKunai          = { Speed = 0.15, Perfect = 0.15, Money = -0.06 },
	CrystalSword       = { Luck = 0.08, Dynamite = 0.20, Speed = -0.05 },
}
Config.SkinUiVersion = 1

-- 5) ГОБЛИНСКИЙ ЛАГЕРЬ (v20.44, server/Services/GoblinCampService) -----------
-- Лагерь — Workspace/GoblinCamp:
--   GoblinCamp/Zone        — Part (невидимый), границы лагеря. Гоблины НИКОГДА
--                            не выходят из него.
--   GoblinCamp/Spawns/*    — Part'ы-точки появления (сколько угодно).
--   GoblinCamp/Marker      — (необязательно) Part, над которым висит табличка
--                            лагеря; нет — табличка над центром Zone.
-- Раз в IntervalSeconds — волна (Waves) по средней пещере игроков сервера.
-- Над лагерем табличка: таймер до волны, название, сила и ДРОП волны.
--
-- ДВИЖЕНИЕ — «поле направлений» (flow field): Zone делится на клетки
-- CellSize стадов, свободные клетки находятся один раз рейкастами. Для
-- каждой цели (игрок / точка дома) считается одно поле «куда шагнуть» на
-- ВСЕХ гоблинов сразу — толпа обходит препятствия и не толкается.
--
-- МОДЕЛИ И АНИМАЦИИ — свои: ReplicatedStorage.Assets.Goblin_<Тип>
-- (или Goblin_<Тип>_1.._3), тип из Config.Goblins.Types. Анимации — папка
-- Animations внутри модели (Animation: Idle, Walk, Run, Attack1..3, Hit,
-- Stun, Death) или Config.Goblins.Animations. Сервер только ставит атрибуты
-- (GoblinMoving/GoblinRunning/GoblinAttackSequence/GoblinHitSequence/
-- GoblinStunned/GoblinDead) — играет их GoblinAnimation.client.
Config.GoblinRaid = {
	Enabled = true,
	UseCampService = true,     -- лагерь (GoblinCampService); старый рейд удалён из конфига
	DisableRoadWaves = true,   -- гоблинов на дороге нет, только лагерь
	IntervalSeconds = 300,     -- волна раз в 5 минут
	AnnounceBefore = 20,
	-- v20.45: волна стоит, пока её не зачистят; следующая — через
	-- IntervalSeconds ПОСЛЕ зачистки.
	FirstWaveDelay = 90,       -- первая волна после старта сервера

	-- ИИ (все расстояния в стадах).
	Ai = {
		TickSeconds = 0.2,       -- как часто думает КАЖДЫЙ гоблин (тики разнесены)
		AggroRadius = 28,        -- замечает игрока внутри лагеря ближе этого
		DeaggroRadius = 40,      -- теряет цель дальше этого
		AttackRange = 5,         -- начинает замах с этого расстояния
		HitRange = 7,            -- удар долетает, если игрок ещё ближе этого
		AttackWindup = 0.55,     -- видимый замах, от которого можно отойти
		AttackCooldown = 1.6,
		WanderRadius = 16,       -- бродит вокруг своей точки
		WanderPause = { 1.5, 4 },-- постоять между прогулками, сек
		RunSpeedMult = 1.35,     -- бег за целью быстрее прогулки
		StunSeconds = 1.2,       -- оглушение от удара (каждый 3-й удар)
		StunEveryHits = 3,
		SeparationRadius = 3.2,  -- расходятся, чтобы не стоять друг в друге
		StuckSeconds = 1.6,      -- нет прогресса — прыжок и новый шаг
		DeathRagdollSeconds = 1.8, -- после смерти лежит рагдоллом
		DeathSinkSeconds = 1.2,    -- потом уходит под землю и исчезает
	},
	Flow = {
		CellSize = 4,
		MaxStep = 3.5,           -- перепад высоты между соседними клетками
		ClearHeight = 5,         -- столько места над землёй нужно гоблину
		RecomputeSeconds = 0.35, -- поле к игроку пересчитывается не чаще
	},

	-- ВОЛНЫ — только существующие гоблины (Config.Goblins.Types).
	--   Units   — { Тип, Сколько }; MinCave/MaxCave — средняя пещера сервера;
	--   HealthMult/DamageMult — сила волны; Drops — дроп, он же на табличке:
	--     PerKill = { MoneyCarts = {мин, макс}, Dynamite = шанс, Geode = шанс },
	--     Clear   = сундук за зачистку по доле урона (MinShare → Chest).
	Waves = {
		{ Id = "Scouts", Title = "GOBLIN SCOUTS", Color = Color3.fromRGB(210, 70, 70), MinCave = 1, MaxCave = 8, Weight = 30,
			Units = { { "Warrior", 6 } }, HealthMult = 0.8, DamageMult = 0.8,
			Drops = { PerKill = { MoneyCarts = { 0.10, 0.25 }, Dynamite = 0.15 },
				Clear = { { MinShare = 0.3, Chest = "Rare" }, { MinShare = 0.01, Chest = "Common" } } } },
		{ Id = "Thieves", Title = "GOBLIN THIEVES", Color = Color3.fromRGB(220, 175, 55), MinCave = 2, MaxCave = 12, Weight = 26,
			Units = { { "Thief", 7 } }, HealthMult = 0.8, DamageMult = 0.75,
			Drops = { PerKill = { MoneyCarts = { 0.15, 0.35 }, Dynamite = 0.2 },
				Clear = { { MinShare = 0.3, Chest = "Rare" }, { MinShare = 0.01, Chest = "Common" } } } },
		{ Id = "Warband", Title = "GOBLIN WARBAND", Color = Color3.fromRGB(230, 120, 60), MinCave = 4, MaxCave = 15, Weight = 22,
			Units = { { "Warrior", 3 }, { "Thief", 2 }, { "Berserker", 1 } }, HealthMult = 1, DamageMult = 1,
			Drops = { PerKill = { MoneyCarts = { 0.2, 0.4 }, Dynamite = 0.2, Geode = 0.08 },
				Clear = { { MinShare = 0.35, Chest = "Epic" }, { MinShare = 0.1, Chest = "Rare" }, { MinShare = 0.01, Chest = "Common" } } } },
		{ Id = "Brutes", Title = "GOBLIN BARBARIANS", Color = Color3.fromRGB(170, 95, 45), MinCave = 5, MaxCave = 15, Weight = 16,
			Units = { { "Berserker", 4 } }, HealthMult = 1.3, DamageMult = 1.2,
			Drops = { PerKill = { MoneyCarts = { 0.3, 0.55 }, Dynamite = 0.25, Geode = 0.1 },
				Clear = { { MinShare = 0.35, Chest = "Epic" }, { MinShare = 0.1, Chest = "Rare" }, { MinShare = 0.01, Chest = "Common" } } } },
		{ Id = "KingsGuard", Title = "THE GOBLIN KING", Color = Color3.fromRGB(165, 80, 210), MinCave = 7, MaxCave = 15, Weight = 10, Boss = true,
			Units = { { "King", 1 }, { "Warrior", 3 } }, HealthMult = 1.5, DamageMult = 1.2,
			Drops = { PerKill = { MoneyCarts = { 0.3, 0.6 }, Dynamite = 0.3, Geode = 0.15 }, BossMoneyMult = 5,
				Clear = { { MinShare = 0.35, Chest = "Legendary" }, { MinShare = 0.1, Chest = "Epic" }, { MinShare = 0.01, Chest = "Rare" } } } },
		{ Id = "Golden", Title = "GOLDEN GOBLIN KING", Color = Color3.fromRGB(255, 210, 60), MinCave = 9, MaxCave = 15, Weight = 4, Boss = true,
			Units = { { "Golden", 1 }, { "Berserker", 2 } }, HealthMult = 4, DamageMult = 1.3,
			Drops = { PerKill = { MoneyCarts = { 0.4, 0.8 }, Dynamite = 0.35, Geode = 0.2 }, BossMoneyMult = 8,
				Clear = { { MinShare = 0.1, Chest = "Legendary" }, { MinShare = 0.01, Chest = "Epic" } } } },
	},

	-- Табличка над лагерем (видна издалека).
	-- Размер таблички в стадах (Width × SignHeight); вплотную не раздувается.
	Marker = { Height = 22, MaxDistance = 900, Width = 26, SignHeight = 9 },

	-- ГОБЛИНЫ ДОБИЛИ ИГРОКА: не смерть, а пинок домой — рагдолл, полёт по
	-- дуге к своей базе с трейлом, посадка на базу (см. CombatService:GoblinKick).
	Kick = {
		FlightSeconds = 2.4,
		ArcHeight = 90,          -- насколько выше прямой идёт дуга
		Spin = 9,                -- кувырки в полёте (рад/с)
		RagdollAfterLanding = 1.2,
		HealOnLanding = 1.0,     -- доля здоровья после посадки
		TrailColors = { Color3.fromRGB(255, 90, 90), Color3.fromRGB(255, 220, 80), Color3.fromRGB(90, 220, 255) },
	},
}

--------------------------------------------------------------------------------
-- v14 — ЛУТ ИЗ ВАЛУНОВ (см. RockService:GrantBoulderRewards / spawnBaseBoulderOre)
--
-- Руда больше не телепортируется в точку над валуном: каждый кусок вылетает
-- по дуге (MineService:EjectToGround — тот же сквош/стретч, что у шахты),
-- с интервалом StaggerSeconds, ложится на пол по рейкасту и ПЕРВЫЕ
-- PickupDelay секунд не подбирается — игрок успевает увидеть, что выпало.
-- Редкая руда (BeamRarities) получает столб света цвета редкости
-- (client/LootBeamFX.client.lua).
--------------------------------------------------------------------------------
Config.BoulderLoot = {
	PickupDelay = 1.8,
	StaggerSeconds = 0.12,
	SpreadMin = 4,
	SpreadMax = 8.5,
	FlightSeconds = 0.75,
	ArcHeight = 7,
	RewardStagger = 0.18,     -- пауза между разными наградами одного валуна (монеты/жеода/кристалл)
	CrystalPromptDelay = 2.0, -- через сколько после приземления кристалл можно поднять
	BeamRarities = { Rare = true, Epic = true, Legendary = true, Mythic = true },
	-- Лента лута справа (client/LootFeed.client.lua).
	FeedMax = 6,
	FeedLifetime = 4.5,
	BannerRarities = { Epic = true, Legendary = true, Mythic = true, Secret = true },
}

--------------------------------------------------------------------------------
-- v14 — КАТСЦЕНА ЖЕОДЫ (client/GeodeUI.client.lua)
--
-- Игрок встаёт перед наковальней лицом к ней, в правой руке — молот
-- (ReplicatedStorage.Assets.GeodeHammer: Model/Part/Tool; ручка — часть
-- "Handle" или PrimaryPart, опционально Attachment "Grip"). Каждый клик
-- = один взмах анимацией Config.Geodes.HammerAnimationId (НЕ в цикле).
-- Контакт молота с жеодой — по маркеру анимации ImpactMarker, а если его
-- нет — через ImpactDelay. На каждом контакте FOV «панчит» сильнее
-- предыдущего, камера трясётся, жеода трескается. Последний удар — слоу-мо,
-- вспышка, раскол.
--------------------------------------------------------------------------------
Config.GeodeCutscene = {
	StandDistance = 3.6,          -- студов от центра наковальни до игрока
	PlayerScale = 1.35,           -- v20.114: было 2 - персонаж «скукоживался» (голова в теле); 1 = как есть
	ButtonSize = 104,             -- v20.106: квадратные кнопки AUTO и SKIP, пиксели
	HitSquash = 0.32,             -- v20.121: на сколько жеода сплющивается по высоте от удара (доля; 0 - выкл)
	HitSquashSeconds = 0.26,      -- длина сплющивания с пружинкой
	HammerAsset = "GeodeHammer",
	SwingSeconds = 0.8,           -- минимум между ударами (длина взмаха)
	ImpactDelay = 0.32,           -- контакт, если в анимации нет маркера
	ImpactMarker = "Hit",
	-- v20.79: камера медленно КРУТИТСЯ ВОКРУГ ИГРОКА (стартует из-за
	-- плеча). Центр кадра - между игроком и жеодой.
	OrbitRadius = 17,             -- стадов от центра кадра (v20.106: игрок крупнее - камера дальше)
	OrbitHeight = 7,              -- над центром кадра
	OrbitSpeed = 14,              -- градусов в секунду
	CameraOffset = Vector3.new(4.2, 4.4, 7.6), -- (старый кадр из-за плеча, не используется)
	CameraLookHeight = 1.2,
	-- АНИМАЦИИ ИГРОКА (вставь свои ID, 0 = нет):
	--   HammerAnimationId - ОДИН удар молотом (играется на каждый клик;
	--     момент контакта - маркер ImpactMarker в анимации, иначе ImpactDelay);
	--   IdleAnimationId - поза «держит молот» между ударами (в цикле).
	-- Пока ID удара 0 - игрок замахивается рукой сам (ArmSwing): рука вверх
	-- (SwingUpAngle) -> удар (SwingDownAngle) -> стойка (HoldAngle), молот
	-- в кисти летит вместе с рукой.
	HammerAnimationId = 74242390785908,
	IdleAnimationId = 0,
	-- v20.96: ТЕМП ЗАМАХА (доли пути до контакта с жеодой). Контакт - маркер
	-- ImpactMarker в анимации, иначе ImpactAt от длины клипа. От SwingSlowFrom
	-- до SwingSlowTo анимация идёт медленно (SwingSlowSpeed), потом рывком
	-- (SwingRushSpeed) до удара, после удара - обычная скорость.
	ImpactAt = 0.5,
	SwingSlowFrom = 0.35,
	SwingSlowTo = 0.75,
	SwingSlowSpeed = 0.35,
	SwingRushSpeed = 2.2,
	ArmSwing = true,
	SwingUpAngle = 165,
	SwingDownAngle = 55,
	HoldAngle = 25,
	-- v20.80: СТОП-КАДР удара - анимация и камера замирают на миг в момент
	-- контакта, потом тряска и осколки (последний удар - дольше).
	HitStop = 0.07,
	HitStopFinal = 0.14,
	-- v20.80: КОМБО - клик в течение ComboWindow сек после того, как молот
	-- освободился, продолжает серию («x2, x3...»); каждый шаг ускоряет
	-- взмах на ComboSpeedStep, не больше ComboMaxSpeed.
	ComboWindow = 0.7,
	ComboSpeedStep = 0.15,
	ComboMaxSpeed = 1.6,
	AutoHitDelay = 0.08,          -- автоудар (геймпасс AutoHammer): пауза после взмаха
	FovStart = 62,
	FovStepPerHit = -3,           -- с каждым ударом кадр чуть ближе
	KickBase = -5,                -- FOV-панч первого удара
	KickPerHit = -2.5,            -- каждый следующий сильнее
	ShakeBase = 0.22,
	ShakePerHit = 0.14,
	FinalHold = 0.5,              -- слоу-мо перед расколом
	FinalFov = 42,
	FlashBrightness = 0.55,
}

--------------------------------------------------------------------------------
-- v14 — ТОТЕМЫ, ДЕКОР И РЕЛИКВИИ НА БАЗЕ (см. BaseDecorService, PlaceableCatalog)
--
-- Всё лежит в ОБЫЧНОМ инвентаре (data.Gear, вкладки TOTEMS/DECOR/RELICS).
-- Взял в руку → призрак следует за курсором (R — поворот), клик —
-- поставить. Только на землю своего участка (shared/GroundCheck), сколько
-- угодно штук. Поднять — ЗАЖАТЬ E у предмета (PickupHoldDuration) →
-- обратно в инвентарь. Позиции хранятся относительно участка.
--
-- ТОТЕМЫ (тиры 1..10, баффы действуют, пока тотем стоит на базе; ставить
-- можно сколько угодно, суммарный эффект ограничен потолками Caps):
--   Fortune — удача +2% за тир (T1 +2% ... T10 +20%);
--   Ember   — доход с продажи +1% за тир (T10 = +10%);
--   Quake   — базовые валуны респавнятся быстрее: −6% времени за тир;
--   Prism   — шанс ОДНОЙ конкретной мутации ×(1 + 15% за тир).
--------------------------------------------------------------------------------
Config.Placeables = {
	MinSpacing = 2.2,
	GridStep = 0.5,
	RotateStep = 45,
	PickupHoldDuration = 1.2,
	PlaceRange = 60,            -- как далеко от игрока можно ставить
	-- v14.4: ставить можно на ЛЮБУЮ поверхность участка. На поверхности
	-- положе UprightSlope (градусы) предмет стоит вертикально, на более
	-- крутой (стена, склон, потолок) — прилипает к ней по нормали.
	UprightSlope = 40,
	-- Территория участка = весь прямоугольник PlotTemplate + этот запас, стадов.
	PlotMargin = 1,
	Caps = { Luck = 0.5, Income = 0.5, BoulderRespawn = 0.7, Mutation = 2.0 },
	-- v20.43: ТРИ ТИРА ТОТЕМОВ — начало, середина и конец игры (вариант А):
	-- 4 типа × 3 тира = 12 тотемов (+10 святилищ за престиж = 22).
	--   Early — пещеры 1–5, Mid — 6–10, Late — 11–15 (TierHomeCave).
	-- Сила тотема задаёт Values[тир] у типа (доля: 0.04 = +4%).
	-- v20.53: Names[тир] — название тотема в игре (без Early/Mid/Late).
	-- Старые сейвы (тиры 1..10 и Prism на конкретную мутацию) переводятся
	-- автоматически (BaseDecorService, migrate: T1-3 → Early, T4-7 → Mid, T8-10 → Late).
	TierNames = { "Early", "Mid", "Late" },
	TierRarity = { "Uncommon", "Epic", "Legendary" },
	TierColors = {
		Color3.fromRGB(110, 230, 120),
		Color3.fromRGB(190, 100, 255),
		Color3.fromRGB(255, 190, 50),
	},
	-- Цена тотема = TierPrices[тир] × PriceMult типа (округление до 2 значащих цифр).
	TierPrices = { 600, 8000, 190000 },
	TierHomeCave = { 1, 6, 11 },
	TotemTypes = {
		Fortune = { DisplayName = "Fortune Totem", Names = { "Luck Totem 1", "Luck Totem 2", "Luck Totem 3" }, Icon = "🍀", Color = Color3.fromRGB(110, 235, 120), Effect = "Luck",           Values = { 0.04, 0.10, 0.20 }, PriceMult = 1.0, Asset = "Totem_Fortune" },
		Ember   = { DisplayName = "Ember Totem", Names = { "Income Totem 1", "Income Totem 2", "Income Totem 3" },   Icon = "🔥", Color = Color3.fromRGB(255, 130, 50),  Effect = "Income",         Values = { 0.02, 0.05, 0.10 }, PriceMult = 1.5, Asset = "Totem_Ember" },
		Quake   = { DisplayName = "Quake Totem", Names = { "Boulder Totem 1", "Boulder Totem 2", "Boulder Totem 3" },   Icon = "🪨", Color = Color3.fromRGB(170, 140, 110), Effect = "BoulderRespawn", Values = { 0.12, 0.30, 0.60 }, PriceMult = 0.8, Asset = "Totem_Quake" },
		-- Prism теперь один на ВСЕ мутации из PrismMutations: шанс каждой ×(1 + Value).
		Prism   = { DisplayName = "Prism Totem", Names = { "Mutation Totem 1", "Mutation Totem 2", "Mutation Totem 3" },   Icon = "🔮", Color = Color3.fromRGB(200, 120, 255), Effect = "Mutation",       Values = { 0.20, 0.50, 1.00 }, PriceMult = 1.2, Asset = "Totem_Prism" },
	},
	TotemOrder = { "Fortune", "Ember", "Quake", "Prism" },
	-- Какие мутации усиливает Prism-тотем.
	PrismMutations = { "Frozen", "Toxic", "Void", "Electric", "Molten", "Golden", "Prismatic", "Celestial" },
	-- Сколько РАЗНЫХ тотемов каждого тира в стоке за цикл.
	-- v20.105: все 4 типа каждого тира - всегда в стоке (раньше 3 из 4
	-- случайных, и какого-то тотема не было).
	TotemsPerTier = 4,
	ShowAllTotemTiers = true, -- v20.105: во вкладке TOTEMS видны все тиры (раньше только свой ±1)
	TierWeights = { 30, 22, 15, 11, 8, 5.5, 3.5, 2.5, 1.5, 1 }, -- legacy, v4 не использует
	-- ДЕКОР — без эффектов, чисто для красоты. Asset — своя модель в
	-- ReplicatedStorage.Assets (пивот у основания), иначе плейсхолдер.
	Decor = {
		-- v20.51: фонарь — обычный (частый), синее пламя (реже), зелёное (ультраредкий, дорогой).
		IronLantern      = { DisplayName = "Lantern",              Icon = "🏮", Rarity = "Common",    Price = 400,    Asset = "Decor_IronLantern" },
		IronLanternBlue  = { DisplayName = "Blue Flame Lantern",   Icon = "🔵", Rarity = "Rare",      Price = 8000,   Asset = "Decor_IronLantern_Blue", StockChance = 0.2 },
		IronLanternGreen = { DisplayName = "Green Flame Lantern",  Icon = "🟢", Rarity = "Legendary", Price = 350000, Asset = "Decor_IronLantern_Green", StockChance = 0.03 }, -- ~1 цикл из 33
		CrystalLantern = { DisplayName = "Crystal Lantern", Icon = "💡", Rarity = "Uncommon",  Price = 2000,  Asset = "Decor_CrystalLantern" },
		-- v20.49: бочка с рудой заменена голубой друзой (старые бочки в сейвах
		-- превращаются в неё сами, см. BaseDecorService migrate).
		CrystalBlue    = { DisplayName = "Blue Crystal Cluster",   Icon = "💎", Rarity = "Uncommon", Price = 2500,  Asset = "Decor_CrystalCluster_Blue" },
		CrystalCluster = { DisplayName = "Purple Crystal Cluster", Icon = "🔮", Rarity = "Rare",     Price = 20000, Asset = "Decor_CrystalCluster_Purple" },
		MinerStatue    = { DisplayName = "Miner Statue",    Icon = "🗿", Rarity = "Epic",      Price = 80000, Asset = "Decor_MinerStatue" },
		MoleStatue     = { DisplayName = "Golden Mole Statue", Icon = "🏆", Rarity = "Legendary", Price = 400000, Asset = "Decor_MoleStatue" },
		PlushMole      = { DisplayName = "Plush Mole",      Icon = "🧸", Rarity = "Rare",      Price = 6000,  Asset = "Decor_PlushMole" },
		-- v20.22: растения, скамейка и «рабочий» декор. Function:
		--   "Seat"    — промпт SIT сажает на Seat внутри модели (сесть может любой);
		--   "Storage" — сундук-хранилище руды, своё окно (Storage.Slots ячеек);
		--   "Jar"     — банка-витрина: кладёшь 1 руду, она крутится внутри,
		--               над банкой — редкость.
		Flowers1       = { DisplayName = "Tulip Patch",     Icon = "🌷", Rarity = "Common",    Price = 150,   Asset = "Decor_Flowers1" },
		Flowers2       = { DisplayName = "Sunflower Pot",   Icon = "🌻", Rarity = "Common",    Price = 250,   Asset = "Decor_Flowers2" },
		Flowers3       = { DisplayName = "Lavender Box",    Icon = "💜", Rarity = "Common",    Price = 300,   Asset = "Decor_Flowers3" },
		Flowers4       = { DisplayName = "Daisy Bed",       Icon = "🌼", Rarity = "Uncommon",  Price = 400,   Asset = "Decor_Flowers4" },
		Bush1          = { DisplayName = "Round Bush",      Icon = "🌿", Rarity = "Common",    Price = 200,   Asset = "Decor_Bush1" },
		Bush2          = { DisplayName = "Berry Bush",      Icon = "🌳", Rarity = "Uncommon",  Price = 500,   Asset = "Decor_Bush2" },
		Bench          = { DisplayName = "Wooden Bench",    Icon = "🪑", Rarity = "Uncommon",  Price = 800,   Asset = "Decor_Bench",        Function = "Seat" },
		StorageChest   = { DisplayName = "Storage Chest",   Icon = "📦", Rarity = "Rare",      Price = 5000,  Asset = "Decor_StorageChest", Function = "Storage", AlwaysInStock = true },
		OreJar         = { DisplayName = "Ore Jar",         Icon = "🏺", Rarity = "Uncommon",  Price = 1500,  Asset = "Decor_OreJar",       Function = "Jar", AlwaysInStock = true },
	},
	DecorOrder = { "Flowers1", "Bush1", "Flowers2", "Flowers3", "Flowers4", "IronLantern", "CrystalBlue", "Bush2", "Bench", "OreJar", "CrystalLantern", "IronLanternBlue", "StorageChest", "PlushMole", "CrystalCluster", "MinerStatue", "MoleStatue", "IronLanternGreen" },
	DecorWeights = { Flowers1 = 30, Bush1 = 28, Flowers2 = 26, Flowers3 = 24, Flowers4 = 22, IronLantern = 30, IronLanternBlue = 10, IronLanternGreen = 1, CrystalBlue = 22, Bush2 = 20, Bench = 20, OreJar = 18, CrystalLantern = 18, StorageChest = 14, PlushMole = 12, CrystalCluster = 9, MinerStatue = 4, MoleStatue = 2 },
	-- v20.22: сундук-хранилище (Decor Function = "Storage"). Slots — ячеек,
	-- в каждой стопка одной руды (как в рюкзаке, до Inventory.StackSize).
	-- Руда в сундуке НЕ теряется при смерти. Поднять сундук можно только пустым.
	Storage = { Slots = 10, UseDistance = 14 },
	-- v20.22: банка (Function = "Jar"): руда внутри ужимается до OreSize
	-- стадов и крутится (SpinSpeed рад/с) — вращение на клиенте (DecorJarSpin).
	Jar = { OreSize = 1.1, SpinSpeed = 1.2, BobHeight = 0.12 },
}

--------------------------------------------------------------------------------
-- v14 — РЕЛИКВИИ-ТРОФЕИ (см. BaseDecorService)
--
-- Сверхредкий дроп из валунов (и гарантированный — из Золотого валуна).
-- Каждая реликвия получает ГЛОБАЛЬНЫЙ серийный номер (DataStore, общий для
-- всех серверов): «Crowned Mole Skull #14». Ставится на базе на постамент
-- с табличкой «найдено: ИМЯ». Пока стоит — даёт небольшой бонус к доходу
-- (IncomeBonus), поэтому выбор «держать или продать» — настоящий.
--
-- Падают ТОЛЬКО с валунов и из сундуков (ChestMultiplier), не продаются и
-- не покупаются. Лежат в инвентаре (вкладка RELICS), ставятся на базу
-- сколько угодно, как тотемы.
--
-- Своя модель: ReplicatedStorage.Assets.<Asset> — Model с PrimaryPart
-- (или частью "Root"), пивот у основания. Все ParticleEmitter, Attachment,
-- Beam, Light внутри сохраняются как есть.
--------------------------------------------------------------------------------
Config.Relics = {
	Order = { "GoldenPickaxeTrophy", "CrownedMoleSkull", "DragonEggFossil", "HeartOfTheMountain" },
	Types = {
		GoldenPickaxeTrophy = { DisplayName = "Golden Pickaxe Trophy", Icon = "🏆", Rarity = "Epic",      Chance = 1 / 5000,   IncomeBonus = 0.02, Color = Color3.fromRGB(255, 205, 70),  Asset = "Relic_GoldenPickaxeTrophy" },
		CrownedMoleSkull    = { DisplayName = "Crowned Mole Skull",    Icon = "💀", Rarity = "Legendary", Chance = 1 / 20000,  IncomeBonus = 0.04, Color = Color3.fromRGB(240, 230, 200), Asset = "Relic_CrownedMoleSkull" },
		DragonEggFossil     = { DisplayName = "Dragon Egg Fossil",     Icon = "🥚", Rarity = "Mythic",    Chance = 1 / 75000,  IncomeBonus = 0.07, Color = Color3.fromRGB(255, 90, 60),   Asset = "Relic_DragonEggFossil" },
		HeartOfTheMountain  = { DisplayName = "Heart of the Mountain", Icon = "❤️‍🔥", Rarity = "Secret",    Chance = 1 / 250000, IncomeBonus = 0.12, Color = Color3.fromRGB(255, 60, 140),  Asset = "Relic_HeartOfTheMountain", GlobalAnnounce = true },
	},
	RarityColors = { Secret = Color3.fromRGB(255, 60, 140) },
	TierChanceBonus = 0.06,        -- +6% к шансу за каждый тир валуна выше первого
	PlotBoulderMultiplier = 0.5,   -- личные валуны на базе — вдвое реже
	PerfectMultiplier = 1.5,       -- PERFECT BREAK
	-- Золотой валун: гарантированная реликвия тому, кто добил, по этим весам.
	GoldenWeights = { GoldenPickaxeTrophy = 70, CrownedMoleSkull = 24, DragonEggFossil = 5.2, HeartOfTheMountain = 0.8 },
	-- Сундуки: множитель к базовым шансам реликвии по редкости сундука.
	ChestMultiplier = { Common = 1, Rare = 2.5, Epic = 6, Legendary = 15 },
	SerialDataStore = "RelicSerials_v2", -- v20.88: номера реликвий заново с #1 (вайп)
}

--------------------------------------------------------------------------------
-- v14 — ЗОЛОТОЙ ВАЛУН (событие, см. RockService:_startGoldenBoulder)
--
-- Раз в 15–25 минут один из валунов на карте становится золотым: светится,
-- виден издалека, анонс всему серверу. Ударов нужно в HitsMultiplier раз
-- больше, прогресс общий — за него идёт гонка. Каждый, кто бил, получает
-- лут с множителем денег MoneyMult; тот, кто ДОБИЛ, — гарантированную
-- реликвию (Config.Relics.GoldenWeights), остальные — шанс ContributorRelicChance.
--------------------------------------------------------------------------------
Config.GoldenBoulder = {
	Enabled = true,
	FirstDelay = 5 * 60,
	IntervalMin = 15 * 60,
	IntervalMax = 25 * 60,
	LifetimeSeconds = 5 * 60,      -- не добили — золото гаснет, валун становится обычным
	HitsMultiplier = 2.5,
	MoneyMult = 5,
	ExtraRolls = 2,
	ContributorRelicChance = 0.15,
	Color = Color3.fromRGB(255, 200, 40),
	ShowBeam = false, -- v20.35: столб света над валуном (выключен — был «колхозным»)
	BeamHeight = 120,
}

--------------------------------------------------------------------------------
-- v14 — ЛАВКА: вкладки, лимитированная кирка, товары для базы, продажа реликвий
--------------------------------------------------------------------------------
-- v20.104: 3 вкладки - общий магазин, тотемы, декор (купленное падает в
-- обычный инвентарь).
Config.Merchant.Tabs = {
	{ Id = "Ore", Label = "ORE" }, -- v20.109: главная вкладка - руда для шахты
	{ Id = "Shop", Label = "SHOP" },
	{ Id = "Totems", Label = "TOTEMS" },
	{ Id = "Decor", Label = "DECOR" },
}
Config.Merchant.BaseOffers = {
	TotemSlots = 6, -- legacy: v4 катает Config.Placeables.TotemsPerTier на каждый тир
	DecorSlots = 3, -- legacy: с v20.27 мебель показывается вся (см. ниже)
	TotemStock = { 1, 2 },
	DecorStock = { 1, 3 },
	-- v20.27: шанс мебели оказаться в стоке цикла — от DecorMinChance (самая
	-- редкая по DecorWeights) до DecorMaxChance (самая частая). Своё число —
	-- Config.Placeables.Decor.<Id>.StockChance. Не в стоке — видна затемнённой.
	-- Decor.<Id>.AlwaysInStock = true — всегда в стоке и не кончается.
	DecorMinChance = 0.12,
	DecorMaxChance = 0.8,
}
-- ЛИМИТИРОВАННАЯ КИРКА ЦИКЛА. С шансом Chance в цикле появляется ОДНА
-- кирка из Pool (только из тех, у кого есть ассет). Ушедшая не возвращается
-- CooldownCycles циклов. Сток — 1 на игрока. Никогда не выпадает из жеод.
-- Если ни у одной кирки из Pool ещё нет ассета — берётся FallbackPool.
Config.Merchant.Limited = {
	Enabled = true,
	Chance = 0.65,
	CooldownCycles = 6,
	Pool = { "LimitedSunforge", "LimitedAbyssal", "LimitedCandyCane", "LimitedRuneblade", "LimitedPrismBreaker" },
	FallbackPool = { "TungTungStick", "BigMole", "GoldSword", "GoldKunai" },
	PriceByRarity = { Rare = 120000, Epic = 400000, Legendary = 1500000, Mythic = 5000000 }, -- v4: фиксированные
}
do
	local defs = Config.Skins.Definitions
	defs.LimitedSunforge     = { Kind = "Pickaxe", DisplayName = "Sunforge Pickaxe",  Rarity = "Legendary", AssetName = "Skin_Pickaxe_Sunforge",     ImageId = 0, NpcExclusive = true, MerchantLimited = true }
	defs.LimitedAbyssal      = { Kind = "Pickaxe", DisplayName = "Abyssal Pick",      Rarity = "Mythic",    AssetName = "Skin_Pickaxe_Abyssal",      ImageId = 0, NpcExclusive = true, MerchantLimited = true }
	defs.LimitedCandyCane    = { Kind = "Pickaxe", DisplayName = "Candy Cane Pick",   Rarity = "Epic",      AssetName = "Skin_Pickaxe_CandyCane",    ImageId = 0, NpcExclusive = true, MerchantLimited = true }
	defs.LimitedRuneblade    = { Kind = "Pickaxe", DisplayName = "Runeblade",         Rarity = "Legendary", AssetName = "Skin_Pickaxe_Runeblade",    ImageId = 0, NpcExclusive = true, MerchantLimited = true }
	defs.LimitedPrismBreaker = { Kind = "Pickaxe", DisplayName = "Prism Breaker",     Rarity = "Mythic",    AssetName = "Skin_Pickaxe_PrismBreaker", ImageId = 0, NpcExclusive = true, MerchantLimited = true }
end

--------------------------------------------------------------------------------
-- v18: УНИКАЛЬНЫЙ ЛУТ. У каждого источника своя «профессия», его дроп больше
-- нигде не выпадает (кроме денег):
--   ЖЕОДЫ   — недра земли: кристаллы на подиум, деньги, ЭССЕНЦИИ МУТАЦИЙ
--             (наносятся на кристалл подиума), СЕРДЦЕ ЖЕОДЫ (след. жеода ×3).
--             Скинов и баффов в жеодах больше нет.
--   СУНДУКИ — сокровища: деньги, ПИРАТСКИЕ СКИНЫ (только из сундуков),
--             АМУЛЕТЫ (эффекты, которых нет у зелий), очко престижа.
--             Жеод, динамита и баффов в сундуках больше нет.
-- Шансы считает shared/DropTables.lua — ОДИН модуль и для сервера (ролл),
-- и для окна шансов (client/DropPreviewUI), поэтому показанное = реальное.
--------------------------------------------------------------------------------

-- ЖЕОДЫ: доли категорий (одинаковые для всех типов жеод).
Config.Geodes.Drops = {
	Crystal = 0.55,  -- кристалл на подиум (поровну между Ores типа)
	Money = 0.33,    -- делится 70/25/5 между Money[1..3]
	Essence = 0.11,  -- эссенция мутации (пул — Essence.ByGeode)
	Heart = 0.01,    -- сердце жеоды
}
Config.Geodes.MoneySplit = { 0.70, 0.25, 0.05 }
Config.Geodes.BuffChance = 0 -- баффы из жеод убраны

-- ЭССЕНЦИИ МУТАЦИЙ. Лежат в инвентаре (снаряжение "Essence_<Мутация>").
-- Подходишь к своему подиуму с установленным кристаллом → промпт
-- «APPLY ESSENCE» → кристалл получает эту мутацию (новая ячейка коллекции,
-- доход × множитель мутации). Держишь эссенцию в руке — наносится она,
-- иначе самая редкая из имеющихся, которой у кристалла ещё нет.
Config.Geodes.Essence = {
	MaxPerCrystal = 2, -- сколько мутаций максимум может быть на одном кристалле
	-- Пул по типу жеоды: { мутация, вес }. Чем дороже жеода — тем редкие мутации.
	ByGeode = {
		Stone       = { { "Mossy", 70 },    { "Rusty", 30 } },
		Crystal     = { { "Cracked", 70 },  { "Frozen", 30 } },
		Amber       = { { "Frozen", 60 },   { "Soaked", 40 } },
		Topaz       = { { "Soaked", 60 },   { "Toxic", 40 } },
		Jade        = { { "Toxic", 60 },    { "Void", 40 } },
		Onyx        = { { "Void", 60 },     { "Electric", 40 } },
		Aurora      = { { "Electric", 55 }, { "Molten", 45 } },
		Nebula      = { { "Molten", 55 },   { "Sanguine", 30 }, { "Golden", 15 } },
		Quasar      = { { "Golden", 55 },   { "Radiant", 35 },  { "Glitched", 10 } },
		Singularity = { { "Radiant", 50 },  { "Prismatic", 35 }, { "Celestial", 15 } },
	},
}

-- СЕРДЦЕ ЖЕОДЫ: копится в профиле; следующая открытая жеода даёт Rewards наград.
Config.Geodes.Heart = { Rewards = 3, DisplayName = "Geode Heart", Icon = "💖", Color = Color3.fromRGB(255, 90, 170) }

-- Скины из жеод больше НЕ выпадают.
for geodeType in Config.Skins.DropChance do
	Config.Skins.DropChance[geodeType] = 0
end

-- АМУЛЕТЫ (charms) — только из сундуков. Работают как зелья: лежат в
-- инвентаре, берёшь в руку и жмёшь — активируются. Эффекты уникальные:
--   Midas Touch      — 5 мин: каждая добытая руда на 1 вариацию лучше (I→II→III);
--   Mutation Magnet  — следующие 5 руд из шахты гарантированно с мутацией;
--   Double Haul      — 5 мин: из шахты вылетает вдвое больше руды.
Config.Potions.Types.Charm_Midas = { Buff = "MidasTouch", Amount = 1, Seconds = 300, DisplayName = "Midas Touch Charm", Icon = "🪙", Color = Color3.fromRGB(255, 205, 60), Charm = true, Rarity = "Rare" }
Config.Potions.Types.Charm_Magnet = { Buff = "MutationMagnet", Amount = 5, Seconds = 600, DisplayName = "Mutation Magnet Charm", Icon = "🧲", Color = Color3.fromRGB(215, 120, 255), Charm = true, Rarity = "Epic" }
Config.Potions.Types.Charm_DoubleHaul = { Buff = "DoubleHaul", Amount = 1, Seconds = 300, DisplayName = "Double Haul Charm", Icon = "⛏", Color = Color3.fromRGB(90, 220, 255), Charm = true, Rarity = "Legendary" }
Config.Charms = {
	Order = { "Charm_Midas", "Charm_Magnet", "Charm_DoubleHaul" },
	-- Вес амулета внутри категории «амулет» по редкости сундука.
	Weights = {
		Common    = { Charm_Midas = 80, Charm_Magnet = 18, Charm_DoubleHaul = 2 },
		Rare      = { Charm_Midas = 60, Charm_Magnet = 30, Charm_DoubleHaul = 10 },
		Epic      = { Charm_Midas = 45, Charm_Magnet = 35, Charm_DoubleHaul = 20 },
		Legendary = { Charm_Midas = 30, Charm_Magnet = 38, Charm_DoubleHaul = 32 },
	},
}
for _, key in Config.Charms.Order do
	table.insert(Config.Potions.Order, key)
end
Config.Buffs.MidasTouch = {
	DisplayName = "MIDAS TOUCH", Amount = 1, Rarity = "Rare", ImageId = 0, IconText = "MT",
	Color = Color3.fromRGB(255, 205, 60), Description = "Every ore you mine rolls one variation higher (I → II → III).",
}
Config.Buffs.MutationMagnet = {
	DisplayName = "MUTATION MAGNET", Amount = 5, Rarity = "Epic", ImageId = 0, IconText = "MG",
	Color = Color3.fromRGB(215, 120, 255), Description = "Your next mined ores are guaranteed to have a mutation.",
}
Config.Buffs.DoubleHaul = {
	DisplayName = "DOUBLE HAUL", Amount = 1, Rarity = "Legendary", ImageId = 0, IconText = "x2",
	Color = Color3.fromRGB(90, 220, 255), Description = "Mines eject twice as much ore.",
}

-- ПИРАТСКИЙ КЛАД — скины кирок ТОЛЬКО из сундуков. Chests — из каких
-- сундуков выпадает. Своя модель: ReplicatedStorage.Assets.<AssetName>
-- (Tool или Model с Handle); пока её нет — сервер собирает простую модель
-- сам (shared/ProceduralSkins.lua), поэтому скины работают сразу.
do
	local defs = Config.Skins.Definitions
	local function pirate(id, name, rarity, chests)
		defs[id] = { Kind = "Pickaxe", DisplayName = name, Rarity = rarity, AssetName = "Skin_Pickaxe_" .. id, ImageId = 0, Chests = chests, Procedural = true, Set = "Pirate" }
	end
	pirate("RustyShovel",        "Rusty Shovel",          "Common",    { Common = true, Rare = true })
	pirate("BonePick",           "Bone Pick",             "Common",    { Common = true, Rare = true })
	pirate("AnchorPick",         "Anchor Pick",           "Rare",      { Common = true, Rare = true, Epic = true })
	pirate("PirateHook",         "Pirate Hook",           "Rare",      { Rare = true, Epic = true })
	pirate("KrakenTentacle",     "Kraken Tentacle",       "Epic",      { Rare = true, Epic = true, Legendary = true })
	pirate("SkeletonKey",        "Skeleton Key",          "Epic",      { Epic = true, Legendary = true })
	pirate("GoldenTrident",      "Golden Trident",        "Legendary", { Epic = true, Legendary = true })
	pirate("DoubloonAxe",        "Doubloon Axe",          "Legendary", { Legendary = true })
	pirate("CursedCaptainBlade", "Cursed Captain's Blade","Mythic",    { Legendary = true })
end
Config.SkinBuffs.RustyShovel        = { Boulder = 0.10, ChestLuck = 0.05, Speed = -0.04 }
Config.SkinBuffs.BonePick           = { Damage = 0.10, Stagger = 0.06, Luck = -0.03 }
Config.SkinBuffs.AnchorPick         = { Stagger = 0.18, Toughness = 0.10, Speed = -0.06 }
Config.SkinBuffs.PirateHook         = { ChestLuck = 0.15, Speed = 0.05, Toughness = -0.08 }
Config.SkinBuffs.KrakenTentacle     = { Mutation = 0.15, Stagger = 0.15, Money = -0.05 }
Config.SkinBuffs.SkeletonKey        = { ChestLuck = 0.25, Luck = 0.08, Damage = -0.10 }
Config.SkinBuffs.GoldenTrident      = { Money = 0.12, Damage = 0.20, Speed = -0.06 }
Config.SkinBuffs.DoubloonAxe        = { Money = 0.18, ChestLuck = 0.15, Toughness = -0.12 }
Config.SkinBuffs.CursedCaptainBlade = { Luck = 0.18, Mutation = 0.20, Money = 0.08, Toughness = -0.20 }

--------------------------------------------------------------------------------
-- v20.28: РЕБАЛАНС БОНУСОВ СКИНОВ ПО РЕДКОСТИ. У каждой кирки одна понятная
-- РОЛЬ (Config.SkinRoles) и «бюджет» плюсов по редкости (сумма долей):
--   Common 0.10 · Uncommon 0.14 · Rare 0.22 · Epic 0.32 · Legendary 0.46 · Mythic 0.62
-- С Rare — один небольшой минус по теме (тяжёлая кирка — медленнее и т.п.).
-- Бонусы видны в лавке торговца и в меню SKINS (с сравнением с надетой).
--------------------------------------------------------------------------------
local SKIN_REBALANCE = {
	BonePick            = { Damage = 0.06, Stagger = 0.04 },
	RustyShovel         = { Boulder = 0.07, ChestLuck = 0.03 },
	AmethystPickaxe     = { Luck = 0.05, Mutation = 0.06, Money = 0.03 },
	RadioactivePickaxe  = { Mutation = 0.10, Stagger = 0.04 },
	AnchorPick          = { Toughness = 0.14, Stagger = 0.08, Speed = -0.05 },
	BigWoodenPickaxe    = { Boulder = 0.15, Perfect = 0.07, Speed = -0.05 },
	CactusSword         = { Damage = 0.14, Stagger = 0.08, Luck = -0.03 },
	FishSkin            = { Money = 0.08, Speed = 0.08, ChestLuck = 0.06, Damage = -0.06 },
	LovePickaxe         = { Mutation = 0.14, Luck = 0.08, Stagger = -0.05 },
	PirateHook          = { ChestLuck = 0.14, Speed = 0.08, Toughness = -0.05 },
	BigMole             = { Boulder = 0.20, ChestLuck = 0.12, Speed = -0.06 },
	CrystalPickaxe      = { Perfect = 0.22, Luck = 0.10, Toughness = -0.06 },
	GroupPickaxe        = { Speed = 0.10, Dynamite = 0.16, Luck = 0.06 },
	KrakenTentacle      = { Mutation = 0.16, Stagger = 0.16, Money = -0.04 },
	LikePickaxe         = { Speed = 0.12, Dynamite = 0.14, Money = 0.06 },
	SkeletonKey         = { ChestLuck = 0.22, Luck = 0.10, Damage = -0.06 },
	TungTungStick       = { Stagger = 0.22, Boulder = 0.10, Perfect = -0.06 },
	LimitedCandyCane    = { Speed = 0.12, Mutation = 0.10, ChestLuck = 0.10 },
	DoubloonAxe         = { ChestLuck = 0.20, Money = 0.16, Luck = 0.10, Toughness = -0.08 },
	Gold                = { Money = 0.18, ChestLuck = 0.14, Dynamite = 0.14, Stagger = -0.08 },
	GoldKunai           = { Perfect = 0.20, Speed = 0.16, Dynamite = 0.10, Money = -0.04 },
	GoldSword           = { Damage = 0.26, Stagger = 0.14, ChestLuck = 0.06, Luck = -0.05 },
	GoldenTrident       = { Damage = 0.20, Boulder = 0.14, Money = 0.12, Speed = -0.05 },
	VoidPickaxe         = { ChestLuck = 0.18, Luck = 0.16, Mutation = 0.12, Money = -0.04 },
	LimitedRuneblade    = { Damage = 0.18, Boulder = 0.16, Toughness = 0.12 },
	LimitedSunforge     = { Perfect = 0.18, Money = 0.14, Dynamite = 0.14 },
	CursedCaptainBlade  = { Mutation = 0.22, Luck = 0.18, ChestLuck = 0.12, Money = 0.10, Toughness = -0.10 },
	DevSword            = { Luck = 0.20, Damage = 0.15, Speed = 0.15, Money = 0.12, Toughness = -0.08 },
	Frostmorn           = { Perfect = 0.30, Toughness = 0.18, Boulder = 0.14, Money = -0.05 },
	LimitedAbyssal      = { Mutation = 0.24, Stagger = 0.22, Luck = 0.16 },
	LimitedPrismBreaker = { Boulder = 0.22, Perfect = 0.20, Money = 0.10, Dynamite = 0.10 },
}
for skinId, buffs in SKIN_REBALANCE do
	Config.SkinBuffs[skinId] = buffs
end

-- Роль кирки одной строкой (лавка торговца, меню SKINS).
Config.SkinRoles = {
	BonePick = "Goblin hunter", RustyShovel = "Boulder breaker", AmethystPickaxe = "Lucky finder",
	RadioactivePickaxe = "Mutation hunter", AnchorPick = "PvP tank", BigWoodenPickaxe = "Boulder breaker",
	CactusSword = "Goblin hunter", FishSkin = "Money maker", LovePickaxe = "Mutation hunter", PirateHook = "Treasure hunter",
	BigMole = "Boulder breaker", CrystalPickaxe = "Perfect striker", GroupPickaxe = "Explorer", KrakenTentacle = "Mutation brawler",
	LikePickaxe = "Explorer", SkeletonKey = "Treasure hunter", TungTungStick = "PvP brawler", LimitedCandyCane = "Explorer",
	DoubloonAxe = "Treasure hunter", Gold = "Money maker", GoldKunai = "Perfect striker", GoldSword = "Goblin hunter",
	GoldenTrident = "Goblin hunter", VoidPickaxe = "Lucky finder", LimitedRuneblade = "Boulder breaker", LimitedSunforge = "Money maker",
	CursedCaptainBlade = "Mutation hunter", DevSword = "All-rounder", Frostmorn = "Perfect striker", LimitedAbyssal = "Mutation brawler",
	LimitedPrismBreaker = "Boulder breaker", TurboPickaxe = "Rocket launcher",
}

-- СУНДУКИ: новый лут. Rolls — сколько наград за открытие. Skin — пул
-- скинов с Chests[редкость]; вес скина внутри пула — SkinRarityWeights.
-- Дубль скина превращается в деньги (DuplicateCarts полных тележек).
Config.Chests.SkinRarityWeights = { Common = 50, Uncommon = 40, Rare = 30, Epic = 14, Legendary = 5, Mythic = 1 }
Config.Chests.DuplicateCarts = { Common = 1, Rare = 2, Epic = 3.5, Legendary = 6 }
-- Гарантия: каждый Every-й сундук этих редкостей без скина — точно скин.
Config.Chests.SkinPity = { Every = 10, Rarities = { Epic = true, Legendary = true } }
Config.Chests.LootIcons = { Money = "💰", Skin = "⛏", Charm = "🔮", PrestigePoint = "⭐", Relic = "🏆" }
Config.Chests.Types.Common.Loot = {
	{ Kind = "Money", Weight = 80, Carts = { 0.4, 1.2 } },
	{ Kind = "Skin", Weight = 12 },
	{ Kind = "Charm", Weight = 8 },
}
Config.Chests.Types.Rare.Loot = {
	{ Kind = "Money", Weight = 62, Carts = { 1, 2.5 } },
	{ Kind = "Skin", Weight = 20 },
	{ Kind = "Charm", Weight = 18 },
}
Config.Chests.Types.Epic.Loot = {
	{ Kind = "Money", Weight = 48, Carts = { 2, 5 } },
	{ Kind = "Skin", Weight = 27 },
	{ Kind = "Charm", Weight = 25 },
}
Config.Chests.Types.Legendary.Loot = {
	{ Kind = "Money", Weight = 34, Carts = { 4, 10 } },
	{ Kind = "Skin", Weight = 34 },
	{ Kind = "Charm", Weight = 26 },
	{ Kind = "PrestigePoint", Weight = 6 },
}

-- v19: ВАЛУНЫ — ПЛАШКА ХП, ЦИФРЫ УРОНА, ВИНЬЕТКА (client/BoulderHitFX).
-- Плашка в стиле The Forge: тёмная подложка, имя слева, ХП справа, полоса с
-- белым «хвостом» урона. Видна рядом с камнем или после удара. Кольцо из
-- партов над камнем и старый билборд «BOULDER LV» убраны.
-- Имя: атрибут DisplayName на модели валуна (если задан в Studio), иначе
-- DisplayNames[тир].
Config.BoulderHitFx = {
	Enabled = true,
	DisplayNames = { "Mossy Pebble", "Icy Pebble", "Rough Stone", "Copper Rock", "Granite Chunk", "Crystal Boulder", "Obsidian Slab", "Magma Boulder", "Void Monolith" },
	ShowDistance = 55,     -- v19.5: ближе — плашка видна всегда (как старый билборд валуна)
	HitShowSeconds = 4,    -- после удара видна столько секунд
	MaxDistance = 70,
	PlateColor = Color3.fromRGB(14, 14, 18),
	-- v20: ТРЯСКА ВАЛУНА на каждый удар (видят все игроки): толчок от
	-- бьющего → пружина обратно с перелётом → затухание.
	--   Push — сдвиг (студы), Tilt — наклон (градусы) при силе удара 1;
	--   Frequency — частота пружины (рад/с), Damping — затухание, Duration — сек.
	Wobble = { Enabled = true, Push = 0.45, Tilt = 9, Frequency = 22, Damping = 7.5, Duration = 0.7 },
	-- Виньетка по краям экрана на удар: цвет и непрозрачность у края (0..1).
	Vignette = {
		-- v19.1: вспышка только в момент удара, не больше 10% видимости.
		Miss = { Color = Color3.fromRGB(255, 255, 255), Alpha = 0.05 },
		Good = { Color = Color3.fromRGB(255, 255, 255), Alpha = 0.08 },
		Perfect = { Color = Color3.fromRGB(255, 205, 70), Alpha = 0.10 },
		Dynamite = { Color = Color3.fromRGB(255, 150, 60), Alpha = 0.10 },
		Final = { Color = Color3.fromRGB(255, 245, 225), Alpha = 0.10 },
		MaxAlpha = 0.10, -- потолок для любых значений выше
		Seconds = 0.12,  -- за сколько гаснет
	},
}

--------------------------------------------------------------------------------
-- v20.60: СКИНЫ — ПОЛНЫЙ СПИСОК. Всё, чего нет в этом списке, удалено
-- (в сохранениях у игроков старые ключи просто игнорируются; надетый
-- удалённый скин = обычная кирка). Исключение — TurboPickaxe: это скин
-- геймпасса Rocket Pickaxe, без него пасс перестанет работать.
--
-- Источник каждого скина:
--   Chests  = { Common/Rare/Epic/Legendary = true } — выпадает из сундуков;
--   Goblins = true          — падает с гоблинов (Config.GoblinRaid.SkinDrop);
--   Merchant = true         — продаётся в лавке торговца (Config.Merchant.Items);
--   Limited = true          — лимитированная кирка цикла у торговца;
--   NpcExclusive = true     — только наградой (NPC, дейлик, лайк).
-- Своя модель: ReplicatedStorage.Assets.<AssetName> (Tool с Handle, как
-- раньше). Пока её нет — сервер собирает простую модель сам по Shape/
-- Colors/Material (shared/ProceduralSkins), поэтому скин работает сразу.
--------------------------------------------------------------------------------
do
	local C = Color3.fromRGB
	local M = Enum.Material
	local function skin(id, name, rarity, asset, image, shape, colors, material, extra)
		local def = {
			Kind = "Pickaxe", DisplayName = name, Rarity = rarity, AssetName = asset, ImageId = image or 0,
			Procedural = true, Shape = shape, Colors = colors, Material = material,
		}
		for key, value in extra or {} do def[key] = value end
		return id, def
	end
	local roster = {}
	local function add(id, def) roster[id] = def end

	-- ОБЫЧНЫЕ (сундуки, гоблины)
	add(skin("AncientStonePickaxe", "Ancient Stone Pickaxe", "Common", "Skin_Pickaxe_AncientStone", 0, "Pickaxe", { C(120, 116, 108), C(88, 70, 50) }, M.Slate, { Chests = { Common = true, Rare = true }, Goblins = true }))
	add(skin("BonePick", "Bone Pickaxe", "Common", "Skin_Pickaxe_BonePick", 0, "Pickaxe", { C(236, 228, 205), C(236, 228, 205) }, M.SmoothPlastic, { Chests = { Common = true, Rare = true }, Goblins = true }))
	add(skin("ForestPickaxe", "Forest Pickaxe", "Common", "Skin_Pickaxe_Forest", 0, "Pickaxe", { C(80, 150, 70), C(110, 72, 40) }, M.Grass, { Chests = { Common = true, Rare = true } }))
	-- НЕОБЫЧНЫЕ
	add(skin("JunglePickaxe", "Jungle Pickaxe", "Uncommon", "Skin_Pickaxe_Jungle", 0, "Pickaxe", { C(40, 120, 60), C(90, 60, 30) }, M.LeafyGrass, { Chests = { Common = true, Rare = true }, Goblins = true }))
	add(skin("RadioactivePickaxe", "Retro Radioactive Pickaxe", "Uncommon", "Skin_Pickaxe_Radioactive", 132744755925965, "Pickaxe", { C(120, 255, 60), C(50, 50, 50) }, M.Neon, { Merchant = true }))
	add(skin("AmethystPickaxe", "Retro Amethyst Pickaxe", "Uncommon", "Skin_Pickaxe_Amethyst", 76941906947734, "Pickaxe", { C(170, 90, 230), C(90, 60, 40) }, M.Glass, { Merchant = true, Chests = { Rare = true } }))
	-- РЕДКИЕ
	add(skin("AnchorPick", "Underwater Anchor", "Rare", "Skin_Pickaxe_AnchorPick", 0, "Pickaxe", { C(80, 84, 92), C(80, 84, 92) }, M.Metal, { Chests = { Rare = true, Epic = true }, Goblins = true }))
	add(skin("PirateCutlass", "Pirate Cutlass", "Rare", "Skin_Pickaxe_PirateCutlass", 0, "Sword", { C(210, 215, 225), C(200, 160, 60) }, M.Metal, { Chests = { Rare = true, Epic = true }, Goblins = true }))
	add(skin("BigWoodenPickaxe", "Big Retro Wooden Pickaxe", "Rare", "Skin_Pickaxe_BigWooden", 121805710908648, "Pickaxe", { C(150, 100, 55), C(110, 72, 40) }, M.Wood, { Merchant = true }))
	add(skin("LovePickaxe", "Retro Love Pickaxe", "Rare", "Skin_Pickaxe_Love", 115736148291739, "Pickaxe", { C(255, 110, 170), C(255, 220, 235) }, M.SmoothPlastic, { Merchant = true }))
	add(skin("CactusSword", "Cactus Sword", "Rare", "Skin_Pickaxe_CactusSword", 125983395178047, "Sword", { C(70, 170, 70), C(120, 90, 50) }, M.Grass, { Goblins = true }))
	add(skin("FishSkin", "Fish Sword", "Rare", "Skin_Pickaxe_Fish", 138909766473481, "Sword", { C(90, 170, 220), C(240, 200, 90) }, M.SmoothPlastic, { Chests = { Rare = true, Epic = true } }))
	add(skin("IcePickaxe", "Ice Pickaxe", "Rare", "Skin_Pickaxe_Ice", 0, "Pickaxe", { C(170, 225, 255), C(70, 100, 140) }, M.Ice, { Chests = { Rare = true, Epic = true } }))
	-- ЭПИЧЕСКИЕ
	-- BattleAxe (Battle Axe) убран в v20.65 - модель ещё не готова.
	add(skin("MagmaPickaxe", "Magma Pickaxe", "Epic", "Skin_Pickaxe_Magma", 0, "Pickaxe", { C(255, 110, 30), C(40, 30, 30) }, M.Neon, { Chests = { Epic = true, Legendary = true } }))
	add(skin("ElectricPickaxe", "Electric Pickaxe", "Epic", "Skin_Pickaxe_Electric", 0, "Pickaxe", { C(90, 200, 255), C(255, 230, 60) }, M.Neon, { Chests = { Epic = true, Legendary = true } }))
	add(skin("CrystalPickaxe", "Retro Crystal Pickaxe", "Epic", "Skin_Pickaxe_Crystal", 128296786196999, "Pickaxe", { C(120, 230, 255), C(90, 90, 110) }, M.Glass, { Merchant = true }))
	add(skin("BigMole", "Mole Club", "Epic", "Skin_Pickaxe_BigMole", 96146522945116, "Club", { C(110, 80, 60), C(255, 170, 190) }, M.Fabric, { Goblins = true, Limited = true }))
	add(skin("TungTungStick", "Tung Tung Sahur Stick", "Epic", "Skin_Pickaxe_TungTungStick", 115880001946513, "Club", { C(160, 110, 60), C(110, 72, 40) }, M.Wood, { Goblins = true, Limited = true }))
	-- ЛЕГЕНДАРНЫЕ
	add(skin("StarPickaxe", "Star Pickaxe", "Legendary", "Skin_Pickaxe_Star", 0, "Pickaxe", { C(255, 230, 90), C(60, 50, 110) }, M.Neon, { Chests = { Legendary = true } }))
	add(skin("SpectrumPickaxe", "Spectrum Pickaxe", "Legendary", "Skin_Pickaxe_Spectrum", 0, "Pickaxe", { C(255, 90, 200), C(90, 220, 255) }, M.Neon, { Chests = { Legendary = true }, Rainbow = true }))
	add(skin("GoldSword", "Gold Sword", "Legendary", "Skin_Pickaxe_GoldSword", 75847632645464, "Sword", { C(255, 210, 60), C(120, 75, 15) }, M.Metal, { Limited = true, Chests = { Legendary = true } }))
	add(skin("GoldKunai", "Gold Kunai", "Legendary", "Skin_Pickaxe_GoldKunai", 82992142504153, "Kunai", { C(255, 225, 80), C(95, 60, 15) }, M.Metal, { Limited = true, Goblins = true }))
	add(skin("Gold", "Gold Skin", "Legendary", "Skin_GOLD", 79280932428022, "Pickaxe", { C(255, 205, 50), C(255, 205, 50) }, M.Foil, { NpcExclusive = true }))
	-- МИФИЧЕСКИЕ
	add(skin("GalaxySword", "Galaxy Sword", "Mythic", "Skin_Pickaxe_GalaxySword", 0, "Sword", { C(120, 60, 220), C(30, 20, 60) }, M.Neon, { Chests = { Legendary = true }, Goblins = true }))
	add(skin("MilkyWayPickaxe", "Milky Way Pickaxe", "Mythic", "Skin_Pickaxe_MilkyWay", 0, "Pickaxe", { C(230, 225, 255), C(40, 30, 90) }, M.Neon, { Chests = { Legendary = true } }))
	add(skin("DevSword", "Ban Hammer", "Mythic", "Skin_Pickaxe_DevSword", 117000062306052, "Hammer", { C(60, 60, 70), C(255, 60, 60) }, M.Metal, { Limited = true }))
	add(skin("Frostmorn", "Frostmourne", "Mythic", "Skin_Frostmorn", 74383462032767, "Sword", { C(150, 220, 255), C(60, 70, 90) }, M.Ice, { NpcExclusive = true }))

	-- Геймпасс Rocket Pickaxe (см. Config.RocketPickaxe) — оставлен.
	local turbo = Config.Skins.Definitions.TurboPickaxe
	if turbo then roster.TurboPickaxe = turbo end

	Config.Skins.Definitions = roster
	Config.Skins.EnabledKinds = { Pickaxe = true, Cart = false, Ore = false }

	-- Порядок в каталогах (по редкости, внутри — как в списке выше).
	Config.Skins.Order = {
		"AncientStonePickaxe", "BonePick", "ForestPickaxe",
		"JunglePickaxe", "RadioactivePickaxe", "AmethystPickaxe",
		"AnchorPick", "PirateCutlass", "BigWoodenPickaxe", "LovePickaxe", "CactusSword", "FishSkin", "IcePickaxe",
		"MagmaPickaxe", "ElectricPickaxe", "CrystalPickaxe", "BigMole", "TungTungStick",
		"StarPickaxe", "SpectrumPickaxe", "GoldSword", "GoldKunai", "Gold",
		"GalaxySword", "MilkyWayPickaxe", "DevSword", "Frostmorn",
	}

	-- v20.65: БОНУСЫ ПО КАТЕГОРИЯМ. У каждого источника своя «профессия»,
	-- и внутри неё чем реже/дороже скин, тем сильнее главный бонус. Минусов
	-- нет - просто одна кирка лучше другой в СВОЕЙ категории:
	--   ГОБЛИНЫ   - всё, что падает с гоблинов: Damage (урон по гоблинам);
	--   СУНДУКИ   - удача, деньги, сундуки, мутации;
	--   ТОРГОВЕЦ  - ретро-кирки: мутации, валуны, PERFECT;
	--   НАГРАДЫ   - особые (Gold, Frostmourne, Ban Hammer).
	-- Главный бонус по редкости: Common 8-10% · Uncommon 12% · Rare 14-20% ·
	-- Epic 22-28% · Legendary 30-38% · Mythic 40-52%. Второй - вдвое-вчетверо слабее.
	local buffs = {
		-- ГОБЛИНЫ: урон по гоблинам растёт строго по редкости.
		AncientStonePickaxe = { Damage = 0.08, Toughness = 0.03 },
		BonePick            = { Damage = 0.10, Stagger = 0.03 },
		JunglePickaxe       = { Damage = 0.12, Speed = 0.04 },
		AnchorPick          = { Damage = 0.16, Toughness = 0.08 },
		PirateCutlass       = { Damage = 0.18, ChestLuck = 0.06 },
		CactusSword         = { Damage = 0.20, Stagger = 0.06 },
		BigMole             = { Damage = 0.26, Boulder = 0.08 },
		TungTungStick       = { Damage = 0.28, Stagger = 0.10 },
		GoldKunai           = { Damage = 0.38, Speed = 0.10 },
		GalaxySword         = { Damage = 0.52, Luck = 0.12 },
		-- СУНДУКИ: удача / деньги / мутации / скорость / валуны.
		ForestPickaxe       = { Luck = 0.06, ChestLuck = 0.04 },
		AmethystPickaxe     = { Luck = 0.10, Money = 0.04 },
		FishSkin            = { Money = 0.14, ChestLuck = 0.06 },
		IcePickaxe          = { Perfect = 0.14, Toughness = 0.06 },
		MagmaPickaxe        = { Boulder = 0.22, Dynamite = 0.10 },
		ElectricPickaxe     = { Speed = 0.18, Perfect = 0.08 },
		StarPickaxe         = { Luck = 0.30, ChestLuck = 0.10 },
		SpectrumPickaxe     = { Mutation = 0.30, Luck = 0.10 },
		GoldSword           = { Money = 0.30, ChestLuck = 0.10 },
		MilkyWayPickaxe     = { Luck = 0.40, Mutation = 0.15 },
		-- ТОРГОВЕЦ (ретро): мутации, валуны, PERFECT.
		RadioactivePickaxe  = { Mutation = 0.12, Luck = 0.03 },
		BigWoodenPickaxe    = { Boulder = 0.18, Perfect = 0.04 },
		LovePickaxe         = { Mutation = 0.18, Luck = 0.05 },
		CrystalPickaxe      = { Perfect = 0.26, Luck = 0.06 },
		-- НАГРАДЫ.
		Gold                = { Money = 0.36, Dynamite = 0.08 },
		DevSword            = { Damage = 0.30, Luck = 0.15, Money = 0.15, Speed = 0.10 },
		Frostmorn           = { Perfect = 0.45, Toughness = 0.15, Boulder = 0.10 },
	}
	local roles = {
		AncientStonePickaxe = "Goblin hunter", BonePick = "Goblin hunter", JunglePickaxe = "Goblin hunter",
		AnchorPick = "Goblin hunter", PirateCutlass = "Goblin hunter", CactusSword = "Goblin hunter",
		BigMole = "Goblin hunter", TungTungStick = "Goblin hunter", GoldKunai = "Goblin hunter", GalaxySword = "Goblin slayer",
		ForestPickaxe = "Lucky finder", AmethystPickaxe = "Lucky finder", FishSkin = "Money maker", IcePickaxe = "Perfect striker",
		MagmaPickaxe = "Boulder breaker", ElectricPickaxe = "Speedster", StarPickaxe = "Lucky finder",
		SpectrumPickaxe = "Mutation hunter", GoldSword = "Money maker", MilkyWayPickaxe = "Lucky finder",
		RadioactivePickaxe = "Mutation hunter", BigWoodenPickaxe = "Boulder breaker", LovePickaxe = "Mutation hunter",
		CrystalPickaxe = "Perfect striker", Gold = "Money maker", DevSword = "All-rounder", Frostmorn = "Perfect striker",
		TurboPickaxe = "Rocket launcher",
	}
	local keepTurboBuff = Config.SkinBuffs and Config.SkinBuffs.TurboPickaxe
	Config.SkinBuffs = buffs
	Config.SkinBuffs.TurboPickaxe = keepTurboBuff
	Config.SkinRoles = roles
	Config.PickaxeSkinBuffs = { Default = { Damage = 0, Luck = 0, Speed = 0 } }

	-- ЛАВКА: скины Merchant = true (цена по редкости), остальное не трогаем.
	local merchantPrice = { Common = 8000, Uncommon = 20000, Rare = 120000, Epic = 450000, Legendary = 1500000, Mythic = 5000000 }
	local merchantChance = { Common = 0.7, Uncommon = 0.5, Rare = 0.28, Epic = 0.13, Legendary = 0.05, Mythic = 0.02 }
	local items = {}
	for _, item in Config.Merchant.Items or {} do
		if item.Kind ~= "Skin" then table.insert(items, item) end
	end
	local mysterySkins = {}
	for _, id in Config.Skins.Order do
		local def = roster[id]
		if def and def.Merchant then
			table.insert(items, {
				Id = "Skin_" .. id, Kind = "Skin", SkinId = id, DisplayName = def.DisplayName, Icon = "⛏",
				Rarity = def.Rarity, Chance = merchantChance[def.Rarity] or 0.1, Stock = { 1, 1 },
				Price = merchantPrice[def.Rarity] or 100000,
			})
			table.insert(mysterySkins, id)
		end
	end
	Config.Merchant.Items = items
	for _, row in (Config.Merchant.Mystery and Config.Merchant.Mystery.Pool) or {} do
		if row.Kind == "Skin" then row.Skins = mysterySkins end
	end
	-- Лимитированная кирка цикла — скины Limited = true.
	local limitedPool = {}
	for _, id in Config.Skins.Order do
		if roster[id] and roster[id].Limited then table.insert(limitedPool, id) end
	end
	Config.Merchant.Limited.Pool = limitedPool
	Config.Merchant.Limited.FallbackPool = limitedPool

	-- Награды, которые выдавали удалённые скины.
	Config.LikeReward.SkinId = "IcePickaxe"
	Config.GroupReward.SkinId = "ForestPickaxe"

	-- ГОБЛИНЫ: шанс скина с каждого убитого гоблина (у боссов — BossChance).
	-- Скин из пула Goblins = true, вес — Config.Chests.SkinRarityWeights,
	-- сначала те, которых у игрока ещё нет. Все собраны — ничего не падает.
	Config.GoblinRaid.SkinDrop = { Chance = 0.02, BossChance = 0.25 }
end

-- v20.63: ЧАСТИЦЫ МУТАЦИЙ (как у Toxic) - поверх основного вида. Своя:
-- ReplicatedStorage.Assets.MutationVFX_<Имя> (Attachment, или Part/Model с
-- ParticleEmitter). Нет своей - встроенная заготовка. Цвет частиц = цвет
-- мутации (ParticleColor - свой цвет). Убрать - удали строку.
for mutationId, vfxName in {
	Frozen = "Frozen", Soaked = "Soaked", Void = "Void", Molten = "Molten", Sanguine = "Sanguine",
	Golden = "Golden", Radiant = "Radiant", Prismatic = "Prismatic", Celestial = "Celestial",
} do
	if Config.Mutations[mutationId] then Config.Mutations[mutationId].Particles = vfxName end
end

-- v20.66: МУТАЦИИ - ДВУХЭТАПНЫЙ БРОСОК (как в Grow a Garden и большинстве
-- Roblox-игр с мутациями). Раньше каждая из 18 мутаций бросалась отдельно,
-- шансы складывались (≈30-60% руды мутировало, часто по 3-5 сразу), а
-- надпись «1/N» перемножала всё и уходила в миллионы.
--   1) Мутирует ли руда вообще: Roll.BaseChance (6% = 1 из ~17). Зелье,
--      перк Mutations, пасс удачи - множат ЭТОТ шанс (не выше MaxChance).
--   2) Какая именно: по весам Weight (редкие - маленький вес). Удача от
--      пещеры и погода сдвигают выбор к редким.
--   3) Вторая/третья мутация сверху: ExtraChance от первой (8%).
-- Chance каждой мутации ниже ПЕРЕСЧИТАН = итоговый шанс получить именно
-- её (BaseChance × вес / сумма весов) - это и показывается игроку.
Config.Mutations.Roll = { BaseChance = 0.06, ExtraChance = 0.08, MaxMutations = 3, MaxChance = 0.5 }
do
	local totalWeight = 0
	for _, mutationId in Config.Mutations.Order do
		local info = Config.Mutations[mutationId]
		if info then
			info.Weight = tonumber(info.Weight) or tonumber(info.Chance) or 0
			totalWeight += info.Weight
		end
	end
	Config.Mutations.TotalWeight = totalWeight
	for _, mutationId in Config.Mutations.Order do
		local info = Config.Mutations[mutationId]
		if info then info.Chance = Config.Mutations.Roll.BaseChance * info.Weight / math.max(1e-9, totalWeight) end
	end
end

-- v20.64: ДИНАМИТ ПО ГОБЛИНАМ - доля макс. здоровья гоблина от взрыва
-- (в центре; у края радиуса вдвое меньше). Боссы - × BossGoblinDamageMult.
Config.Dynamite.GoblinDamage = 0.35
Config.Dynamite.BossGoblinDamageMult = 0.25
for key, share in { Dynamite = 0.35, Dynamite_Medium = 0.6, Dynamite_Mega = 1.0 } do
	if Config.Dynamite.Types[key] then Config.Dynamite.Types[key].GoblinDamage = share end
end

-- v20: цена престижа — в масштабе дохода пещеры, где его делают (Config.NumberGrowth).
if Config.Prestige and Config.Prestige.CostBase then
	Config.Prestige.CostBase = Config.NiceNumber(Config.Prestige.CostBase * Config.CaveNumberScale(Config.Prestige.MinCave or 8))
	Config.Prestige.CostMax = Config.NiceNumber((Config.Prestige.CostMax or 1e15) * Config.CaveNumberScale(#Config.MineTiers))
end

return Config

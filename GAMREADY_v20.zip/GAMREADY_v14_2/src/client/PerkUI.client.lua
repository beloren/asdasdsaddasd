--------------------------------------------------------------------------------
-- PerkUI (LocalScript) v9 — окно престижа ДЕРЕВОМ (PrestigeService,
-- Config.Prestige.Branches). Сервер открывает его командой "Open" по клику
-- на чемоданчик у NPC ребёрта. Узел ветки открывается, когда у предыдущего
-- есть UnlockLevel уровней (проверяет и сервер). Перки не сбрасываются.
--------------------------------------------------------------------------------
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")

local Config = require(ReplicatedStorage.Shared.Config)
local Localization = require(ReplicatedStorage.Shared.Localization)
local UiSfx = require(ReplicatedStorage.Shared.UiSfx)
local Builder = require(ReplicatedStorage.Shared.PerkUiBuilder)

-- Цвета узлов (оформление окна — в PerkUiBuilder).
local COLOR_LOCKED = Color3.fromRGB(46, 42, 70)
local COLOR_STAR = Color3.fromRGB(80, 70, 150)
local COLOR_INK = Color3.fromRGB(10, 8, 24)
local COLOR_GOLD_TEXT = Color3.fromRGB(255, 220, 110)
local COLOR_GREEN_TEXT = Color3.fromRGB(120, 255, 150)
local COLOR_GREEN = Color3.fromRGB(70, 200, 95)
local COLOR_ORANGE = Color3.fromRGB(215, 120, 45)
local COLOR_GREY = Color3.fromRGB(95, 98, 110)

local function press(guiButton)
	local scale = guiButton:FindFirstChild("PressScale") or Instance.new("UIScale")
	scale.Name = "PressScale"
	scale.Parent = guiButton
	local function to(value, seconds)
		TweenService:Create(scale, TweenInfo.new(seconds or 0.1, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), { Scale = value }):Play()
	end
	guiButton.MouseEnter:Connect(function() to(1.06) end)
	guiButton.MouseLeave:Connect(function() to(1) end)
	guiButton.MouseButton1Down:Connect(function() to(0.92, 0.06) end)
	guiButton.MouseButton1Up:Connect(function() to(1.06) end)
end

local cfg = Config.Prestige
if not (cfg and cfg.Enabled) then return end

local player = Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

local function tr(text, args)
	local ok, result = pcall(Localization.Translate, player.LocaleId, text, args)
	return ok and result or text
end

-- v20: окно собирается билдером (Shared.PerkUiBuilder → StarterGui/PerkUi).
local UiKit = require(ReplicatedStorage.Shared.UiKit)
local gui = require(ReplicatedStorage.Shared.UiRegistry).Get("PerkUi")
if not (gui:FindFirstChild("Tree", true) and gui:FindFirstChild("Shrines", true)) then
	gui:Destroy()
	gui = Builder.Build()
	gui.Parent = playerGui
end
gui.ResetOnSpawn = false
gui.Enabled = false

local panel = gui:WaitForChild("Panel")
local autoScale = panel:FindFirstChild("AutoScale")
local pointsLabel = panel:WaitForChild("Points"):WaitForChild("Text")
local closeButton = panel:WaitForChild("CloseButton")
local tree = panel:WaitForChild("Tree")
local branchTemplate = tree:WaitForChild("BranchTemplate")
local nodeTemplate = tree:WaitForChild("NodeTemplate")
local linkTemplate = tree:WaitForChild("LinkTemplate")
local detail = panel:WaitForChild("Detail")
local upgradeButton = detail:WaitForChild("UpgradeButton")
local upgradeText = upgradeButton:WaitForChild("Text")
require(ReplicatedStorage.Shared.TutorialTarget).Mark(upgradeButton, "PerkUpgrade") -- v20.110
-- v4: вкладки и список святилищ.
local tabs = panel:WaitForChild("Tabs")
local perksTab = tabs:WaitForChild("PerksTab")
local shrinesTab = tabs:WaitForChild("ShrinesTab")

-- v20.67: подписи кнопок (PERKS / SHRINES / купить) всегда крупные и
-- читаемые: растянуты на всю кнопку, TextScaled и минимум 18 px - даже
-- если копия окна в месте старая или её подпись кто-то уменьшил.
local function readableCaption(button, minSize)
	local caption = button:FindFirstChild("Text") or button:FindFirstChild("Caption")
	if not (caption and caption:IsA("TextLabel")) then return end
	caption.AnchorPoint = Vector2.zero
	caption.Position = UDim2.fromOffset(6, 3)
	caption.Size = UDim2.new(1, -12, 1, -6)
	caption.TextScaled = true
	caption.TextWrapped = false
	local limit = caption:FindFirstChildOfClass("UITextSizeConstraint") or Instance.new("UITextSizeConstraint")
	limit.MinTextSize = minSize or 18
	limit.MaxTextSize = 48
	limit.Parent = caption
end
readableCaption(perksTab, 20)
readableCaption(shrinesTab, 18)
readableCaption(upgradeButton, 24)
local shrinesList = panel:WaitForChild("Shrines")
local shrineTemplate = shrinesList:WaitForChild("ShrineTemplate")
local SHRINES = cfg.Shrines or { Order = {}, Types = {} }
local mode = "Perks"
local selectedShrine = nil
local shrineState = {}

local remote = ReplicatedStorage.Shared:WaitForChild("PrestigeRequest", 30)
if not remote then
	warn("[PerkUI] PrestigeRequest не появился - окно перков отключено.")
	return
end

local PERK_BY_ID = {}
for _, perk in cfg.Perks do PERK_BY_ID[perk.Id] = perk end
local BRANCH_OF = {}
for _, branch in cfg.Branches or {} do
	for _, perkId in branch.Perks do BRANCH_OF[perkId] = branch end
end

-- v20.21: узлы чуть меньше, промежутки больше — линии между улучшениями
-- видны целиком (не прячутся под плашкой уровня) и 4 узла влезают в ветку.
-- Иконка: ImageLabel "Icon" (+ "Emoji" внутри) или старый TextLabel.
local function setIcon(holder, emoji, imageId, transparency)
	if not holder then return end
	if holder:IsA("TextLabel") then
		holder.Text = emoji or ""
		holder.TextTransparency = transparency or 0
		return
	end
	local id = tonumber(imageId) or 0
	if id > 0 then holder.Image = "rbxassetid://" .. id end
	if holder:IsA("ImageLabel") then holder.ImageTransparency = transparency or 0 end
	local text = holder:FindFirstChild("Emoji")
	if text then
		text.Text = emoji or ""
		text.TextTransparency = transparency or 0
		text.Visible = holder.Image == ""
	end
end

-- v20.106: ИКОНКА ОЧКОВ ПРЕСТИЖА вместо «⭐» у чисел (Config.Prestige.PointIconId;
-- пока 0 - нарисованный фиолетовый ромб). Иконка - ImageLabel "PointIcon"
-- слева внутри надписи, текст сдвигается вправо.
local Points = {}
function Points.Icon(label)
	if not (label and label:IsA("TextLabel")) then return end
	local icon = label:FindFirstChild("PointIcon")
	if not icon then
		icon = Instance.new("ImageLabel")
		icon.Name = "PointIcon"
		icon.BackgroundTransparency = 1
		icon.AnchorPoint = Vector2.new(0, 0.5)
		icon.Position = UDim2.new(0, 0, 0.5, 0)
		icon.Size = UDim2.fromScale(1, 0.9)
		icon.ZIndex = label.ZIndex + 1
		local ratio = Instance.new("UIAspectRatioConstraint")
		ratio.AspectRatio = 1
		ratio.Parent = icon
		local id = tonumber(cfg.PointIconId) or 0
		if id > 0 then
			icon.Image = "rbxassetid://" .. id
		else
			local diamond = Instance.new("Frame")
			diamond.Name = "Diamond"
			diamond.AnchorPoint = Vector2.new(0.5, 0.5)
			diamond.Position = UDim2.fromScale(0.5, 0.5)
			diamond.Size = UDim2.fromScale(0.62, 0.62)
			diamond.Rotation = 45
			diamond.BackgroundColor3 = Color3.fromRGB(190, 120, 255)
			diamond.BorderSizePixel = 0
			diamond.ZIndex = icon.ZIndex
			local stroke = Instance.new("UIStroke")
			stroke.Thickness = 2
			stroke.Color = Color3.fromRGB(40, 15, 70)
			stroke.Parent = diamond
			diamond.Parent = icon
		end
		icon.Parent = label
		local pad = label:FindFirstChildOfClass("UIPadding") or Instance.new("UIPadding")
		pad.PaddingLeft = UDim.new(0.22, 0)
		pad.Parent = label
	end
end
function Points.Set(label, value)
	if not label then return end
	label.Text = tostring(value)
	Points.Icon(label)
	label.PointIcon.Visible = true
end
function Points.Hide(label)
	local icon = label and label:FindFirstChild("PointIcon")
	if icon then icon.Visible = false end
end

local NODE_SIZE = 60
local NODE_GAP = 34
local CHIP_OVERHANG = 13 -- плашка уровня «3/10» свисает ниже узла

local state = { Points = 0 }
local levels = {}
local selected = nil
local isOpen = false
local openedAt = nil

local function effectText(perk, level)
	local value = level * perk.PerLevel
	local shown = perk.Percent and tostring(math.floor(value * 100 + 0.5)) or tostring(math.floor(value + 0.5))
	return tr(perk.Text, { v = shown, c = tostring(1 + math.floor(value + 0.5)) })
end

local function infoOf(perkId)
	return levels[perkId] or { Level = 0, MaxLevel = PERK_BY_ID[perkId] and PERK_BY_ID[perkId].MaxLevel or 1 }
end

local renderDetail

-- v20.107: СВОБОДНОЕ ДЕРЕВО (Config.Prestige.TreeLayout) как на референсе:
-- стартовый узел в центре, ветки расходятся линиями, закрытые узлы - «?».
local Free = {}
local renderTree
function Free.Link(parent, size, a, b, color)
	local ax, ay = a[1] * size.X, a[2] * size.Y
	local bx, by = b[1] * size.X, b[2] * size.Y
	local dx, dy = bx - ax, by - ay
	local line = linkTemplate:Clone()
	line.Name = "Link"
	line.Visible = true
	line.AnchorPoint = Vector2.new(0.5, 0.5)
	-- позиция и длина в долях: не зависят от UIScale окна
	line.Position = UDim2.fromScale((a[1] + b[1]) / 2, (a[2] + b[2]) / 2)
	line.Size = UDim2.new(math.sqrt(dx * dx + dy * dy) / math.max(1, size.X), 0, 0, 6)
	line.Rotation = math.deg(math.atan2(dy, dx))
	line.BackgroundColor3 = color
	line.ZIndex = 2
	line.Parent = parent
end
function Free.Shape(node)
	local id = tonumber(cfg.NodeImageId) or 0
	if id <= 0 then return end
	node.Image = "rbxassetid://" .. id
	node.ImageColor3 = node.BackgroundColor3
	node.BackgroundTransparency = 1
	local corner = node:FindFirstChildOfClass("UICorner")
	if corner then corner:Destroy() end
	local outline = node:FindFirstChild("Outline")
	if outline then outline.Enabled = false end
end
function Free.Render()
	local layout = cfg.TreeLayout
	local holder = Instance.new("Frame")
	holder.Name = "FreeTree"
	holder:SetAttribute("Generated", true)
	holder.BackgroundTransparency = 1
	holder.Size = UDim2.fromScale(1, 1)
	holder.ClipsDescendants = true
	holder.Parent = tree
	local size = holder.AbsoluteSize
	if size.X < 10 then size = tree.AbsoluteSize end
	local startPos = layout.Start or { 0.5, 0.5 }
	-- стартовый узел
	local start = nodeTemplate:Clone()
	start.Name = "StartNode"
	start.Visible = true
	start.AnchorPoint = Vector2.new(0.5, 0.5)
	start.Position = UDim2.fromScale(startPos[1], startPos[2])
	start.Size = UDim2.fromOffset(NODE_SIZE + 12, NODE_SIZE + 12)
	start.ZIndex = 3
	start.BackgroundColor3 = Color3.fromRGB(150, 90, 230)
	setIcon(start.Icon, "✦", nil, 0)
	start.LevelChip.Level.Text = tr("START")
	start.Lock.Visible = false
	if start:FindFirstChild("CanBuy") then start.CanBuy.Visible = false end
	Free.Shape(start)
	press(start)
	start.Activated:Connect(function()
		UiSfx.play("UiButtonClick")
		selected = "__Start"
		renderTree()
		renderDetail()
	end)
	start.Parent = holder
	for _, branch in cfg.Branches or {} do
		local prev = startPos
		for _, perkId in branch.Perks do
			local perk = PERK_BY_ID[perkId]
			local pos = layout[perkId]
			if perk and pos then
				local info = infoOf(perkId)
				local locked = info.Locked == true
				local maxed = info.Level >= perk.MaxLevel
				Free.Link(holder, size, prev, pos, locked and COLOR_LOCKED or branch.Color)
				prev = pos
				local node = nodeTemplate:Clone()
				node.Name = "Node_" .. perkId
				node.Visible = true
				require(ReplicatedStorage.Shared.TutorialTarget).Mark(node, locked and "PerkNode-" or ("PerkNode:" .. perkId)) -- v20.110
				node.AnchorPoint = Vector2.new(0.5, 0.5)
				node.Position = UDim2.fromScale(pos[1], pos[2])
				node.Size = UDim2.fromOffset(NODE_SIZE, NODE_SIZE)
				node.ZIndex = 3
				node.BackgroundColor3 = locked and COLOR_LOCKED or (maxed and branch.Color:Lerp(COLOR_INK, 0.15) or branch.Color:Lerp(COLOR_STAR, 0.55))
				setIcon(node.Icon, perk.Icon, perk.ImageId, 0)
				node.Icon.Visible = not locked
				local unknown = node:FindFirstChild("Unknown")
				if unknown then unknown.Visible = locked end
				node.LevelChip.Visible = not locked
				node.LevelChip.Level.Text = maxed and "MAX" or ("%d/%d"):format(info.Level, perk.MaxLevel)
				node.LevelChip.Level.TextColor3 = maxed and COLOR_GREEN_TEXT or COLOR_GOLD_TEXT
				node.Lock.Visible = false
				local outline = node:FindFirstChild("Outline")
				if outline then
					outline.Color = (selected == perkId) and Color3.new(1, 1, 1) or COLOR_INK
					outline.Thickness = (selected == perkId) and 5 or 4
				end
				local canBuy = node:FindFirstChild("CanBuy")
				if canBuy then
					canBuy.Visible = not locked and not maxed and state.Points >= (info.Cost or math.huge)
				end
				Free.Shape(node)
				press(node)
				node.Activated:Connect(function()
					UiSfx.play("UiButtonClick")
					selected = perkId
					renderTree()
					renderDetail()
				end)
				node.Parent = holder
			end
		end
	end
end
function Free.Find(perkId)
	local holder = tree:FindFirstChild("FreeTree")
	return holder and holder:FindFirstChild("Node_" .. perkId)
end

renderTree = function()
	Points.Set(pointsLabel, state.Points)
	for _, child in tree:GetChildren() do
		if child:GetAttribute("Generated") then child:Destroy() end
	end
	if cfg.TreeLayout then
		Free.Render()
		return
	end
	for branchIndex, branch in cfg.Branches or {} do
		local column = branchTemplate:Clone()
		column.Name = "Branch_" .. branch.Id
		column:SetAttribute("Generated", true)
		column.LayoutOrder = branchIndex
		column.Visible = true
		column.Header.BackgroundColor3 = branch.Color
		column.Header.Text.Text = tr(branch.Title)
		column.Parent = tree
		local nodes = column.Nodes
		for index, perkId in branch.Perks do
			local perk = PERK_BY_ID[perkId]
			if perk then
				local info = infoOf(perkId)
				local locked = info.Locked == true
				local maxed = info.Level >= perk.MaxLevel
				local y = (index - 1) * (NODE_SIZE + NODE_GAP)
				-- Линия от предыдущего узла: цвет ветки, если открыто.
				if index > 1 then
					local line = linkTemplate:Clone()
					line.Name = "Link"
					line.Visible = true
					-- От низа плашки уровня предыдущего узла до верха этого.
					line.Position = UDim2.new(0.5, 0, 0, y - NODE_GAP + CHIP_OVERHANG)
					line.Size = UDim2.fromOffset(line.Size.X.Offset, NODE_GAP - CHIP_OVERHANG)
					line.BackgroundColor3 = locked and COLOR_LOCKED or branch.Color
					line.ZIndex = 1 -- v20.64: линия ПОД узлом и плашкой уровня «0/10»
					line.Parent = nodes
				end
				local node = nodeTemplate:Clone()
				node.Name = "Node_" .. perkId
				node.Visible = true
				node.Position = UDim2.new(0.5, 0, 0, y)
				node.Size = UDim2.fromOffset(NODE_SIZE, NODE_SIZE)
				node.ZIndex = 3 -- выше линии-связки (у неё 1)
				node.BackgroundColor3 = locked and COLOR_LOCKED or (maxed and branch.Color:Lerp(COLOR_INK, 0.15) or branch.Color:Lerp(COLOR_STAR, 0.55))
				setIcon(node.Icon, perk.Icon, perk.ImageId, locked and 0.55 or 0)
				node.LevelChip.Level.Text = maxed and "MAX" or ("%d/%d"):format(info.Level, perk.MaxLevel)
				node.LevelChip.Level.TextColor3 = maxed and COLOR_GREEN_TEXT or COLOR_GOLD_TEXT
				node.Lock.Visible = locked
				local outline = node:FindFirstChild("Outline")
				if outline then
					outline.Color = (selected == perkId) and Color3.new(1, 1, 1) or COLOR_INK
					outline.Thickness = (selected == perkId) and 5 or 4
				end
				-- Можно купить прямо сейчас — лёгкое свечение.
				local canBuy = node:FindFirstChild("CanBuy")
				if canBuy then
					canBuy.Visible = not locked and not maxed and state.Points >= (info.Cost or math.huge)
				end
				press(node)
				node.Activated:Connect(function()
					UiSfx.play("UiButtonClick")
					selected = perkId
					renderTree()
					renderDetail()
				end)
				node.Parent = nodes
			end
		end
	end
end

local function shrineEffect(def)
	if def.Kind == "Mutation" then
		local mutation = Config.Mutations[def.Mutation]
		return tr("1 of every {n} ore: guaranteed {m}", { n = tostring(def.Every or 3), m = mutation and mutation.DisplayName or def.Mutation })
	elseif def.Kind == "Luck" then
		return tr("+{v}% Luck (permanent)", { v = tostring(math.floor((def.Value or 0) * 100 + 0.5)) })
	end
	return tr("+{v}% Sell Income (permanent)", { v = tostring(math.floor((def.Value or 0) * 100 + 0.5)) })
end

-- v20.94: ИКОНКА СВЯТИЛИЩА = его 3D-модель (рисовать картинку не нужно):
-- широкой стороной к камере (у плоского святилища - верх), с обводкой.
local ShrineIcon = {}
function ShrineIcon.Set(holder, shrineId, def, transparency)
	if not holder then return end
	local ok = false
	if holder:IsA("ImageLabel") or holder:IsA("ImageButton") or holder:IsA("Frame") then
		local OrePreview = require(ReplicatedStorage.Shared.OrePreview)
		local key = "Shrine|" .. tostring(shrineId)
		local existing = holder:FindFirstChild("ModelView")
		if existing and existing:GetAttribute("Key") == key then
			ok = true
		else
			local okBuild, model = pcall(function()
				local PlaceableCatalog = require(ReplicatedStorage.Shared.PlaceableCatalog)
				return require(ReplicatedStorage.Shared.PlaceableFactory).BuildItem(PlaceableCatalog.ShrineId(shrineId))
			end)
			if okBuild and model then
				local okMount, mounted = pcall(OrePreview.MountModel, holder, model, key)
				ok = okMount and mounted
			end
		end
	end
	if ok then
		if holder:IsA("ImageLabel") or holder:IsA("ImageButton") then holder.Image = "" end
		local text = holder:FindFirstChild("Emoji")
		if text then text.Visible = false end
		for _, view in holder:GetChildren() do
			if view:IsA("ViewportFrame") then view.ImageTransparency = transparency or 0 end
		end
	else
		setIcon(holder, def.Icon or "🗿", def.ImageId, transparency)
	end
end

local function renderShrineDetail()
	local def = selectedShrine and SHRINES.Types[selectedShrine]
	if not def then
		detail.Visible = false
		return
	end
	detail.Visible = true
	local info = shrineState[selectedShrine] or {}
	ShrineIcon.Set(detail.Icon, selectedShrine, def)
	detail.Title.Text = tr(def.DisplayName)
	detail.Title.TextColor3 = Color3.fromRGB(255, 220, 110)
	detail.Level.Text = tr("SHRINE · never resets")
	detail.Now.Text = shrineEffect(def)
	detail.Next.Text = tr("Place it on your base")
	detail.Hint.Visible = false
	if info.Owned then
		upgradeText.Text = "✅ " .. tr("OWNED")
		upgradeButton.BackgroundColor3 = COLOR_GREY
	else
		local affordable = state.Points >= (def.Cost or math.huge)
		Points.Set(upgradeText, def.Cost or 0)
		upgradeButton.BackgroundColor3 = affordable and COLOR_GREEN or COLOR_ORANGE
	end
end

local function renderShrines()
	Points.Set(pointsLabel, state.Points)
	for _, child in shrinesList:GetChildren() do
		if child:GetAttribute("Generated") then child:Destroy() end
	end
	for index, shrineId in SHRINES.Order or {} do
		local def = SHRINES.Types[shrineId]
		if def then
			local info = shrineState[shrineId] or {}
			local card = shrineTemplate:Clone()
			card.Name = "Shrine_" .. shrineId
			card:SetAttribute("Generated", true)
			card.Visible = true
			card.LayoutOrder = index
			ShrineIcon.Set(card.Icon, shrineId, def)
			card.Title.Text = tr(def.DisplayName)
			if info.Owned then card.Status.Text = "✅ " .. tr("OWNED"); Points.Hide(card.Status) else Points.Set(card.Status, def.Cost or 0) end
			card.Status.TextColor3 = info.Owned and COLOR_GREEN_TEXT or COLOR_GOLD_TEXT
			card.BackgroundColor3 = (selectedShrine == shrineId) and COLOR_STAR:Lerp(Color3.new(1, 1, 1), 0.25)
				or (info.Owned and COLOR_GREEN:Lerp(COLOR_INK, 0.35) or COLOR_STAR)
			press(card)
			card.Activated:Connect(function()
				UiSfx.play("UiButtonClick")
				selectedShrine = shrineId
				renderShrines()
				renderShrineDetail()
			end)
			card.Parent = shrinesList
		end
	end
end

local function setMode(newMode)
	mode = newMode
	tree.Visible = mode == "Perks"
	shrinesList.Visible = mode == "Shrines"
	if perksTab:GetAttribute("UiSkin") then
		UiKit.ApplySkin(perksTab, mode == "Perks" and "Button_Yellow" or "Button_Dark")
		UiKit.ApplySkin(shrinesTab, mode == "Shrines" and "Button_Yellow" or "Button_Dark")
	else
		perksTab.BackgroundColor3 = mode == "Perks" and Color3.fromRGB(255, 200, 70) or COLOR_STAR
		shrinesTab.BackgroundColor3 = mode == "Shrines" and Color3.fromRGB(255, 200, 70) or COLOR_STAR
	end
	if mode == "Shrines" then
		selectedShrine = selectedShrine or (SHRINES.Order and SHRINES.Order[1])
		renderShrines()
		renderShrineDetail()
	else
		renderTree()
		renderDetail()
	end
end

renderDetail = function()
	if mode == "Shrines" then
		renderShrineDetail()
		return
	end
	if selected == "__Start" then
		detail.Visible = true
		pcall(require(ReplicatedStorage.Shared.OrePreview).Clear, detail.Icon)
		setIcon(detail.Icon, "✦", nil)
		detail.Title.Text = tr("Start")
		detail.Title.TextColor3 = Color3.fromRGB(200, 150, 255)
		detail.Level.Text = ""
		detail.Now.Text = tr(cfg.StartText or "Your journey begins here.")
		detail.Next.Text = ""
		detail.Hint.Visible = false
		upgradeText.Text = "✦"
		Points.Hide(upgradeText)
		upgradeButton.BackgroundColor3 = COLOR_GREY
		return
	end
	local perk = selected and PERK_BY_ID[selected]
	if not perk then
		detail.Visible = false
		return
	end
	detail.Visible = true
	local info = infoOf(perk.Id)
	local branch = BRANCH_OF[perk.Id]
	pcall(require(ReplicatedStorage.Shared.OrePreview).Clear, detail.Icon) -- v20.94: убрать 3D святилища
	setIcon(detail.Icon, perk.Icon, perk.ImageId)
	detail.Title.Text = tr(perk.Title)
	detail.Title.TextColor3 = branch and branch.Color or Color3.new(1, 1, 1)
	detail.Level.Text = ("LV %d/%d"):format(info.Level, perk.MaxLevel)
	detail.Now.Text = info.Level > 0 and effectText(perk, info.Level) or "-"
	local hint = detail.Hint
	hint.Visible = false
	if info.Level >= perk.MaxLevel then
		detail.Next.Text = "✅ MAX"
		upgradeText.Text = "MAX"
		if upgradeText:FindFirstChild("PointIcon") then upgradeText.PointIcon.Visible = false end
		upgradeButton.BackgroundColor3 = COLOR_GREY
	elseif info.Locked then
		local required = info.Requires and PERK_BY_ID[info.Requires]
		detail.Next.Text = "> " .. effectText(perk, info.Level + 1)
		hint.Visible = true
		hint.Text = "🔒 " .. tr("Needs {p}", { p = required and tr(required.Title) or "?" })
		upgradeText.Text = "🔒"
		Points.Hide(upgradeText)
		upgradeButton.BackgroundColor3 = COLOR_GREY
	else
		detail.Next.Text = "> " .. effectText(perk, info.Level + 1)
		local affordable = state.Points >= (info.Cost or math.huge)
		Points.Set(upgradeText, info.Cost or 0)
		upgradeButton.BackgroundColor3 = affordable and COLOR_GREEN or COLOR_ORANGE
	end
end

local function applyState(payload)
	if type(payload) ~= "table" then return end
	state.Points = tonumber(payload.Points) or 0
	levels = {}
	for _, entry in payload.Perks or {} do levels[entry.Id] = entry end
	shrineState = {}
	for _, entry in payload.Shrines or {} do shrineState[entry.Id] = entry end
	if not selected then
		local first = cfg.Branches and cfg.Branches[1] and cfg.Branches[1].Perks[1]
		selected = cfg.TreeLayout and "__Start" or first
	end
	if mode == "Shrines" then
		renderShrines()
	else
		renderTree()
	end
	renderDetail()
end

local function open()
	isOpen = true
	local hrp = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	openedAt = hrp and hrp.Position or nil
	gui.Enabled = true
	UiSfx.play("UiMenuOpen")
	if autoScale then
		local camera = workspace.CurrentCamera
		local viewport = camera and camera.ViewportSize or Vector2.new(1280, 720)
		local target = math.min(1.1, (viewport.X - 40) / (Builder.Width + 20), (viewport.Y - 80) / (Builder.Height + 20))
		autoScale.Scale = target * 0.85
		TweenService:Create(autoScale, TweenInfo.new(0.22, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = target }):Play()
	end
end

local function close()
	if not isOpen then return end
	isOpen = false
	UiSfx.play("UiMenuClose")
	gui.Enabled = false
end

closeButton.Activated:Connect(close)
upgradeButton.Activated:Connect(function()
	if mode == "Shrines" then
		if selectedShrine and not (shrineState[selectedShrine] and shrineState[selectedShrine].Owned) then
			remote:FireServer("BuyShrine", selectedShrine)
		end
		return
	end
	if not selected or not PERK_BY_ID[selected] then return end
	remote:FireServer("Buy", selected)
end)
perksTab.Activated:Connect(function()
	UiSfx.play("UiButtonClick")
	setMode("Perks")
end)
shrinesTab.Activated:Connect(function()
	UiSfx.play("UiButtonClick")
	setMode("Shrines")
end)
UserInputService.InputBegan:Connect(function(input)
	if isOpen and input.KeyCode == Enum.KeyCode.Escape then close() end
end)

local function bounceNode(perkId)
	local column = BRANCH_OF[perkId] and tree:FindFirstChild("Branch_" .. BRANCH_OF[perkId].Id)
	local node = Free.Find(perkId) or (column and column.Nodes:FindFirstChild("Node_" .. perkId))
	local scale = node and node:FindFirstChild("PressScale")
	if scale then
		scale.Scale = 1.25
		TweenService:Create(scale, TweenInfo.new(0.35, Enum.EasingStyle.Back, Enum.EasingDirection.Out), { Scale = 1 }):Play()
	end
end

tree:GetPropertyChangedSignal("AbsoluteSize"):Connect(function()
	if isOpen and mode ~= "Shrines" and cfg.TreeLayout then renderTree() end
end)

remote.OnClientEvent:Connect(function(command, payload)
	if command == "Open" then
		applyState(payload)
		open()
	elseif command == "State" then
		applyState(payload)
	elseif command == "BuyResult" and type(payload) == "table" then
		UiSfx.play(payload.Ok and "UiButtonClick" or "UiError")
		if payload.Ok and payload.ShrineId then
			-- святилище легло в инвентарь (вкладка TOTEMS)
		elseif payload.Ok then
			task.defer(bounceNode, payload.PerkId)
		elseif payload.Reason and isOpen then
			local hint = detail.Hint
			hint.Visible = true
			hint.Text = tr(payload.Reason)
		end
	end
end)

-- Отошёл от чемоданчика — закрываем.
task.spawn(function()
	while true do
		task.wait(0.5)
		if isOpen and openedAt then
			local hrp = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
			if not hrp or (hrp.Position - openedAt).Magnitude > 16 then close() end
		end
	end
end)
